# دليل ربط نظام الذكاء

**لفريق الذكاء.** نظام المكتب لا يحتوي أيّ نموذج. الذكاء يسمع الشخصية ويفهم شنو تريد، ونظام المكتب ينفّذ: يحدّد الموظف، يخزّن، يرنّ على الأجهزة، ويسجّل كل شي بسجلّ الأحداث.

```
الشخصية تتكلم
      │
      ▼
 نظام الذكاء ──── /api/v1/ai/*  (مفتاح خدمة) ────> خادم المكتب ───> PostgreSQL
                                                     ▲
                       تطبيق الموظفين ── /api/v1/* ──┘  (دخول المستخدم)
```

| عليكم | علينا |
|---|---|
| الصوت، النموذج، فهم الكلام، أسئلة التأكيد قبل الأفعال الخطرة | تحديد الموظف من الاسم أو المنصب، ورفض التخمين |
| تحويل التواريخ المحكية («باچر العصر») إلى وقت ISO | الموعد الافتراضي، التخزين، الإشعارات، التذكيرات |
| تحويل المعلومات إلى كلام للشخصية | التقارير، التبليغات، الموجز، سجلّ الأحداث |
| نموذج الوجه (`POST /embed`، أدناه) | مطابقة الوجه وتسجيل الدخول |

**ممنوع الكتابة بالقاعدة مباشرة.** كل تغيير يمرّ من هذا الباب، فتتطبّق نفس القواعد اللي يمرّ بيها التطبيق.

## المصادقة

مدير النظام يصنع مفتاحاً (`POST /api/v1/api-keys` من حسابه، أو `npm run db -- api-key "نظام الذكاء"` على الخادم). المفتاح يظهر **مرّة وحدة** فقط:

```
Authorization: Bearer ok_<prefix>_<secret>
```

(أو `x-api-key: ok_...`). لكل مفتاح نطاقات:

| النطاق | يسمح بـ |
|---|---|
| `ai.read` | كل طلبات `GET` |
| `ai.tasks.write` | إنشاء المهام، إلغاؤها، تحويلها، تمديدها، قبولها أو إرجاعها، هامش الكتب |
| `ai.office.write` | المواعيد، الرسائل للموظفين، تعليم الرسائل والتبليغات والموجز كمسموعة |

بلا مفتاح: `401 INVALID_API_KEY`. مفتاح بلا النطاق: `403 MISSING_SCOPE`. كل فعل يتسجّل بسجلّ الأحداث كأنه من «الذكاء نيابة عن الشخصية» مع اسم المفتاح اللي سوّاه.

```bash
curl http://<الخادم>:8000/api/v1/ai/health -H "Authorization: Bearer $AI_API_KEY"
```

## قواعد عامة

- JSON، والأوقات ISO 8601 **مع المنطقة** (`2026-11-10T18:00:00+03:00`). التواريخ بلا ساعة `YYYY-MM-DD` بتوقيت المكتب (بغداد).
- الخطأ: `{ "error": { "code", "message", "requestId", "details?" } }`. الرسالة عربية وجاهزة تنقال للشخصية.
- **إعادة الطلب بأمان:** أرسلوا `Idempotency-Key: <قيمة فريدة لكل أمر>` مع كل `POST`. الإعادة بنفس القيمة ترجع نفس الجواب الأول (مع ترويسة `idempotent-replayed: true`) ولا تنفّذ مرّتين.
- **الموظف:** بالاسم كما قيل (`assignee_query`) أو بالمعرّف (`assignee_id`)، واحد منهم. إذا طابق أكثر من شخص: `409 AMBIGUOUS_ASSIGNEE` والمرشحون في `details.candidates`، فاسألوا الشخصية وأعيدوا بـ `assignee_id`. لا أحد: `404 ASSIGNEE_NOT_FOUND`.
- **المهمة أو الكتاب:** بالمعرّف. ابحثوا أوّلاً بـ `GET /tasks?q=` أو `GET /letters?q=`؛ إذا رجع أكثر من واحد، اسألوا الشخصية.
- الوقت الفائت مرفوض (`DUE_IN_PAST`، `IN_PAST`).

## القراءة (`ai.read`)

| الطلب | يجيب عن |
|---|---|
| `GET /health` | المفتاح شغّال، ونطاقاته |
| `GET /people` | الموظفون: الاسم، المنصب، الرتبة، الأسماء الثانية. (الشخصية لا تظهر) |
| `GET /people/resolve?q=` | منو المقصود بهالاسم؟ 409 مع المرشحين إذا أكثر من واحد |
| `GET /tasks` | المهام المفتوحة، الأقرب موعداً أوّلاً. `?q=` كلمات من العنوان أو اسم الموظف (كل التاريخ، الأقرب مطابقة أوّلاً). `?assignee_id=` لموظف. `?all=true` يضيف المنتهية والملغاة |
| `GET /tasks/{id}` | المهمة كاملة: التسليمات، الرسائل عنها، `handed_in`، `return_note`، `last_message`، الأوقات بالثواني |
| `GET /tasks/{id}/images` | روابط صور المهمة، صالحة ساعة، تنفتح بلا دخول |
| `GET /letters` | كتب آخر 30 يوماً. `?unmargined=true` الواردة بلا هامش. `?q=` كلمات الموضوع أو الجهة أو العدد |
| `GET /letters/{id}/images` | صفحات الكتاب، روابط صالحة ساعة |
| `GET /facts?from=&to=&q=` | كل ما يعرفه المكتب لفترة (أدناه) |
| `GET /briefing` | موجز الشخصية لما تفتح: ينتظر قرارها، المتأخر، اليوم، من آخر مرة، البارحة. فيه `spoken` جملة جاهزة |
| `GET /today` | اليوم بنظرة: المواعيد، المتأخر، غير المفتوح، من يشتغل، الرسائل غير المقروءة |
| `GET /announcements` | شنو لازم ينقال للشخصية بدون ما تسأل، العاجل أوّلاً (آخر 12 ساعة) |
| `GET /events?after_id=&limit=` | سجلّ الأحداث بالترتيب. احفظوا آخر `id` حتى ما يفوتكم شي |

### `GET /facts`

بدون تواريخ: اليوم. `from` وحده يعني يوماً واحداً، و`to` وحده يعني من اليوم إلى `to`.

```json
{
  "now": "…", "time_zone": "Asia/Baghdad", "period": { "from": "2026-11-08", "to": "2026-11-08" },
  "people": [{ "id": "…", "full_name": "سامي علي", "job_title": "مدير المكتب", "role_name": "مدير المكتب", "aliases": [] }],
  "tasks": [{ "id": "…", "title": "…", "assignee": "…", "status": "submitted", "due_at": "…", "opened_at": "…",
              "receipt_delay_s": 300, "overdue_s": null, "is_overdue": false, "device_not_reached": false,
              "handed_in": "…", "return_note": null, "last_message": { "from": "…", "body": "…", "at": "…" } }],
  "appointments": [{ "title": "…", "starts_at": "…", "guest": "أبو علي", "organization": "…", "guest_notes": "…",
                     "earlier_visits": 1, "last_visit": "…" }],
  "meetings": [{ "title": "…", "held_at": "…", "body": "نص المحضر", "decisions": ["…"], "recorded_by": "…" }],
  "messages_to_principal": [{ "id": "…", "sender_name": "…", "body": "…", "task_title": null }],
  "messages_from_principal": [{ "body": "…", "to_name": "…", "created_at": "…", "read_at": null }],
  "letters": [{ "subject": "…", "party": "…", "ref_number": "…", "summary": "…", "margin": null, "task_assignee": null }],
  "performance": [{ "assignee": "…", "total_tasks": 5, "closed_on_time": 4, "overdue_now": 1 }]
}
```

- المهام: مهام الفترة وكل المفتوح دائماً، أو مع `q` المطابق بكل التاريخ.
- المواعيد: أيام الفترة، أو الأسبوع القادم إذا ما انطى تاريخ.
- المحاضر: أيام الفترة، وقرارات آخر شهر مهما كان يومها («شنو قررنا عن المحولة؟»).
- القراءة ما تعلّم شي. لما تسمع الشخصية رسائلها: `POST /messages/read`.

## المهام (`ai.tasks.write`)

| الطلب | الجسم |
|---|---|
| `POST /tasks` | `assignee_query` أو `assignee_id`، `title`، `original_utterance` (إجباري: كلامها كما سُمع)، `description?`، `priority?` (`normal`/`high`)، `due_at?` أو `due_in_hours?` (الافتراضي 48 ساعة) |
| `POST /tasks/{id}/cancel` | `reason` |
| `POST /tasks/{id}/reassign` | `assignee_query` أو `assignee_id`، `reason`. ترجع مختومة للجديد |
| `POST /tasks/{id}/extend` | `due_at` أو `due_in_hours`، `reason`. الموعد الأول يبقى مسجّلاً |
| `POST /tasks/{id}/review` | `decision`: `accepted` أو `returned`، و`note` (إجباري مع الإرجاع). للمهام المسلَّمة فقط |
| `POST /letters/{id}/margin` | `margin` (نص الهامش)، `original_utterance`، `assignee_query?` أو `assignee_id?` (بدونهما يرجع لمن سجّل الكتاب)، `priority?`، `due_at?` أو `due_in_hours?` |

```bash
curl -X POST http://<الخادم>:8000/api/v1/ai/tasks \
  -H "Authorization: Bearer $AI_API_KEY" -H "Idempotency-Key: 7c1e6a10" -H "Content-Type: application/json" \
  -d '{"assignee_query": "مدير المكتب", "title": "حجز موعد مع فلان", "priority": "high",
       "due_at": "2026-11-10T18:00:00+03:00", "original_utterance": "خلي مدير المكتب يحجزلي موعد ويا فلان باچر"}'
```

```json
201 { "id": "…", "status": "assigned", "priority": "high", "due_at": "…", "assignee": { "id": "…", "full_name": "سامي علي" } }
```

الموظف يشوف المرسل «الشخصية الأساسية» وكلامها الأصلي، بعد ما يفتح المهمة فقط.

| الخطأ | المعنى |
|---|---|
| `409 TASK_BAD_STATE` | حالة المهمة ما تسمح (ملغاة، منتهية، أو تنتظر مراجعة عند التحويل) |
| `409 SAME_ASSIGNEE` | التحويل لنفس الشخص |
| `409 LETTER_MARGINED` | الكتاب مهمّش من قبل |
| `400 RETURN_NEEDS_REASON` | إرجاع بلا سبب |

## باقي المكتب (`ai.office.write`)

| الطلب | الجسم |
|---|---|
| `POST /appointments` | `title`، `starts_at`، `kind?` (`appointment`/`interview`)، `ends_at?`، `location?`، `notes?`، `guest?` (اسم الضيف: نفس الملف إذا موجود، وإلا ملف جديد)، `original_utterance?`. يوصل إشعار لمن يدير المواعيد |
| `POST /messages` | `body`، و`all: true` أو `recipients: ["اسم أو معرّف", …]`، و`task_id?` |
| `POST /messages/read` | `ids`: رسائل للشخصية سمعتها |
| `POST /announcements/{id}/spoken` | التبليغ انقال (والرسالة اللي بيه تنحسب مقروءة) |
| `POST /briefing/seen` | سمعت الموجز: الموجز الجاي يبدأ من هسه |

## أسئلة التأكيد مسؤوليتكم

نظام المكتب ينفّذ مباشرة. قبل الأفعال اللي تاخذ شغل من أحد أو توصل للكل، اسألوا الشخصية أوّلاً، مثل ما كان يسوي النموذج: «ألغي مهمة «…» اللي عند فلان؟»، «أحوّلها من فلان إلى فلان؟»، «أرسل لكل الموظفين: …؟». خلّوا التأكيد مربوطاً بجلسة الشخصية، مو حالة عامة.

## الوجه: الاتجاه المعاكس

تسجيل الدخول بالوجه يصير بخادم المكتب، لكن النموذج عندكم. الخادم ينادي `FACE_URL` (بالإعدادات):

```
POST <FACE_URL>/embed
Content-Type: application/octet-stream
<بايتات الصورة>
```

```json
200 { "faces": 1, "embedding": [128 رقماً] }
200 { "faces": 0 }                       ما بيّن وجه
200 { "faces": 2 }                       أكثر من وجه
200 { "faces": 1, "error": "FACE_TOO_SMALL" }
200 { "faces": 0, "error": "NOT_AN_IMAGE" }
```

خادم المكتب يحفظ البصمات (لا الصور) ويطابقها بنفسه. التفاصيل في [06-face-login.md](06-face-login.md).

## السرّية

- `facts` يعطي نص المحاضر لأنكم تخدمون الشخصية وحدها. **لا تقولوه لأيّ شخص غيرها.**
- المفتاح يعادل صلاحيات الشخصية على المكتب: لا تعطوه لأيّ برنامج يستعمله غيرها، واصنعوا لكل برنامج مفتاحه ونطاقاته.
- لا تدرّبوا نموذجاً على هذه البيانات ولا ترسلوها خارج الشبكة.

## للتجربة بدون نموذج

[`tools/fake_ai/fake_ai.py`](../tools/fake_ai/fake_ai.py) يحاكي الذكاء بلا مكتبات خارجية:

```bash
python tools/fake_ai/fake_ai.py task "مدير المكتب" "حجز موعد مع فلان" --hours 168 --high
```
```bash
python tools/fake_ai/fake_ai.py facts --q "سامي"
```

يقرأ `OFFICE_URL` و`AI_API_KEY` من البيئة.
