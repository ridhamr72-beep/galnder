# قاعدة البيانات

PostgreSQL واحدة. المرجع هو الكود: المخطط الأوّل في [`server/src/office/schema.ts`](../server/src/office/schema.ts) والتغييرات بعده في [`server/src/db/migrations.ts`](../server/src/db/migrations.ts). الخادم يطبّق ما لم يُطبَّق عند كل تشغيل، وكل ترحيل بـ transaction.

**لا يكتب بالقاعدة غير الخادم.** تطبيق الموظفين ونظام الذكاء يمرّان من الـ API.

## الترحيلات

| المعرّف | المحتوى |
|---|---|
| `002_office` | المخطط الأساسي: الهوية، المهام، المحاضر، المواعيد، الإشعارات، السجلّ، الإعدادات، والـ View `office_tasks` |
| `003_office_messages` | الرسائل |
| `004_office_announcements` | تبليغات الشخصية |
| `005_office_letters` | الكتب الرسمية، وصور الكتاب ضمن `attachments` |
| `007_office_meeting_decisions` | قرارات المحضر |
| `008_office_manager_oversight` | مدير المكتب يرى كل المهام والالتزام |
| `009_office_more_alerts` | إشعارات الإغلاق والتمديد والإلغاء والمواعيد |
| `010_office_face_prints` | بصمات الوجه (أرقام، لا صور) |
| `011_office_service_keys` | مفاتيح الخدمات ونطاقاتها، `idempotency_keys`، و`events.actor_key_id` |

المعرّفات نفسها اللي كانت لهذه التغييرات أيام كان المكتب داخل البوابة، فقاعدة طُبّقت عليها من قبل ما تتغيّر مرّتين. **`001` (قاعدة المعرفة) و`006` (بنك الجمل) لنظام الذكاء وليست هنا.** إذا كانت القاعدة العامة تحمل جداول الذكاء أيضاً، فالخادم ما يلمسها.

## المجموعات

| المجموعة | الجداول |
|---|---|
| الهوية | `users`, `roles`, `permissions`, `role_permissions`, `devices`, `refresh_tokens`, `face_prints` |
| مفاتيح الخدمات | `api_keys`, `idempotency_keys` |
| العمل | `tasks`, `task_submissions`, `attachments`, `meetings`, `appointments`, `persons`, `letters`, `messages` |
| الإشعارات | `notifications`, `notification_deliveries_sent` |
| الذاكرة | `events`, `daily_reports`, `announcements` |
| البنية | `jobs`, `settings`, `schema_migrations` |

`office_tasks` (View): كل مهمة مع اسم المكلَّف وأوقاتها ومددها بالثواني: `receipt_delay_s` من وصولها للجهاز إلى فتحها، `execution_s`، `overdue_s`، `is_overdue`، `device_not_reached`.

## قواعد تحميها القاعدة نفسها

ترفضها القاعدة حتى لو أخطأ الكود:

- شخصية أساسية واحدة فقط (`one_principal`).
- لكل مهمة منشئ واحد: مستخدم، أو الذكاء نيابة عن الشخصية.
- مهمة من الذكاء بلا كلام الشخصية الأصلي مرفوضة.
- تسليم واحد مقبول لكل مهمة، والإرجاع بلا سبب مرفوض.
- المرفق لمهمة أو لكتاب، واحد منهم.
- `events` لا يُعدَّل ولا يُحذف.

## سجلّ الأحداث `events`

كل فعل مهم يضيف صفاً، و`summary` جملة عربية جاهزة. `actor_type` واحد من `user` و`ai` و`system`، ومع `ai` يحمل `actor_key_id` المفتاح اللي سوّاه.

| النوع | متى |
|---|---|
| `task.created` · `delivered` · `opened` · `started` · `submitted` · `returned` · `closed` · `reassigned` · `extended` · `cancelled` · `reminder_sent` | دورة المهمة |
| `meeting.published` | نُشر محضر |
| `appointment.created` / `.cancelled` | موعد |
| `letter.registered` / `.margined` | كتاب وهامشه |
| `message.sent` | رسالة (للشخصية بـ `visibility = principal`) |
| `auth.login` · `login_failed` · `face_enrolled` · `face_failed` · `face_wiped` | الدخول |
| `user.*` · `role.*` · `api_key.*` | تغييرات إدارية |

## السرّية `visibility`

- `principal`: للشخصية فقط، مثل رسائل الموظفين لها.
- `general`: أحداث العمل العادية.

نص المحضر لا يصل لأيّ موظف غير كاتبه، ويصل للشخصية عبر نظام الذكاء.

## الإعدادات `settings`

تُعدَّل من `PATCH /api/v1/settings` (`settings.manage`). أهمّها: `timezone`، `report.morning_time` و`report.evening_time`، `task.default_due_hours`، `reminder.before_due_hours`، `alert.normal_repeat_minutes` و`alert.high_repeat_minutes`، `auth.max_failed_attempts` و`auth.lock_minutes`، `announce.unopened_minutes` و`announce.appointment_minutes`. سرّ توقيع التوكنات `secret.jwt` لا يظهر بالـ API.

## النسخ والاسترجاع

`npm run backup` يصدّر كل جدول JSON lines بترتيب يسمح بالاسترجاع، و`npm run db -- restore "<المجلد>"` يرجعه لقاعدة فارغة فقط. التفاصيل في [09-deployment.md](09-deployment.md).
