# عقد الـ API

المسار الأساسي `http://<الخادم>:8000/api/v1`. هذا الملف لتطبيق الموظفين، والمرجع الدقيق هو الكود (`server/src/office/`).

باب نظام الذكاء `/api/v1/ai/*` موثّق منفصلاً في [07-ai-integration.md](07-ai-integration.md).

## قواعد عامة

- JSON بأسماء `snake_case`. الأوقات ISO 8601 بتوقيت UTC.
- المعرّفات UUID.
- القوائم ترجع `{ "items": [], "next_cursor": null }`.
- لا يُقبل أيّ وقت من العميل لتسجيل حدث.

شكل الخطأ:

```json
{ "error": { "code": "TASK_NOT_FOUND", "message": "المهمة غير موجودة", "requestId": "…", "details": {} } }
```

| الحالة | المعنى |
|---|---|
| 401 | غير مسجّل دخول |
| 403 | لا صلاحية |
| 404 | غير موجود، أو غير مسموح أن يعرف بوجوده |
| 409 | حالة لا تسمح، مثل تسليم مهمة مغلقة |
| 400 | بيانات خاطئة (`VALIDATION_ERROR`) |
| 429 | محاولات دخول كثيرة (`LOGIN_LOCKED`، `FACE_PAUSED`) |

## المصادقة

| الطلب | الوصف |
|---|---|
| `POST /auth/login` | اسم مستخدم وكلمة مرور وبيانات الجهاز |
| `POST /auth/face` | `{image, device}`: دخول بالوجه، نفس التوكنات. انظر [06-face-login.md](06-face-login.md) |
| `GET/POST/DELETE /me/face` | بصمات وجهي: كم عندي، أضيف، أطفي |
| `POST /auth/refresh` | تجديد |
| `POST /auth/logout` | خروج وإبطال الجهاز الحالي |
| `GET /me` | المستخدم وصلاحياته |

ترجع: `access_token`، و`refresh_token`، و`push_token` (لقناة الإشعارات فقط).

## المهام

| الطلب | الصلاحية | الوصف |
|---|---|---|
| `GET /tasks/mine` | `tasks.read_own` | مهامي |
| `GET /tasks/sent` | أيّ مستخدم، ويرى ما أرسله هو فقط | هل وصلت، ومتى فُتحت، وأين وصلت |
| `POST /tasks/{id}/open` | المكلَّف فقط | يكشف المحتوى ويسجّل وقت الاستلام |
| `GET /tasks/{id}` | المكلَّف بعد الفتح، أو `tasks.read_all` | التفاصيل |
| `POST /tasks/{id}/start` | المكلَّف | باشر |
| `POST /tasks/{id}/submit` | المكلَّف | يرسل `result_text` |
| `GET /tasks` | `tasks.read_all` | كل المهام مع فلاتر |
| `POST /tasks` | `tasks.create` | إنشاء من التطبيق |
| `GET /tasks/review-queue` | `tasks.review` | بانتظار المراجعة |
| `POST /tasks/{id}/review` | `tasks.review` | `{decision, note}` |
| `POST /tasks/{id}/reassign` | `tasks.reassign` | `{assignee_id, reason}` |
| `POST /tasks/{id}/extend` | `tasks.reassign` | `{due_at, reason}` |
| `POST /tasks/{id}/cancel` | `tasks.cancel` | `{reason}` |

### المهمة المختومة

قبل الفتح، `GET /tasks/mine` يرجع المهمة **بدون عنوان أو تفاصيل**:

```json
{ "id": "…", "sealed": true, "notification_level": "high", "created_at": "…" }
```

وبعد `POST /tasks/{id}/open` ترجع كاملة:

```json
{
  "id": "…", "sealed": false, "title": "حجز موعد مع فلان",
  "description": "…", "priority": "high", "status": "opened",
  "due_at": "…", "created_at": "…", "opened_at": "…", "started_at": null,
  "sender_name": "الشخصية الأساسية", "sender_id": null,
  "original_utterance": "خلي مدير المكتب يحجزلي موعد ويا فلان باجر",
  "attachments": 1, "messages": 2, "return_note": null, "last_result": null
}
```

`sender_name` يكون «الشخصية الأساسية» إذا الذكاء أنشأها (و `sender_id` فارغ)، و `original_utterance` كلام الشخصية كما قيل.

## الرسائل

| الطلب | الصلاحية | الوصف |
|---|---|---|
| `GET /messages` | أيّ مستخدم | ما أرسلته وما وصلني، الأحدث أوّلاً |
| `POST /messages` | أيّ مستخدم | `{to, body, task_id?}`: `to` معرّف موظف أو `"principal"` |
| `POST /messages/{id}/read` | المستلم | قرأتها، ويوقف إشعارها |
| `GET /tasks/{id}/messages` | من يرى المهمة | محادثة المهمة |

الرسالة لموظف تصله بإشعار `message` (بلا نصّ، مثل المهام). الرسالة للشخصية تبقى حتى تسأل الذكاء «اكو رسائل؟»،
فيقرأها لها مرّة واحدة. ورسالة عن مهمة لا تُرسل إلّا ممّن يرى المهمة.

`open` آمن للتكرار: الفتح الثاني يرجع نفس المحتوى ولا يغيّر الوقت الأوّل.
ولا يرجع أيّ طلب للموظف نص المحضر أو مهام غيره. `meeting_id` نفسه لا يظهر له.

## الكتب الرسمية

| الطلب | الصلاحية | الوصف |
|---|---|---|
| `GET /letters?direction=incoming\|outgoing` | `letters.read` | السجل، مع الهامش وحالة مهمته |
| `POST /letters` | `letters.write` | `{direction, subject, party?, ref_number?, letter_date?, summary?}` |
| `POST /letters/{id}/images` · `GET /letters/{id}/images` | `letters.write` · `letters.read` | صفحات الكتاب |
| `POST /letters/{id}/margin` | `letters.write` | هامش ورقي: `{assignee_id, margin, priority?, due_in_hours?}` ← مهمة ويا الصفحات |
| `GET /persons/{id}` · `PATCH /persons/{id}` | `persons.write` | ملف الضيف وزياراته السابقة |

الكتاب يُسجَّل يدوياً مع صور صفحاته. الشخصية تهمّش بالكلام عبر نظام الذكاء (`POST /ai/letters/{id}/margin`) أو على الورق فيدخله مدير المكتب، والمهمة تحمل نسخة من صفحات الكتاب.

## الصور

| الطلب | الوصف |
|---|---|
| `POST /tasks/{id}/attachments` | multipart `file` (jpg/png/webp، 5 MB): المرسل يرفق للمهمة، والمكلَّف للنتيجة بعد الفتح |
| `GET /tasks/{id}/attachments` · `GET /attachments/{id}` | لمن يرى المهمة |
| `GET /files/{id}?exp=&sig=` | رابط موقّع صالح ساعة بلا دخول، يصنعه باب الذكاء ليعرض الصورة للشخصية |

## الإشعارات

| الطلب | الوصف |
|---|---|
| `GET /notifications/mine?after_seq=` | إشعاراتي، بلا أيّ نصّ من المهمة |
| `POST /notifications/{id}/read` | يوقف إشعاراً لا تفتحه مهمة، مثل `review_needed` |

فتح المهمة بـ `POST /tasks/{id}/open` يوقف كل إشعاراتها تلقائياً، وآمن للتكرار، فيُستدعى أيضاً عند إعادة فتح مهمة مرجَّعة.

## الاجتماعات

| الطلب | الصلاحية | الوصف |
|---|---|---|
| `GET /meetings` | `meetings.write` | **محاضره هو فقط** |
| `POST /meetings` | `meetings.write` | مسودة جديدة |
| `GET/PATCH /meetings/{id}` | كاتبه فقط | قراءة وتعديل المسودة |
| `POST /meetings/{id}/publish` | كاتبه فقط | ينشر وينشئ المهام معاً |

طلب النشر، إمّا ينجح كله أو لا يحدث شيء:

```json
{
  "tasks": [
    { "title": "…", "description": "…", "assignee_id": "…",
      "priority": "high", "due_at": "2026-11-11T09:00:00Z" }
  ]
}
```

## المتابعة والتقارير

| الطلب | الصلاحية | الوصف |
|---|---|---|
| `GET /dashboard/overview` | `performance.read` | متأخرة، قريبة، غير مفتوحة، بانتظار المراجعة |
| `GET /dashboard/performance` | `performance.read` | التزام كل موظف، مع `start` و`end` |
| `GET /tasks/{id}/timeline` | `tasks.read_all` | الخط الزمني للمهمة |

## المواعيد والأشخاص

`GET /directory` (`directory.read`): أسماء من يمكن إرسال مهمة لهم.
`GET/POST/DELETE /appointments` (`appointments.write`)، و`kind` قيمته `appointment` أو `interview`، و`notes` ما يريد مدير المكتب أن تعرفه الشخصية.
`GET/POST /persons` و`GET/PATCH /persons/{id}` (`persons.write`)

## الإدارة

| المسار | الصلاحية |
|---|---|
| `/users` | `users.manage` |
| `/roles`، `/permissions` | `roles.manage` |
| `/devices`، `POST /devices/{id}/revoke` | `users.manage` |
| `POST /users/{id}/password` | `users.manage` |
| `DELETE /users/{id}/face` | `users.manage` |
| `/settings` | `settings.manage` |
| `GET/POST /api-keys`، `POST /api-keys/{id}/revoke` | `api_keys.manage`: مفاتيح نظام الذكاء. `POST` يرجع المفتاح مرّة وحدة |

## WebSocket

`GET /ws` مع ترويسة `Authorization: Bearer <push_token>`. البروتوكول في [05-notifications.md](05-notifications.md).
