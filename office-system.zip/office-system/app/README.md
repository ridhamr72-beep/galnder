# تطبيق نظام المكتب

Flutter للكمبيوتر (ويندوز)، والهاتف لاحقاً. كل شاشة تظهر بالصلاحية القادمة من `GET /me`، لا باسم الدور.

| الملف | عمله |
|---|---|
| `lib/core/api.dart` | الطلبات، وتجديد الجلسة، وأخطاء الخادم |
| `lib/core/push.dart` | الاتصال الدائم بالإشعارات، والـ ack، وإعادة الاتصال |
| `lib/core/session.dart`، `store.dart` | المستخدم الحالي وحفظ الجلسة |
| `lib/core/ui.dart` | الألوان والعناصر المشتركة |
| `lib/shell.dart` | القائمة الجانبية وشاشة الرنين |
| `lib/features/` | شاشة لكل قسم |

## التشغيل

يحتاج Flutter وVisual Studio مع أدوات C++. شغّل الخادم أوّلاً (من مجلد `server`، يفتح على المنفذ 8000 ويملأ مكتباً تجريبياً):

```bash
npm run setup
```
```bash
npm start
```

ثمّ التطبيق:

```bash
flutter run -d windows
```

عنوان الخادم يُحدَّد وقت البناء، والافتراضي `http://127.0.0.1:8000`:

```bash
flutter build windows --release --dart-define=API_URL=http://<جهاز-الخادم>:8000
```

## الاختبارات

```bash
flutter test test
```
```bash
flutter test integration_test/real_server_test.dart -d windows
```

الثاني يشغّل التطبيق الحقيقي مع الخادم الحقيقي: دخول، إشعار عالي الأهمية، فتح، تسليم.

## ناقص

- شاشة مفاتيح الخدمات والإعدادات (الخادم جاهز لها: `/api/v1/api-keys` و`/api/v1/settings`؛ المفتاح يُصنع الآن بـ `npm run db -- api-key`).
- البقاء في شريط النظام مع تشغيل ويندوز.
- ويندوز يصدر صوت تنبيه النظام، لا رنيناً خاصاً.
- خدمة أندرويد بـ Kotlin.
