// لقطات لشاشة كل دور من التطبيق الحقيقي، للمراجعة بالعين.
// flutter test integration_test/screens_test.dart -d windows --dart-define=SHOT_DIR=<folder>
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:office_app/core/api.dart';
import 'package:office_app/core/push.dart';
import 'package:office_app/core/session.dart';
import 'package:office_app/core/store.dart';
import 'package:office_app/main.dart';
import 'package:window_manager/window_manager.dart';

const shotDir = String.fromEnvironment('SHOT_DIR');

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  Future<void> shot(WidgetTester tester, GlobalKey key, String name) async {
    await tester.pump(const Duration(seconds: 1));
    await tester.pumpAndSettle(const Duration(milliseconds: 200), EnginePhase.sendSemanticsUpdate, const Duration(seconds: 5));
    final boundary = key.currentContext!.findRenderObject() as RenderRepaintBoundary;
    final image = await boundary.toImage();
    final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
    await File('$shotDir/$name.png').writeAsBytes(bytes!.buffer.asUint8List());
  }

  for (final (user, sections) in [
    ('mustafa', ['محضر جديد']),
    ('sami', ['مهامي', 'الكتب', 'المواعيد']),
    ('ali', ['كل المهام', 'المراجعة']),
    ('zainab', ['مهامي']),
    ('admin', ['الرتب']),
  ]) {
    testWidgets('لقطات $user', (tester) async {
      await windowManager.ensureInitialized();
      tester.view.physicalSize = const Size(1280, 800);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.reset);
      final store = Store.memory();
      final session = Session(Api(store));
      await session.login(user, 'office-dev-1');
      await session.restore();
      final key = GlobalKey();
      await tester.pumpWidget(RepaintBoundary(key: key, child: OfficeApp(session: session, push: PushClient(store))));
      for (final section in sections) {
        await tester.tap(find.text(section).first);
        await tester.pump(const Duration(seconds: 2));
        await shot(tester, key, '$user-$section');
      }
    });
  }
}
