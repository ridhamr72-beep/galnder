// كل شاشة بثلاث أحجام (هاتف، تابلت، كمبيوتر) على السيرفر الحقيقي ومكتبه التجريبي: يفشل إذا شي طلع برّا الشاشة،
// ويحفظ لقطة لكل شاشة للمراجعة بالعين.
// flutter test integration_test/responsive_test.dart -d windows --dart-define=SHOT_DIR=<folder>
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:office_app/core/api.dart';
import 'package:office_app/core/push.dart';
import 'package:office_app/core/session.dart';
import 'package:office_app/core/store.dart';
import 'package:office_app/main.dart';
import 'package:window_manager/window_manager.dart';

const shotDir = String.fromEnvironment('SHOT_DIR');

const sizes = {'phone': Size(390, 844), 'tablet': Size(820, 1000), 'desktop': Size(1280, 800)};
const labels = ['محضر جديد', 'الكتب', 'المواعيد', 'اللوحة', 'المراجعة', 'الالتزام', 'إرسال مهمة', 'ما أرسلته', 'كل المهام', 'مهامي', 'الرسائل', 'الموظفون', 'الرتب'];

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  Future<void> shot(GlobalKey key, String name) async {
    if (shotDir.isEmpty) return;
    final boundary = key.currentContext!.findRenderObject() as RenderRepaintBoundary;
    final image = await boundary.toImage();
    final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
    await File('$shotDir/$name.png').writeAsBytes(bytes!.buffer.asUint8List());
  }

  Future<void> settle(WidgetTester tester) async {
    await tester.pump(const Duration(milliseconds: 1500));
    await tester.pumpAndSettle(const Duration(milliseconds: 100), EnginePhase.sendSemanticsUpdate, const Duration(seconds: 5));
  }

  for (final user in ['sami', 'mustafa', 'ali', 'admin']) {
    for (final MapEntry(key: form, value: size) in sizes.entries) {
      testWidgets('$user على $form', (tester) async {
        await windowManager.ensureInitialized();
        tester.view.physicalSize = size;
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.reset);

        // كل خطأ «طلع برّا» ينسجّل باسم الشاشة، والفحص يكمل لآخر شاشة.
        final problems = <String>[];
        var where = 'البداية';
        final previous = FlutterError.onError;
        FlutterError.onError = (details) {
          final text = details.exceptionAsString();
          if (text.contains('overflowed') || text.contains('unbounded') || text.contains('RenderBox was not laid out')) {
            problems.add('$where: ${text.split('\n').first}');
          } else {
            previous?.call(details);
          }
        };
        addTearDown(() => FlutterError.onError = previous);

        final store = Store.memory();
        final session = Session(Api(store));
        await session.login(user, 'office-dev-1');
        await session.restore();
        final key = GlobalKey();
        await tester.pumpWidget(RepaintBoundary(key: key, child: OfficeApp(session: session, push: PushClient(store))));
        await settle(tester);

        for (final label in labels) {
          if (form == 'phone') {
            await tester.tap(find.byIcon(Icons.menu));
            await settle(tester);
            final item = find.descendant(of: find.byType(Drawer), matching: find.text(label));
            if (item.evaluate().isEmpty) {
              Navigator.of(tester.element(find.byType(Drawer))).pop();
              await settle(tester);
              continue;
            }
            await tester.tap(item.first);
          } else {
            final item = find.text(label);
            if (item.evaluate().isEmpty) continue;
            await tester.tap(item.first);
          }
          where = label;
          await settle(tester);
          await shot(key, '$form-$user-$label');
        }
        expect(problems, isEmpty, reason: problems.join('\n'));
      });
    }
  }
}
