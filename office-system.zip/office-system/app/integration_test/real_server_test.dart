// يشغّل التطبيق الحقيقي مع الخادم الحقيقي. قبله: من مجلد server شغّل npm start (OFFICE_DEMO=true يملأ الحسابات).
// flutter test integration_test -d windows
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:office_app/core/api.dart';
import 'package:office_app/core/push.dart';
import 'package:office_app/core/session.dart';
import 'package:office_app/core/store.dart';
import 'package:office_app/main.dart';
import 'package:window_manager/window_manager.dart';

const password = 'office-dev-1';

Future<void> waitFor(WidgetTester tester, Finder finder, {int seconds = 15}) async {
  for (var i = 0; i < seconds * 10; i++) {
    await tester.pump(const Duration(milliseconds: 100));
    if (finder.evaluate().isNotEmpty) return;
  }
  fail('لم يظهر: $finder');
}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('السكرتير يدخل، ترنّ عليه مهمة عالية، يفتحها ويسلّمها، والمرسل يشوف', (tester) async {
    await windowManager.ensureInitialized();
    final store = Store.memory();
    final session = Session(Api(store));
    await tester.pumpWidget(OfficeApp(session: session, push: PushClient(store)));
    await session.restore();
    await tester.pump();

    // مستخدم جديد لكل تشغيل، حتى لا تختلط مهام التجارب السابقة
    final admin = Session(Api(Store.memory()));
    await admin.login('admin', password);
    final username = 'qa${DateTime.now().millisecondsSinceEpoch}';
    await admin.api.post('/users', {
      'username': username, 'full_name': 'سكرتير الفحص $username', 'role_code': 'secretary', 'password': password,
    });

    await tester.enterText(find.byType(TextField).at(0), username);
    await tester.enterText(find.byType(TextField).at(1), password);
    await tester.tap(find.text('دخول'));
    await waitFor(tester, find.text('مهامي'));

    // الواجهة مفصولة: السكرتير لا يشوف غير مهامه
    expect(find.text('المراجعة'), findsNothing);
    expect(find.text('الموظفون'), findsNothing);
    expect(find.text('إرسال مهمة'), findsNothing);
    await waitFor(tester, find.text('متصل بالمكتب'));

    final senderStore = Store.memory();
    final sender = Session(Api(senderStore));
    await sender.login('ali', password);
    final title = 'فحص حقيقي ${DateTime.now().millisecondsSinceEpoch}';
    final task = await sender.api.post('/tasks', {
      'title': title,
      'assignee_id': session.me!.id,
      'priority': 'high',
      'due_in_hours': 24,
    }) as Map<String, dynamic>;

    await waitFor(tester, find.text('الرنين يتوقف عند فتحها'));
    expect(find.textContaining(title), findsNothing);
    await tester.tap(find.text('افتح المهمة').first);
    await waitFor(tester, find.text(title));
    expect(find.text('الرنين يتوقف عند فتحها'), findsNothing);
    await tester.tap(find.text('باشرت بالمهمة').first);
    await waitFor(tester, find.text('سلّم النتيجة'));
    await tester.enterText(find.byType(TextField).last, 'تم من الفحص');
    await tester.tap(find.text('سلّم النتيجة').first);
    await tester.pump(const Duration(seconds: 2));

    final view = await sender.api.get('/tasks/${task['id']}') as Map<String, dynamic>;
    expect(view['status'], 'submitted');
    expect(view['delivered_at'], isNotNull);
    expect(view['opened_at'], isNotNull);
  });
}
