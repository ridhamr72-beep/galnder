import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:office_app/core/api.dart';
import 'package:office_app/core/push.dart';
import 'package:office_app/core/session.dart';
import 'package:office_app/core/store.dart';
import 'package:office_app/core/ui.dart';
import 'package:office_app/features/compose.dart';
import 'package:office_app/features/my_tasks.dart';

http.Response json(Object body, [int status = 200]) => http.Response.bytes(utf8.encode(jsonEncode(body)), status,
    headers: {'content-type': 'application/json'});

Widget app(Widget child) => MaterialApp(
      theme: appTheme(),
      builder: (context, c) => Directionality(textDirection: TextDirection.rtl, child: c!),
      home: Scaffold(body: child),
    );

void main() {
  test('الصلاحية تأتي من الخادم، لا من اسم الدور', () {
    final me = Me.fromJson({'id': '1', 'full_name': 'س', 'role_code': 'new_role', 'permissions': ['tasks.review']});
    expect(me.can('tasks.review'), isTrue);
    expect(me.can('users.manage'), isFalse);
  });

  test('الإشعار لا يحمل نصاً من المهمة', () {
    expect(Alert('1', 1, 'task_assigned', 'high', 't').text, 'وصلتك مهمة جديدة');
    expect(Alert('1', 1, 'task_assigned', 'high', 't').high, isTrue);
  });

  test('انتهاء التوكن يجدده ويعيد الطلب مرة واحدة', () async {
    final store = Store.memory();
    await store.saveTokens(access: 'old', refresh: 'r');
    var calls = 0;
    final api = Api(store, client: MockClient((request) async {
      if (request.url.path.endsWith('/auth/refresh')) return json({'access_token': 'new', 'refresh_token': 'r2'});
      calls++;
      return request.headers['Authorization'] == 'Bearer new' ? json({'ok': true}) : json({}, 401);
    }));
    expect(await api.get('/me'), {'ok': true});
    expect(calls, 2);
    expect(store.refreshToken, 'r2');
  });

  test('خطأ الخادم يظهر بجملته العربية', () async {
    final api = Api(Store.memory(), client: MockClient((_) async => json({
          'error': {'code': 'forbidden', 'message': 'لا تملك هذه الصلاحية'}
        }, 403)));
    expect(api.get('/users'), throwsA(isA<ApiError>().having((e) => e.message, 'message', 'لا تملك هذه الصلاحية')));
  });

  testWidgets('المهمة المختومة لا تعرض تفاصيل، وتنفتح بالزر', (tester) async {
    var opened = false;
    final api = Api(Store.memory(), client: MockClient((request) async {
      if (request.url.path.endsWith('/open')) {
        opened = true;
        return json({});
      }
      if (request.url.path.endsWith('/attachments')) return json({'items': []});
      if (request.url.path.endsWith('/messages')) {
        return json({
          'items': [
            {'id': 'm1', 'sender_name': 'زينب', 'body': 'القاعة الثانية محجوزة', 'created_at': '2026-11-07T09:00:00Z'}
          ]
        });
      }
      return json({
        'items': [
          opened
              ? {
                  'id': '1', 'sealed': false, 'title': 'تجهيز القاعة', 'status': 'opened', 'priority': 'high',
                  'due_at': '2026-11-08T07:00:00Z', 'sender_name': 'الشخصية الأساسية',
                  'original_utterance': 'خلي القاعة جاهزة باجر الصبح',
                }
              : {'id': '1', 'sealed': true, 'notification_level': 'high'}
        ]
      });
    }));
    await tester.pumpWidget(app(MyTasksScreen(api: api, refresh: ChangeNotifier())));
    await tester.pumpAndSettle();
    expect(find.text('وصلتك مهمة جديدة'), findsOneWidget);
    expect(find.text('تجهيز القاعة'), findsNothing);

    await tester.tap(find.text('افتح المهمة'));
    await tester.pumpAndSettle();
    expect(find.text('تجهيز القاعة'), findsOneWidget);
    expect(find.text('بديت بيها'), findsOneWidget); // one button: the next step only
    expect(find.text('«خلي القاعة جاهزة باجر الصبح»'), findsNothing); // details stay folded

    // التفاصيل الكاملة بالضغط على المهمة: كلام الشخصية ومحادثة المهمة.
    await tester.tap(find.text('تجهيز القاعة'));
    await tester.pumpAndSettle();
    expect(find.text('«خلي القاعة جاهزة باجر الصبح»'), findsOneWidget);
    expect(find.textContaining('القاعة الثانية محجوزة', findRichText: true), findsOneWidget);
    expect(find.text('اكتب لـالشخصية الأساسية عن المهمة'), findsOneWidget);
  });

  testWidgets('زر + يضيف مهمة، والناقص لا يُرسل', (tester) async {
    tester.view.physicalSize = const Size(1400, 1000);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.resetDevicePixelRatio);
    addTearDown(tester.view.resetPhysicalSize);
    final controller = TaskRowsController();
    await tester.pumpWidget(app(ListView(children: [
      TaskRows(people: const [
        {'id': 'u1', 'full_name': 'زينب', 'job_title': 'السكرتير'}
      ], controller: controller),
    ])));
    expect(find.text('1'), findsOneWidget);
    await tester.ensureVisible(find.text('+ أضف مهمة'));
    await tester.tap(find.text('+ أضف مهمة'));
    await tester.pump();
    expect(find.text('2'), findsOneWidget);
    expect(controller.read(), isNull);
  });
}
