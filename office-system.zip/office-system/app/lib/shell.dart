import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:window_manager/window_manager.dart';

import 'core/platform.dart';
import 'core/push.dart';
import 'core/session.dart';
import 'core/ui.dart';
import 'features/admin.dart';
import 'features/all_tasks.dart';
import 'features/messages.dart';
import 'features/appointments.dart';
import 'features/compose.dart';
import 'features/follow_up.dart';
import 'features/letters.dart';
import 'features/my_face.dart';
import 'features/my_tasks.dart';
import 'features/roles.dart';
import 'features/sent.dart';

class _Section {
  const _Section(this.label, this.icon, this.permission, this.build);

  final String label;
  final IconData icon;
  final String permission;
  final Widget Function(Session session, Listenable refresh) build;
}

/// كل عنصر يظهر بصلاحيته، فكل مستخدم يشوف واجهته هو فقط.
final _sections = <_Section>[
  _Section('محضر جديد', Icons.edit_note, 'meetings.write', (s, _) => MeetingScreen(api: s.api)),
  _Section('الكتب', Icons.description_outlined, 'letters.read',
      (s, r) => LettersScreen(api: s.api, refresh: r, canWrite: s.me!.can('letters.write'))),
  _Section('المواعيد', Icons.event, 'appointments.write', (s, r) => AppointmentsScreen(api: s.api)),
  _Section('اللوحة', Icons.dashboard_outlined, 'performance.read', (s, r) => DashboardScreen(api: s.api, refresh: r)),
  _Section('المراجعة', Icons.fact_check_outlined, 'tasks.review', (s, r) => ReviewScreen(api: s.api, refresh: r)),
  _Section('الالتزام', Icons.insights, 'performance.read', (s, _) => PerformanceScreen(api: s.api)),
  _Section('إرسال مهمة', Icons.send_outlined, 'tasks.create', (s, _) => SendTaskScreen(api: s.api)),
  _Section('ما أرسلته', Icons.outbox_outlined, 'tasks.create', (s, r) => SentScreen(api: s.api, refresh: r)),
  _Section('كل المهام', Icons.swap_horiz, 'tasks.reassign',
      (s, r) => AllTasksScreen(api: s.api, refresh: r, canCancel: s.me!.can('tasks.cancel'))),
  _Section('مهامي', Icons.task_alt, 'tasks.read_own', (s, r) => MyTasksScreen(api: s.api, refresh: r)),
  _Section('الرسائل', Icons.chat_bubble_outline, 'tasks.read_own',
      (s, r) => MessagesScreen(api: s.api, refresh: r, myId: s.me!.id, canPickPeople: s.me!.can('directory.read'))),
  _Section('الموظفون', Icons.group_outlined, 'users.manage', (s, _) => UsersScreen(api: s.api)),
  _Section('الرتب', Icons.admin_panel_settings_outlined, 'roles.manage', (s, _) => RolesScreen(api: s.api)),
];

class Shell extends StatefulWidget {
  const Shell({super.key, required this.session, required this.push});

  final Session session;
  final PushClient push;

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  final _refresh = ChangeNotifier();
  final _rings = <String, Timer>{};
  Timer? _tick;
  late final List<StreamSubscription<dynamic>> _subscriptions;
  Alert? _urgent;
  int _index = 0;

  List<_Section> get _visible {
    final me = widget.session.me!;
    return _sections.where((s) => me.can(s.permission)).toList();
  }

  @override
  void initState() {
    super.initState();
    widget.push.start();
    _subscriptions = [widget.push.alerts.listen(_onAlert), widget.push.dismissed.listen(_onDismissed)];
    // Every screen also reloads each minute: what someone else did shows up even without an alert to this user.
    // ignore: invalid_use_of_protected_member, invalid_use_of_visible_for_testing_member
    _tick = Timer.periodic(const Duration(minutes: 1), (_) => _refresh.notifyListeners());
  }

  void _onAlert(Alert alert) {
    // ignore: invalid_use_of_protected_member, invalid_use_of_visible_for_testing_member
    _refresh.notifyListeners();
    SystemSound.play(SystemSoundType.alert);
    if (alert.high) {
      _ring(alert);
      if (isDesktop) {
        windowManager.show();
        windowManager.focus();
        windowManager.setAlwaysOnTop(true);
      }
      setState(() => _urgent = alert);
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(alert.text)));
    }
  }

  /// رنين متكرر لمدة دقيقة، والسيرفر يعيد التنبيه بعدها إذا لم تُفتح.
  void _ring(Alert alert) {
    _rings[alert.id]?.cancel();
    var left = 30;
    _rings[alert.id] = Timer.periodic(const Duration(seconds: 2), (timer) {
      SystemSound.play(SystemSoundType.alert);
      if (--left <= 0) timer.cancel();
    });
  }

  void _onDismissed(String id) {
    _rings.remove(id)?.cancel();
    if (_urgent?.id == id) _clearUrgent();
    // ignore: invalid_use_of_protected_member, invalid_use_of_visible_for_testing_member
    _refresh.notifyListeners();
  }

  void _clearUrgent() {
    if (isDesktop) windowManager.setAlwaysOnTop(false);
    if (mounted) setState(() => _urgent = null);
  }

  /// ضغطة واحدة تفتح نفس المهمة: السيرفر يسجّل وقت الفتح ويوقف الرنين بكل الأجهزة.
  Future<void> _openUrgent() async {
    final alert = _urgent!;
    final tasks = _visible.indexWhere((s) => s.permission == 'tasks.read_own');
    final opened = alert.taskId == null ||
        await attempt(context, () => widget.session.api.post('/tasks/${alert.taskId}/open'));
    if (!opened || !mounted) return;
    _rings.remove(alert.id)?.cancel();
    setState(() {
      _index = tasks < 0 ? 0 : tasks;
      _urgent = null;
    });
    if (isDesktop) windowManager.setAlwaysOnTop(false);
    // ignore: invalid_use_of_protected_member, invalid_use_of_visible_for_testing_member
    _refresh.notifyListeners();
  }

  @override
  void dispose() {
    _tick?.cancel();
    for (final subscription in _subscriptions) {
      subscription.cancel();
    }
    for (final ring in _rings.values) {
      ring.cancel();
    }
    _refresh.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final sections = _visible;
    final index = _index.clamp(0, sections.isEmpty ? 0 : sections.length - 1);
    final form = formFactor(context);
    final phone = form == FormFactor.phone;
    final content = sections.isEmpty
        ? const Empty('حسابك بلا صلاحيات بعد')
        : KeyedSubtree(key: ValueKey(sections[index].label), child: sections[index].build(widget.session, _refresh));
    Widget sidebar(bool inDrawer) => _Sidebar(
          sections: sections,
          index: index,
          me: widget.session.me!,
          push: widget.push,
          onPick: (i) {
            setState(() => _index = i);
            if (inDrawer) Navigator.pop(context);
          },
          onLogout: widget.session.logout,
          onFace: () => showMyFace(context, widget.session.api),
        );
    // الهاتف: شريط علوي باسم القسم، والأقسام بقائمة تنسحب من الجنب. الكمبيوتر: الشريط الجانبي ثابت.
    return Scaffold(
      appBar: phone
          ? AppBar(
              backgroundColor: Ink2.ink,
              foregroundColor: Colors.white,
              title: Text(sections.isEmpty ? 'نظام المكتب' : sections[index].label, style: const TextStyle(fontWeight: FontWeight.w800)),
              actions: [
                ListenableBuilder(
                  listenable: widget.push,
                  builder: (context, _) => Padding(
                    padding: const EdgeInsetsDirectional.only(end: 16),
                    child: Icon(Icons.circle, size: 10, color: widget.push.connected ? const Color(0xFF22C55E) : const Color(0xFFF59E0B)),
                  ),
                ),
              ],
            )
          : null,
      drawer: phone ? Drawer(width: 236, shape: const RoundedRectangleBorder(), child: sidebar(true)) : null,
      body: Stack(
        children: [
          if (phone)
            content
          else
            Row(children: [
              if (form == FormFactor.tablet)
                _Rail(
                  sections: sections,
                  index: index,
                  me: widget.session.me!,
                  push: widget.push,
                  onPick: (i) => setState(() => _index = i),
                  onLogout: widget.session.logout,
                  onFace: () => showMyFace(context, widget.session.api),
                )
              else
                sidebar(false),
              Expanded(child: content),
            ]),
          if (_urgent != null) _UrgentCover(alert: _urgent!, onOpen: _openUrgent),
        ],
      ),
    );
  }
}

class _Sidebar extends StatelessWidget {
  const _Sidebar({required this.sections, required this.index, required this.me, required this.push,
      required this.onPick, required this.onLogout, required this.onFace});

  final List<_Section> sections;
  final int index;
  final Me me;
  final PushClient push;
  final ValueChanged<int> onPick;
  final VoidCallback onLogout;
  final VoidCallback onFace;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 236,
      color: Ink2.ink,
      child: CustomPaint(
        painter: const StarPattern(),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 24, 14, 16),
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 0, 8, 22),
            child: Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(border: Border.all(color: Ink2.khaki, width: 1.5)),
                  child: const CustomPaint(painter: StarEmblem()),
                ),
                const SizedBox(width: 10),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('نظام المكتب', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900)),
                    Text('مكتب الشخصية', style: TextStyle(color: Ink2.khaki, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
                  ],
                ),
              ],
            ),
          ),
          for (var i = 0; i < sections.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 2),
              child: Material(
                color: i == index ? Ink2.blue : Colors.transparent,
                child: InkWell(
                  onTap: () => onPick(i),
                  child: Container(
                    height: 44,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      border: BorderDirectional(start: BorderSide(color: i == index ? Ink2.khaki : Colors.transparent, width: 4)),
                    ),
                    child: Row(
                      children: [
                        Icon(sections[i].icon, size: 20, color: i == index ? Colors.white : const Color(0xFFC9C4AE)),
                        const SizedBox(width: 10),
                        Text(sections[i].label,
                            style: TextStyle(color: i == index ? Colors.white : const Color(0xFFC9C4AE), fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          const Spacer(),
          ListenableBuilder(
            listenable: push,
            builder: (context, _) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Row(
                children: [
                  Icon(Icons.circle, size: 9, color: push.connected ? const Color(0xFF22C55E) : const Color(0xFFF59E0B)),
                  const SizedBox(width: 8),
                  Text(push.connected ? 'متصل بالمكتب' : 'غير متصل',
                      style: const TextStyle(color: Color(0xFFD6D5D0), fontSize: 13)),
                ],
              ),
            ),
          ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            padding: const EdgeInsets.only(top: 10),
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: Color(0x33B9A779)))),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(me.fullName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                if (me.roleName != null) Text(me.roleName!, style: const TextStyle(color: Ink2.khaki, fontSize: 12, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
          Row(
            children: [
              TextButton.icon(
                onPressed: onFace,
                icon: const Icon(Icons.face_outlined, size: 18),
                style: TextButton.styleFrom(foregroundColor: const Color(0xFFC9C4AE)),
                label: const Text('بصمة الوجه'),
              ),
              const Spacer(),
              TextButton(
                onPressed: onLogout,
                style: TextButton.styleFrom(foregroundColor: const Color(0xFFC9C4AE)),
                child: const Text('خروج'),
              ),
            ],
          ),
        ],
          ),
        ),
      ),
    );
  }
}

/// التابلت: شريط ضيق، أيقونة وتحتها اسم القسم صغير، حتى تبقى المساحة للمحتوى.
class _Rail extends StatelessWidget {
  const _Rail({required this.sections, required this.index, required this.me, required this.push,
      required this.onPick, required this.onLogout, required this.onFace});

  final List<_Section> sections;
  final int index;
  final Me me;
  final PushClient push;
  final ValueChanged<int> onPick;
  final VoidCallback onLogout;
  final VoidCallback onFace;

  @override
  Widget build(BuildContext context) {
    const dim = Color(0xFFC9C4AE);
    return Container(
      width: 92,
      color: Ink2.ink,
      child: CustomPaint(
        painter: const StarPattern(),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 14),
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(border: Border.all(color: Ink2.khaki, width: 1.5)),
                child: const CustomPaint(painter: StarEmblem()),
              ),
              const SizedBox(height: 14),
              Expanded(
                child: ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    for (var i = 0; i < sections.length; i++)
                      Material(
                        color: i == index ? Ink2.blue : Colors.transparent,
                        child: InkWell(
                          onTap: () => onPick(i),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                            decoration: BoxDecoration(
                              border: BorderDirectional(start: BorderSide(color: i == index ? Ink2.khaki : Colors.transparent, width: 4)),
                            ),
                            child: Column(
                              children: [
                                Icon(sections[i].icon, size: 22, color: i == index ? Colors.white : dim),
                                const SizedBox(height: 4),
                                Text(sections[i].label,
                                    textAlign: TextAlign.center,
                                    maxLines: 2,
                                    style: TextStyle(fontSize: 11.5, height: 1.2, fontWeight: FontWeight.w700, color: i == index ? Colors.white : dim)),
                              ],
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              ListenableBuilder(
                listenable: push,
                builder: (context, _) => Tooltip(
                  message: push.connected ? 'متصل بالمكتب' : 'غير متصل',
                  child: Icon(Icons.circle, size: 9, color: push.connected ? const Color(0xFF22C55E) : const Color(0xFFF59E0B)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                child: Text(me.fullName, textAlign: TextAlign.center, maxLines: 2, style: const TextStyle(color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w800)),
              ),
              IconButton(onPressed: onFace, tooltip: 'بصمة الوجه', icon: const Icon(Icons.face_outlined, color: dim)),
              IconButton(onPressed: onLogout, tooltip: 'خروج', icon: const Icon(Icons.logout, color: dim)),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }
}

class _UrgentCover extends StatelessWidget {
  const _UrgentCover({required this.alert, required this.onOpen});

  final Alert alert;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: ColoredBox(
        color: Ink2.ink,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 112,
                height: 112,
                decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: const Color(0xFFF97316), width: 3)),
                child: const Icon(Icons.notifications_active_outlined, size: 48, color: Color(0xFFF97316)),
              ),
              const SizedBox(height: 24),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text(alert.text,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white, fontSize: formFactor(context) == FormFactor.phone ? 28 : 40, fontWeight: FontWeight.w700)),
              ),
              const SizedBox(height: 6),
              const Text('الرنين يتوقف عند فتحها', style: TextStyle(color: Color(0xFFD6D5D0), fontSize: 18)),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: onOpen,
                style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Ink2.ink, minimumSize: const Size(220, 60)),
                child: const Text('افتح المهمة', style: TextStyle(fontSize: 20)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
