import 'package:flutter/material.dart';
import 'package:window_manager/window_manager.dart';

import 'core/api.dart';
import 'core/platform.dart';
import 'core/push.dart';
import 'core/session.dart';
import 'core/store.dart';
import 'core/ui.dart';
import 'features/login.dart';
import 'shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (isDesktop) {
    await windowManager.ensureInitialized();
    // النافذة تصغر لحد حجم الهاتف، والشكل يتبدّل وحده (هاتف، تابلت، كمبيوتر).
    await windowManager.setMinimumSize(const Size(360, 560));
    final size = switch (preview) {
      'phone' => const Size(400, 860), // هاتف عادي 6.1 إنچ
      'tablet' => const Size(820, 1000), // تابلت 11 إنچ بالطول
      _ => null,
    };
    await windowManager.setTitle(size == null ? 'نظام المكتب' : 'نظام المكتب (شكل ${preview == 'phone' ? 'الهاتف' : 'التابلت'})');
    if (size != null) {
      await windowManager.setSize(size);
      await windowManager.center();
    }
  }

  final store = await Store.open();
  final session = Session(Api(store));
  runApp(OfficeApp(session: session, push: PushClient(store)));
  await session.restore();
}

class OfficeApp extends StatelessWidget {
  const OfficeApp({super.key, required this.session, required this.push});

  final Session session;
  final PushClient push;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'نظام المكتب',
      debugShowCheckedModeBanner: false,
      theme: appTheme(),
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      home: ListenableBuilder(
        listenable: session,
        builder: (context, _) {
          if (session.restoring) return const Scaffold(body: Center(child: CircularProgressIndicator()));
          if (session.me == null) {
            push.stop();
            return LoginScreen(session: session);
          }
          return Shell(session: session, push: push);
        },
      ),
    );
  }
}
