import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';

import 'api.dart';
import 'store.dart';

class Me {
  Me(this.id, this.fullName, this.roleCode, this.permissions, [this.roleName]);

  factory Me.fromJson(Map<String, dynamic> json) => Me(json['id'] as String, json['full_name'] as String,
      json['role_code'] as String, (json['permissions'] as List).cast<String>().toSet(), json['role_name'] as String?);

  final String id;
  final String fullName;
  final String roleCode;
  /// الرتبة كما تنكتب (مدير المكتب، السكرتير…)، تطلع تحت الاسم.
  final String? roleName;
  final Set<String> permissions;

  /// كل قرار بالواجهة يأتي من هنا، لا من اسم الدور، فالأدوار الجديدة تعمل بلا تعديل.
  bool can(String permission) => permissions.contains(permission);
}

class Session extends ChangeNotifier {
  Session(this.api) {
    api.onSessionEnded = () => unawaited(_end());
  }

  final Api api;
  Me? me;
  bool restoring = true;

  Store get store => api.store;

  Future<void> restore() async {
    try {
      if (store.accessToken != null) {
        me = Me.fromJson(await api.get('/me') as Map<String, dynamic>);
      }
    } on ApiError {
      me = null;
    }
    restoring = false;
    notifyListeners();
  }

  Map<String, dynamic> get _device => {
        if (store.deviceId != null) 'id': store.deviceId,
        'platform': Platform.isAndroid ? 'android' : 'windows',
        'name': Platform.localHostname,
      };

  Future<void> login(String username, String password) async {
    await _signedIn(await api.post('/auth/login', {'username': username, 'password': password, 'device': _device}) as Map<String, dynamic>);
  }

  /// الدخول بالوجه: صورة من الكاميرا، والسيرفر يعرف صاحبها.
  Future<void> loginWithFace(String image) async {
    await _signedIn(await api.post('/auth/face', {'image': image, 'device': _device}) as Map<String, dynamic>);
  }

  Future<void> _signedIn(Map<String, dynamic> tokens) async {
    await store.saveTokens(
      access: tokens['access_token'] as String,
      refresh: tokens['refresh_token'] as String,
      push: tokens['push_token'] as String?,
      device: tokens['device_id'] as String,
    );
    me = Me.fromJson(await api.get('/me') as Map<String, dynamic>);
    notifyListeners();
  }

  Future<void> logout() async {
    try {
      await api.post('/auth/logout');
    } on ApiError {
      // السيرفر غير متاح: الخروج من هذا الجهاز يبقى صحيحاً
    }
    await _end();
  }

  Future<void> _end() async {
    await store.clearSession();
    me = null;
    notifyListeners();
  }
}
