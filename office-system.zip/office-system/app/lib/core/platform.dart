import 'dart:io';

import 'package:flutter/widgets.dart';

/// كمبيوتر (نافذة وتنبيه فوق كل النوافذ) أو هاتف.
final bool isDesktop = Platform.isWindows || Platform.isLinux || Platform.isMacOS;

/// تجربة شكل الهاتف أو التابلت على الكمبيوتر: flutter run -d windows --dart-define=PREVIEW=phone (أو tablet)
const String preview = String.fromEnvironment('PREVIEW');

/// ثلاث أحجام: هاتف (تحت 600)، تابلت (600 إلى 1000)، كمبيوتر.
const double phoneWidth = 600;
const double tabletWidth = 1000;

enum FormFactor { phone, tablet, desktop }

FormFactor formFactor(BuildContext context) {
  final width = MediaQuery.sizeOf(context).width;
  return width < phoneWidth ? FormFactor.phone : width < tabletWidth ? FormFactor.tablet : FormFactor.desktop;
}

/// الهامش حول الصفحة حسب الحجم.
double pagePadding(BuildContext context) => switch (formFactor(context)) {
      FormFactor.phone => 12,
      FormFactor.tablet => 24,
      FormFactor.desktop => 40,
    };
