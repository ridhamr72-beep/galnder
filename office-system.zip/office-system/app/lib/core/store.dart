import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// جلسة هذا الجهاز في ملف بمجلد المستخدم. ملف Windows خاص بالحساب؛ على الهاتف يُستبدل بـ Keystore.
class Store {
  Store(this._file, this._data);

  final File? _file;
  final Map<String, dynamic> _data;

  static Future<Store> open() async {
    final dir = await getApplicationSupportDirectory();
    final file = File('${dir.path}${Platform.pathSeparator}session.json');
    final data = await file.exists()
        ? jsonDecode(await file.readAsString()) as Map<String, dynamic>
        : <String, dynamic>{};
    return Store(file, data);
  }

  factory Store.memory() => Store(null, {});

  String? get accessToken => _data['access'] as String?;
  String? get refreshToken => _data['refresh'] as String?;
  String? get pushToken => _data['push'] as String?;
  String? get deviceId => _data['device'] as String?;
  int get lastSeq => (_data['seq'] as int?) ?? 0;

  Future<void> saveTokens({required String access, required String refresh, String? push, String? device}) async {
    _data['access'] = access;
    _data['refresh'] = refresh;
    if (push != null) _data['push'] = push;
    if (device != null) _data['device'] = device;
    await _save();
  }

  Future<void> saveSeq(int seq) async {
    if (seq <= lastSeq) return;
    _data['seq'] = seq;
    await _save();
  }

  /// يبقي معرّف الجهاز، حتى لا يُحسب كل دخول جهازاً جديداً.
  Future<void> clearSession() async {
    _data
      ..remove('access')
      ..remove('refresh')
      ..remove('push');
    await _save();
  }

  Future<void> _save() async => _file?.writeAsString(jsonEncode(_data));
}
