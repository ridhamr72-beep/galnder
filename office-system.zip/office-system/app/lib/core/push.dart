import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';

import 'api.dart';
import 'store.dart';

class Alert {
  Alert(this.id, this.seq, this.kind, this.level, this.taskId);

  final String id;
  final int seq;
  final String kind;
  final String level;
  final String? taskId;

  bool get high => level == 'high';

  /// النصّ ثابت هنا عمداً: الإشعار لا يحمل أيّ شيء من المهمة.
  String get text => switch (kind) {
        'task_assigned' => 'وصلتك مهمة جديدة',
        'task_reminder' => 'تذكير بمهمة',
        'task_returned' => 'رجعت لك مهمة',
        'review_needed' => 'مهمة بانتظار مراجعتك',
        'message' => 'وصلتك رسالة',
        'task_closed' => 'انقبلت مهمتك وتسكّرت',
        'task_extended' => 'تغيّر موعد مهمة عندك',
        'task_cancelled' => 'انلغت مهمة عندك',
        'task_reassigned' => 'تحوّلت مهمة منك لغيرك',
        'appointment' => 'موعد جديد للشخصية',
        _ => 'إشعار جديد',
      };
}

/// اتصال دائم بالسيرفر: يستلم الإشعارات ويؤكد وصولها. لا خدمة خارجية.
class PushClient extends ChangeNotifier {
  PushClient(this.store);

  final Store store;
  final _alerts = StreamController<Alert>.broadcast();
  final _dismissed = StreamController<String>.broadcast();

  WebSocket? _socket;
  Timer? _retry;
  bool _running = false;
  int _delay = 1;
  bool connected = false;

  Stream<Alert> get alerts => _alerts.stream;
  Stream<String> get dismissed => _dismissed.stream;

  void start() {
    if (_running) return;
    _running = true;
    _connect();
  }

  void stop() {
    _running = false;
    _retry?.cancel();
    _socket?.close();
    _socket = null;
    _setConnected(false);
  }

  void _setConnected(bool value) {
    if (connected == value) return;
    connected = value;
    notifyListeners();
  }

  Future<void> _connect() async {
    final token = store.pushToken;
    if (!_running || token == null) return;
    try {
      final url = '${apiUrl.replaceFirst('http', 'ws')}/api/v1/ws';
      final socket = await WebSocket.connect(url, headers: {'Authorization': 'Bearer $token'});
      _socket = socket;
      _delay = 1;
      _setConnected(true);
      socket.add(jsonEncode({'type': 'hello', 'last_seq': store.lastSeq}));
      socket.listen(_onMessage, onDone: _reconnect, onError: (_) => _reconnect(), cancelOnError: true);
    } on Exception {
      _reconnect();
    }
  }

  void _reconnect() {
    _setConnected(false);
    if (!_running) return;
    _retry?.cancel();
    _retry = Timer(Duration(seconds: _delay), _connect);
    _delay = (_delay * 2).clamp(1, 30);
  }

  void _onMessage(dynamic raw) {
    final message = jsonDecode(raw as String) as Map<String, dynamic>;
    switch (message['type']) {
      case 'ping':
        _socket?.add(jsonEncode({'type': 'pong'}));
      case 'dismiss':
        _dismissed.add(message['id'] as String);
      case 'notify':
        final alert = Alert(message['id'] as String, message['seq'] as int, message['kind'] as String,
            message['level'] as String, message['task_id'] as String?);
        _socket?.add(jsonEncode({'type': 'ack', 'id': alert.id}));
        store.saveSeq(alert.seq);
        _alerts.add(alert);
    }
  }

  @override
  void dispose() {
    stop();
    _alerts.close();
    _dismissed.close();
    super.dispose();
  }
}
