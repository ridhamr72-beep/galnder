import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'api.dart';
import 'platform.dart';

/// ألوان المكتب: زيتوني غامق للقيادة، رملي للأرضية، خاكي للتمييز، وأحمر قاتم للعاجل. زوايا حادة وخطوط رفيعة.
abstract final class Ink2 {
  static const ground = Color(0xFFE9E6DC);
  static const ink = Color(0xFF1B2016);
  static const muted = Color(0xFF5B5F4E);
  static const line = Color(0xFFCBC6B2);
  /// اللون الأساسي (الأزرار والتحديد): زيتوني.
  static const blue = Color(0xFF4A5A2C);
  static const khaki = Color(0xFFB9A779);
  static const high = Color(0xFF9B1C1C);
  static const good = Color(0xFF3F6212);
  static const warn = Color(0xFF9A6A10);
}

const _sharp = BorderRadius.all(Radius.circular(4));

ThemeData appTheme() {
  const border = OutlineInputBorder(borderRadius: _sharp, borderSide: BorderSide(color: Ink2.line));
  return ThemeData(
    useMaterial3: true,
    fontFamily: 'Cairo',
    fontFamilyFallback: const ['Segoe UI', 'Tahoma'],
    scaffoldBackgroundColor: Ink2.ground,
    colorScheme: ColorScheme.fromSeed(seedColor: Ink2.blue, primary: Ink2.blue, secondary: Ink2.khaki, surface: const Color(0xFFF6F4EC), error: Ink2.high),
    dividerColor: Ink2.line,
    dialogTheme: const DialogThemeData(shape: RoundedRectangleBorder(borderRadius: _sharp), backgroundColor: Color(0xFFF6F4EC)),
    snackBarTheme: const SnackBarThemeData(backgroundColor: Ink2.ink, shape: RoundedRectangleBorder(borderRadius: _sharp), behavior: SnackBarBehavior.floating),
    chipTheme: const ChipThemeData(shape: RoundedRectangleBorder(borderRadius: _sharp), side: BorderSide(color: Ink2.line), selectedColor: Color(0xFFD9D3B8)),
    textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(foregroundColor: Ink2.blue, textStyle: const TextStyle(fontWeight: FontWeight.w700, fontFamily: 'Cairo'))),
    inputDecorationTheme: const InputDecorationTheme(
      filled: true,
      fillColor: Color(0xFFF6F4EC),
      border: border,
      enabledBorder: border,
      focusedBorder: OutlineInputBorder(borderRadius: _sharp, borderSide: BorderSide(color: Ink2.blue, width: 2)),
      contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 14),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size(44, 48),
        padding: const EdgeInsets.symmetric(horizontal: 24),
        backgroundColor: Ink2.blue,
        shape: const RoundedRectangleBorder(borderRadius: _sharp),
        textStyle: const TextStyle(fontWeight: FontWeight.w800, fontFamily: 'Cairo'),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(44, 48),
        foregroundColor: Ink2.ink,
        side: const BorderSide(color: Ink2.ink, width: 1.2),
        shape: const RoundedRectangleBorder(borderRadius: _sharp),
        textStyle: const TextStyle(fontWeight: FontWeight.w700, fontFamily: 'Cairo'),
      ),
    ),
  );
}

/// رأس الصفحة وعرضها، حتى تتشابه كل الشاشات.
class PageFrame extends StatelessWidget {
  const PageFrame({super.key, required this.title, this.subtitle, this.action, required this.child});

  final String title;
  final String? subtitle;
  final Widget? action;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    // الهاتف: هوامش صغيرة، والعنوان بالشريط العلوي فما يتكرر هنا.
    if (formFactor(context) == FormFactor.phone) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (subtitle != null) Text(subtitle!, style: const TextStyle(color: Ink2.muted, fontSize: 14)),
            if (action != null) Padding(padding: const EdgeInsets.only(top: 8), child: Align(alignment: AlignmentDirectional.centerStart, child: action!)),
            if (subtitle != null || action != null) const SizedBox(height: 12),
            Expanded(child: child),
          ],
        ),
      );
    }
    final pad = pagePadding(context);
    return Padding(
      padding: EdgeInsets.fromLTRB(pad, pad * 0.8, pad, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: -0.2)),
                    Container(width: 56, height: 4, margin: const EdgeInsets.only(top: 4, bottom: 6), color: Ink2.khaki),
                    if (subtitle != null)
                      Text(subtitle!, style: const TextStyle(color: Ink2.muted, fontSize: 15)),
                  ],
                ),
              ),
              if (action != null) action!,
            ],
          ),
          const SizedBox(height: 20),
          Expanded(child: child),
        ],
      ),
    );
  }
}

class Panel extends StatelessWidget {
  const Panel({super.key, required this.child, this.color = Colors.white});

  final Widget child;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final plain = color == Colors.white;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: plain ? const Color(0xFFF6F4EC) : color,
        borderRadius: _sharp,
        border: Border.all(color: plain ? Ink2.line : color),
      ),
      child: child,
    );
  }
}

class Tag extends StatelessWidget {
  const Tag(this.text, {super.key, this.color = Ink2.muted});

  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.08), borderRadius: _sharp, border: Border.all(color: color.withValues(alpha: 0.6))),
      child: Text(text, style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w800)),
    );
  }
}

/// يحمّل بيانات شاشة، ويعرض التحميل والخطأ بنفس الشكل، ويعيد التحميل بـ reload.
class Loader<T> extends StatefulWidget {
  const Loader({super.key, required this.load, required this.builder, this.refresh});

  final Future<T> Function() load;
  final Widget Function(BuildContext context, T data, VoidCallback reload) builder;

  /// يتغيّر عند وصول إشعار، فتتحدث الشاشة وحدها.
  final Listenable? refresh;

  @override
  State<Loader<T>> createState() => _LoaderState<T>();
}

class _LoaderState<T> extends State<Loader<T>> {
  late Future<T> _future = widget.load();

  void _reload() {
    if (!mounted) return;
    setState(() {
      _future = widget.load();
    });
  }

  @override
  void initState() {
    super.initState();
    widget.refresh?.addListener(_reload);
  }

  @override
  void dispose() {
    widget.refresh?.removeListener(_reload);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<T>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('${snapshot.error}', style: const TextStyle(color: Ink2.muted)),
                const SizedBox(height: 12),
                OutlinedButton(onPressed: _reload, child: const Text('حاول مرة ثانية')),
              ],
            ),
          );
        }
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        return widget.builder(context, snapshot.data as T, _reload);
      },
    );
  }
}

class Empty extends StatelessWidget {
  const Empty(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) => Center(child: Text(text, style: const TextStyle(color: Ink2.muted, fontSize: 16)));
}

/// ينفّذ فعلاً ويعرض خطأه للمستخدم بجملة مفهومة.
Future<bool> attempt(BuildContext context, Future<void> Function() action) async {
  try {
    await action();
    return true;
  } on ApiError catch (error) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
    }
    return false;
  }
}

String shortTime(String? iso) {
  if (iso == null) return '-';
  final t = DateTime.parse(iso).toLocal();
  String two(int n) => n.toString().padLeft(2, '0');
  return '${t.day}/${t.month} ${two(t.hour)}:${two(t.minute)}';
}

String duration(num? seconds) {
  if (seconds == null) return '-';
  final minutes = (seconds / 60).round();
  if (minutes < 60) return '${minutes < 1 ? 1 : minutes} دقيقة';
  final hours = (minutes / 60).round();
  return hours < 48 ? '$hours ساعة' : '${(hours / 24).round()} يوم';
}

const statusLabels = {
  'assigned': 'لم تُفتح',
  'opened': 'فُتحت',
  'in_progress': 'قيد التنفيذ',
  'submitted': 'سُلّمت، تنتظر الموافقة',
  'returned': 'مرجَّعة',
  'closed': 'منتهية',
  'cancelled': 'ملغاة',
};

/// العدّاد: كم باقي على الموعد، أخضر ثم خاكي (أقل من 6 ساعات) ثم أحمر (أقل من ساعة أو فات). يتحدث كل نص دقيقة.
class Countdown extends StatefulWidget {
  const Countdown(this.dueIso, {super.key});

  final String? dueIso;

  @override
  State<Countdown> createState() => _CountdownState();
}

class _CountdownState extends State<Countdown> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => setState(() {}));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final due = DateTime.tryParse(widget.dueIso ?? '')?.toLocal();
    if (due == null) return const SizedBox.shrink();
    final left = due.difference(DateTime.now());
    final late = left.isNegative;
    final abs = left.abs();
    final text = abs.inDays >= 1
        ? '${abs.inDays} يوم ${abs.inHours % 24} س'
        : abs.inHours >= 1
            ? '${abs.inHours} س ${abs.inMinutes % 60} د'
            : '${math.max(1, abs.inMinutes)} د';
    final color = late || left.inMinutes < 60 ? Ink2.high : left.inHours < 6 ? Ink2.warn : Ink2.good;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(color: color, borderRadius: _sharp),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.timer_outlined, size: 14, color: Colors.white),
          const SizedBox(width: 4),
          Text(late ? 'متأخرة $text' : 'باقي $text',
              style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800, fontFeatures: [FontFeature.tabularFigures()])),
        ],
      ),
    );
  }
}

/// نقش هندسي إسلامي (نجمة ثمانية متكررة) خفيف، لخلفية الشريط الجانبي.
class StarPattern extends CustomPainter {
  const StarPattern({this.color = const Color(0x0DB9A779)});

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.clipRect(Offset.zero & size);
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    const cell = 46.0;
    for (var y = -cell / 2; y < size.height + cell; y += cell) {
      for (var x = -cell / 2; x < size.width + cell; x += cell) {
        final c = Offset(x, y);
        // نجمة ثمانية: مربعين متداخلين بزاوية 45 درجة.
        for (final turn in [0.0, math.pi / 4]) {
          final path = Path();
          for (var k = 0; k < 4; k++) {
            final a = turn + k * math.pi / 2;
            final p = c + Offset(math.cos(a), math.sin(a)) * (cell * 0.38);
            k == 0 ? path.moveTo(p.dx, p.dy) : path.lineTo(p.dx, p.dy);
          }
          path.close();
          canvas.drawPath(path, paint);
        }
      }
    }
  }

  @override
  bool shouldRepaint(StarPattern oldDelegate) => oldDelegate.color != color;
}

/// شعار المكتب: نجمة ثمانية واحدة بالنص، بلا رموز جهة معيّنة.
class StarEmblem extends CustomPainter {
  const StarEmblem({this.color = Ink2.khaki});

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.shortestSide * 0.36;
    final stroke = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6;
    for (final turn in [0.0, math.pi / 4]) {
      final path = Path();
      for (var k = 0; k < 4; k++) {
        final a = turn + k * math.pi / 2;
        final p = c + Offset(math.cos(a), math.sin(a)) * r;
        k == 0 ? path.moveTo(p.dx, p.dy) : path.lineTo(p.dx, p.dy);
      }
      path.close();
      canvas.drawPath(path, stroke);
    }
    canvas.drawCircle(c, r * 0.28, Paint()..color = color);
  }

  @override
  bool shouldRepaint(StarEmblem oldDelegate) => oldDelegate.color != color;
}

/// بطاقة فيها كلام وأزرار: بالكمبيوتر والتابلت الأزرار يمّ الكلام، وبالهاتف تنزل تحته،
/// حتى ما ينضغط العنوان حرف بسطر.
class CardRow extends StatelessWidget {
  const CardRow({super.key, required this.body, this.actions = const [], this.leading});

  final Widget body;
  final List<Widget> actions;
  /// شي صغير قبل الكلام (وقت الموعد مثلاً): بالهاتف يصير فوق الكلام.
  final Widget? leading;

  @override
  Widget build(BuildContext context) {
    if (formFactor(context) == FormFactor.phone) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (leading != null) Padding(padding: const EdgeInsets.only(bottom: 6), child: Align(alignment: AlignmentDirectional.centerStart, child: leading!)),
          body,
          if (actions.isNotEmpty) ...[
            const SizedBox(height: 12),
            Wrap(alignment: WrapAlignment.end, crossAxisAlignment: WrapCrossAlignment.center, spacing: 8, runSpacing: 8, children: actions),
          ],
        ],
      );
    }
    return Row(
      children: [
        if (leading != null) ...[leading!, const SizedBox(width: 16)],
        Expanded(child: body),
        for (final (i, action) in actions.indexed) ...[SizedBox(width: i > 0 ? 8 : 12), action],
      ],
    );
  }
}
