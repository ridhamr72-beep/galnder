import 'dart:convert';

import 'package:http/http.dart' as http;

import 'store.dart';

/// عنوان خادم المكتب. يُحدَّد وقت البناء:
/// flutter build windows --dart-define=API_URL=http://<جهاز-الخادم>:8000
const apiUrl = String.fromEnvironment('API_URL', defaultValue: 'http://127.0.0.1:8000');

class ApiError implements Exception {
  ApiError(this.status, this.code, this.message);

  final int status;
  final String code;
  final String message;

  @override
  String toString() => message;
}

class Api {
  Api(this.store, {http.Client? client}) : _client = client ?? http.Client();

  final Store store;
  final http.Client _client;
  void Function()? onSessionEnded;

  Uri _uri(String path, [Map<String, String>? query]) =>
      Uri.parse('$apiUrl/api/v1$path').replace(queryParameters: query);

  Future<dynamic> get(String path, [Map<String, String>? query]) => _send('GET', path, query: query);

  Future<dynamic> post(String path, [Map<String, dynamic>? body]) => _send('POST', path, body: body);

  Future<dynamic> patch(String path, Map<String, dynamic> body) => _send('PATCH', path, body: body);

  Future<dynamic> delete(String path) => _send('DELETE', path);

  /// عنصر items من ردّ قائمة.
  Future<List<Map<String, dynamic>>> list(String path, [Map<String, String>? query]) async {
    final data = await get(path, query) as Map<String, dynamic>;
    return (data['items'] as List).cast<Map<String, dynamic>>();
  }

  /// صورة مرفقة كما هي.
  Future<List<int>> bytes(String path) async {
    final response = await _client.get(_uri(path), headers: {'Authorization': 'Bearer ${store.accessToken}'});
    if (response.statusCode >= 400) throw ApiError(response.statusCode, 'error', 'ما كدرنا نجيب الصورة');
    return response.bodyBytes;
  }

  /// يرفع ملفاً واحداً كـ multipart باسم `file`.
  Future<dynamic> upload(String path, String filePath) async {
    final request = http.MultipartRequest('POST', _uri(path))
      ..headers['Authorization'] = 'Bearer ${store.accessToken}'
      ..files.add(await http.MultipartFile.fromPath('file', filePath));
    final response = await http.Response.fromStream(await _client.send(request));
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (response.statusCode >= 400) {
      final error = (decoded as Map)['error'] as Map<String, dynamic>?;
      throw ApiError(response.statusCode, error?['code'] as String? ?? 'error', error?['message'] as String? ?? 'صار خطأ');
    }
    return decoded;
  }

  Future<dynamic> _send(String method, String path,
      {Map<String, String>? query, Map<String, dynamic>? body, bool retried = false}) async {
    final request = http.Request(method, _uri(path, query));
    final token = store.accessToken;
    if (token != null) request.headers['Authorization'] = 'Bearer $token';
    // A JSON content type with an empty body is refused by the server, so the header goes only with a body.
    if (body != null) {
      request.headers['Content-Type'] = 'application/json';
      request.body = jsonEncode(body);
    }

    final http.Response response;
    try {
      response = await http.Response.fromStream(await _client.send(request).timeout(const Duration(seconds: 30)));
    } on Exception {
      throw ApiError(0, 'offline', 'ما كدرنا نوصل للسيرفر. تأكد من شبكة المكتب.');
    }

    if (response.statusCode == 401 && !retried && store.refreshToken != null && !path.startsWith('/auth/')) {
      if (await _refresh()) {
        return _send(method, path, query: query, body: body, retried: true);
      }
      onSessionEnded?.call();
    }
    final text = utf8.decode(response.bodyBytes);
    final decoded = text.isEmpty ? null : jsonDecode(text);
    if (response.statusCode >= 400) {
      final error = decoded is Map ? decoded['error'] as Map<String, dynamic>? : null;
      throw ApiError(response.statusCode, error?['code'] as String? ?? 'error',
          error?['message'] as String? ?? 'صار خطأ');
    }
    return decoded;
  }

  Future<bool> _refresh() async {
    try {
      final response = await _client.post(_uri('/auth/refresh'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'refresh_token': store.refreshToken}));
      if (response.statusCode != 200) return false;
      final data = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      await store.saveTokens(access: data['access_token'] as String, refresh: data['refresh_token'] as String);
      return true;
    } on Exception {
      return false;
    }
  }
}
