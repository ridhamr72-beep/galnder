import 'dart:convert';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

import 'ui.dart';

/// نافذة الكاميرا: تبيّن الوجه وتلتقط صورة واحدة، وترجعها نصّاً (base64) للسيرفر. الصورة ما تنحفظ بالجهاز.
/// ترجع null إذا انسدّت النافذة أو ماكو كاميرا.
Future<String?> captureFace(BuildContext context, {required String title, required String action}) {
  return showDialog<String>(context: context, barrierDismissible: false, builder: (_) => _FaceDialog(title: title, action: action));
}

class _FaceDialog extends StatefulWidget {
  const _FaceDialog({required this.title, required this.action});

  final String title;
  final String action;

  @override
  State<_FaceDialog> createState() => _FaceDialogState();
}

class _FaceDialogState extends State<_FaceDialog> {
  CameraController? _camera;
  String? _problem;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _open();
  }

  Future<void> _open() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        setState(() => _problem = 'ماكو كاميرا بهذا الجهاز. ادخل بكلمة المرور.');
        return;
      }
      // الأمامية إذا موجودة (الهاتف)، وإلا الأولى (كاميرا الكمبيوتر).
      final front = cameras.where((c) => c.lensDirection == CameraLensDirection.front);
      final camera = CameraController(front.isNotEmpty ? front.first : cameras.first, ResolutionPreset.medium, enableAudio: false);
      await camera.initialize();
      if (!mounted) {
        await camera.dispose();
        return;
      }
      setState(() => _camera = camera);
    } on CameraException catch (error) {
      setState(() => _problem = 'الكاميرا ما اشتغلت (${error.description ?? error.code}).');
    }
  }

  Future<void> _take() async {
    final camera = _camera;
    if (camera == null || _busy) return;
    setState(() => _busy = true);
    try {
      final shot = await camera.takePicture();
      final bytes = await shot.readAsBytes();
      if (mounted) Navigator.pop(context, base64Encode(bytes));
    } on CameraException catch (error) {
      setState(() {
        _busy = false;
        _problem = 'ما انلتقطت الصورة (${error.description ?? error.code}).';
      });
    }
  }

  @override
  void dispose() {
    _camera?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final camera = _camera;
    return AlertDialog(
      title: Text(widget.title),
      content: SizedBox(
        width: 380,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AspectRatio(
              aspectRatio: 4 / 3,
              child: Container(
                color: Ink2.ink,
                alignment: Alignment.center,
                child: _problem != null
                    ? Padding(padding: const EdgeInsets.all(16), child: Text(_problem!, style: const TextStyle(color: Colors.white), textAlign: TextAlign.center))
                    : camera == null
                        ? const CircularProgressIndicator(color: Ink2.khaki)
                        : Stack(
                            alignment: Alignment.center,
                            children: [
                              CameraPreview(camera),
                              // إطار يدلّ وين يكون الوجه.
                              Container(width: 150, height: 190, decoration: BoxDecoration(border: Border.all(color: Ink2.khaki, width: 2))),
                            ],
                          ),
              ),
            ),
            const SizedBox(height: 10),
            const Text('خلي وجهك بالإطار، والضوء عليه، وشخص واحد بس.', style: TextStyle(color: Ink2.muted)),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
        FilledButton(onPressed: camera == null || _busy ? null : _take, child: Text(widget.action)),
      ],
    );
  }
}
