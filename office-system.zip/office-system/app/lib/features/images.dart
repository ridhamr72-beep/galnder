import 'dart:typed_data';

import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/ui.dart';

/// صور المهمة: يعرضها ويرفق صورة جديدة. الخادم يقرر من يرى ومن يرفق.
class TaskImages extends StatefulWidget {
  const TaskImages({super.key, required this.api, required this.taskId, this.canAttach = true});

  final Api api;
  final String taskId;
  final bool canAttach;

  @override
  State<TaskImages> createState() => _TaskImagesState();
}

class _TaskImagesState extends State<TaskImages> {
  int _version = 0;

  Future<void> _attach() async {
    final file = await openFile(acceptedTypeGroups: const [
      XTypeGroup(label: 'صور', extensions: ['jpg', 'jpeg', 'png', 'webp']),
    ]);
    if (file == null || !mounted) return;
    final done = await attempt(context, () => widget.api.upload('/tasks/${widget.taskId}/attachments', file.path));
    if (done) setState(() => _version++);
  }

  @override
  Widget build(BuildContext context) {
    return Loader<List<Map<String, dynamic>>>(
      key: ValueKey(_version),
      load: () => widget.api.list('/tasks/${widget.taskId}/attachments'),
      builder: (context, images, _) => Wrap(
        spacing: 8,
        runSpacing: 8,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          for (final image in images) ImageThumb(api: widget.api, image: image),
          if (widget.canAttach)
            OutlinedButton.icon(onPressed: _attach, icon: const Icon(Icons.add_photo_alternate_outlined), label: const Text('إرفاق صورة')),
        ],
      ),
    );
  }
}

/// صورة مصغّرة تنفتح كبيرة بالضغط: لصور المهام وصفحات الكتب.
class ImageThumb extends StatelessWidget {
  const ImageThumb({super.key, required this.api, required this.image});

  final Api api;
  final Map<String, dynamic> image;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<int>>(
      future: api.bytes('/attachments/${image['id']}'),
      builder: (context, snapshot) {
        final data = snapshot.data;
        return InkWell(
          onTap: data == null ? null : () => showDialog<void>(context: context, builder: (_) => Dialog(child: InteractiveViewer(child: Image.memory(Uint8List.fromList(data))))),
          child: Container(
            width: 88,
            height: 88,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: Ink2.line)),
            clipBehavior: Clip.antiAlias,
            child: data == null
                ? const Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)))
                : Tooltip(
                    message: switch (image['purpose']) { 'result' => 'صورة النتيجة', 'task' => 'صورة المهمة', _ => 'صفحة الكتاب' },
                    child: Image.memory(Uint8List.fromList(data), fit: BoxFit.cover),
                  ),
          ),
        );
      },
    );
  }
}
