import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/ui.dart';

/// كل المهام المفتوحة لمسؤول المتابعة: يحوّلها لموظف ثاني، يمدّد موعدها، أو يلغيها.
class AllTasksScreen extends StatelessWidget {
  const AllTasksScreen({super.key, required this.api, required this.refresh, required this.canCancel});

  final Api api;
  final Listenable refresh;
  final bool canCancel;

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'كل المهام',
      subtitle: 'تحويل المهمة أو تمديد موعدها يُسجَّل بسببه',
      child: Loader<List<Map<String, dynamic>>>(
        load: () async => (await api.list('/tasks?limit=200'))
            .where((t) => t['status'] != 'closed' && t['status'] != 'cancelled')
            .toList(),
        refresh: refresh,
        builder: (context, tasks, reload) {
          if (tasks.isEmpty) return const Empty('ما كو مهام مفتوحة');
          return ListView.separated(
            itemCount: tasks.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) => _TaskRow(api: api, task: tasks[i], reload: reload, canCancel: canCancel),
          );
        },
      ),
    );
  }
}

class _TaskRow extends StatelessWidget {
  const _TaskRow({required this.api, required this.task, required this.reload, required this.canCancel});

  final Api api;
  final Map<String, dynamic> task;
  final VoidCallback reload;
  final bool canCancel;

  String get _id => task['id'] as String;

  Future<String?> _reason(BuildContext context, String title) {
    final text = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (dialog) => AlertDialog(
        title: Text(title),
        content: SizedBox(
          width: 400,
          child: TextField(controller: text, autofocus: true, maxLines: 2, decoration: const InputDecoration(labelText: 'السبب')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialog), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              if (text.text.trim().isNotEmpty) Navigator.pop(dialog, text.text.trim());
            },
            child: const Text('تأكيد'),
          ),
        ],
      ),
    );
  }

  Future<void> _reassign(BuildContext context) async {
    final people = await api.list('/directory');
    if (!context.mounted) return;
    String? to;
    final reason = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialog) => StatefulBuilder(
        builder: (dialog, setInner) => AlertDialog(
          title: const Text('تحويل المهمة'),
          content: SizedBox(
            width: 420,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  initialValue: to,
                  decoration: const InputDecoration(labelText: 'إلى'),
                  items: [
                    for (final p in people)
                      if (p['id'] != task['assignee_id'])
                        DropdownMenuItem(value: p['id'] as String, child: Text(p['full_name'] as String)),
                  ],
                  onChanged: (v) => setInner(() => to = v),
                ),
                const SizedBox(height: 12),
                TextField(controller: reason, decoration: const InputDecoration(labelText: 'السبب')),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialog), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () {
                if (to != null && reason.text.trim().isNotEmpty) Navigator.pop(dialog, true);
              },
              child: const Text('حوّل'),
            ),
          ],
        ),
      ),
    );
    if (ok != true || !context.mounted) return;
    if (await attempt(context, () => api.post('/tasks/$_id/reassign', {'assignee_id': to, 'reason': reason.text.trim()}))) reload();
  }

  Future<void> _extend(BuildContext context) async {
    final current = DateTime.tryParse(task['due_at'] as String? ?? '')?.toLocal() ?? DateTime.now();
    final start = current.isBefore(DateTime.now()) ? DateTime.now() : current;
    final day = await showDatePicker(
      context: context,
      initialDate: start.add(const Duration(days: 1)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (day == null || !context.mounted) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(current));
    if (time == null || !context.mounted) return;
    final reason = await _reason(context, 'سبب التمديد');
    if (reason == null || !context.mounted) return;
    final due = DateTime(day.year, day.month, day.day, time.hour, time.minute).toUtc().toIso8601String();
    if (await attempt(context, () => api.post('/tasks/$_id/extend', {'due_at': due, 'reason': reason}))) reload();
  }

  Future<void> _cancel(BuildContext context) async {
    final reason = await _reason(context, 'سبب إلغاء المهمة');
    if (reason == null || !context.mounted) return;
    if (await attempt(context, () => api.post('/tasks/$_id/cancel', {'reason': reason}))) reload();
  }

  @override
  Widget build(BuildContext context) {
    final status = task['status'] as String;
    final overdue = task['is_overdue'] == true;
    return Panel(
      child: CardRow(
        body: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Text(task['title'] as String, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    if (task['priority'] == 'high') const Tag('عالية', color: Ink2.high),
                    Tag(statusLabels[status] ?? status),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  '${task['assignee_name']} · الموعد ${shortTime(task['due_at'] as String?)}${overdue ? ' · متأخرة' : ''}',
                  style: TextStyle(color: overdue ? Ink2.high : Ink2.muted),
                ),
              ],
            ),
        actions: [
          if (status != 'submitted') OutlinedButton(onPressed: () => _reassign(context), child: const Text('تحويل')),
          OutlinedButton(onPressed: () => _extend(context), child: const Text('تمديد')),
          if (canCancel)
            TextButton(onPressed: () => _cancel(context), style: TextButton.styleFrom(foregroundColor: Ink2.high), child: const Text('إلغاء')),
        ],
      ),
    );
  }
}
