import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/ui.dart';

const _durations = {'ساعتين': 2, 'يوم': 24, '3 أيام': 72, 'أسبوع': 168, 'شهر': 720};

class _Draft {
  final title = TextEditingController();
  String? assigneeId;
  String priority = 'normal';
  int hours = 24;
  /// وقت محدد بدل المدة (اليوم والساعة).
  DateTime? dueAt;

  Map<String, dynamic> toJson() => {
        'title': title.text.trim(),
        'assignee_id': assigneeId,
        'priority': priority,
        if (dueAt != null) 'due_at': dueAt!.toUtc().toIso8601String() else 'due_in_hours': hours,
      };

  String get dueLabel {
    if (dueAt == null) return _durations.entries.firstWhere((e) => e.value == hours).key;
    final d = dueAt!;
    return '${d.day}/${d.month} ${d.hour}:${d.minute.toString().padLeft(2, '0')}';
  }
}

/// قائمة المهام مع زرّ «+»، تشترك فيها شاشة المحضر وإرسال مهمة.
class TaskRows extends StatefulWidget {
  const TaskRows({super.key, required this.people, required this.controller});

  final List<Map<String, dynamic>> people;
  final TaskRowsController controller;

  @override
  State<TaskRows> createState() => _TaskRowsState();
}

class TaskRowsController {
  final drafts = <_Draft>[_Draft()];

  /// لنافذة المراجعة: «المهمة ← الشخص · الأهمية · الموعد».
  List<String> summary(List<Map<String, dynamic>> people) => [
        for (final d in drafts)
          '${d.title.text.trim()}  ←  ${people.firstWhere((p) => p['id'] == d.assigneeId, orElse: () => {'full_name': '-'})['full_name']}'
              '  ·  ${d.priority == 'high' ? 'عالية الأهمية' : 'عادية'}  ·  ${d.dueLabel}',
      ];

  /// null إذا كان شيء ناقص.
  List<Map<String, dynamic>>? read() {
    final complete = drafts.every((d) => d.title.text.trim().isNotEmpty && d.assigneeId != null);
    return complete ? drafts.map((d) => d.toJson()).toList() : null;
  }
}

class _TaskRowsState extends State<TaskRows> {
  List<_Draft> get _drafts => widget.controller.drafts;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (var i = 0; i < _drafts.length; i++) ...[
          _row(i),
          const SizedBox(height: 12),
        ],
        OutlinedButton(
          onPressed: () => setState(() => _drafts.add(_Draft())),
          child: const Text('+ أضف مهمة', style: TextStyle(fontWeight: FontWeight.w600)),
        ),
      ],
    );
  }

  Future<void> _pickTime(_Draft draft) async {
    final now = DateTime.now();
    final day = await showDatePicker(context: context, initialDate: now, firstDate: now, lastDate: now.add(const Duration(days: 365)));
    if (day == null || !mounted) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(now.add(const Duration(hours: 2))));
    if (time == null) return;
    final at = DateTime(day.year, day.month, day.day, time.hour, time.minute);
    if (at.isBefore(now)) return;
    setState(() => draft.dueAt = at);
  }

  Widget _row(int i) {
    final draft = _drafts[i];
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 17,
                backgroundColor: Ink2.ink,
                child: Text('${i + 1}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(controller: draft.title, decoration: const InputDecoration(hintText: 'شنو المطلوب؟')),
              ),
              IconButton(
                tooltip: 'حذف المهمة',
                icon: const Icon(Icons.close, color: Ink2.muted),
                onPressed: _drafts.length == 1 ? null : () => setState(() => _drafts.removeAt(i)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 16,
            runSpacing: 10,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              SizedBox(
                width: 240,
                child: DropdownButtonFormField<String>(
                  initialValue: draft.assigneeId,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'يرسل إلى'),
                  items: [
                    for (final p in widget.people)
                      DropdownMenuItem(
                        value: p['id'] as String,
                        child: Text('${p['full_name']} - ${p['job_title'] ?? p['role_name']}', overflow: TextOverflow.ellipsis),
                      ),
                  ],
                  onChanged: (value) => setState(() => draft.assigneeId = value),
                ),
              ),
              _Choices<String>(
                options: const {'مهمة': 'normal', 'عالية الأهمية': 'high'},
                value: draft.priority,
                activeColor: draft.priority == 'high' ? Ink2.high : Ink2.ink,
                onPick: (value) => setState(() => draft.priority = value),
              ),
              _Choices<int>(
                options: _durations,
                value: draft.dueAt == null ? draft.hours : -1,
                onPick: (value) => setState(() {
                  draft.hours = value;
                  draft.dueAt = null;
                }),
              ),
              OutlinedButton.icon(
                onPressed: () => _pickTime(draft),
                icon: const Icon(Icons.timer_outlined, size: 18),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(44, 44),
                  backgroundColor: draft.dueAt != null ? Ink2.ink : Colors.white,
                  foregroundColor: draft.dueAt != null ? Colors.white : Ink2.ink,
                ),
                label: Text(draft.dueAt != null ? draft.dueLabel : 'وقت محدد'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Choices<T> extends StatelessWidget {
  const _Choices({required this.options, required this.value, required this.onPick, this.activeColor = Ink2.ink});

  final Map<String, T> options;
  final T value;
  final ValueChanged<T> onPick;
  final Color activeColor;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 6,
      children: [
        for (final option in options.entries)
          OutlinedButton(
            onPressed: () => onPick(option.value),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size(44, 44),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              backgroundColor: option.value == value ? activeColor : Colors.white,
              foregroundColor: option.value == value ? Colors.white : Ink2.ink,
            ),
            child: Text(option.key, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
          ),
      ],
    );
  }
}

/// مسؤول المحاضر: يكتب الاجتماع والمهام، وينشرها دفعة واحدة.
class MeetingScreen extends StatefulWidget {
  const MeetingScreen({super.key, required this.api});

  final Api api;

  @override
  State<MeetingScreen> createState() => _MeetingScreenState();
}

class _MeetingScreenState extends State<MeetingScreen> {
  final _title = TextEditingController(text: 'اجتماع مع الشخصية');
  final _body = TextEditingController();
  final _decisions = <TextEditingController>[TextEditingController()];
  TaskRowsController _rows = TaskRowsController();
  List<Map<String, dynamic>> _people = const [];
  bool _busy = false;

  /// مراجعة قبل التوزيع: منو ياخذ شنو ولوكت شكد. ما يوصل شي لأحد قبل «وزّع».
  Future<bool> _review(List<String> decisions) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialog) => AlertDialog(
        title: const Text('راجع قبل التوزيع'),
        content: SizedBox(
          width: 560,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                if (decisions.isNotEmpty) ...[
                  const Text('القرارات', style: TextStyle(fontWeight: FontWeight.w700)),
                  for (final d in decisions) Text('•  $d'),
                  const SizedBox(height: 12),
                ],
                const Text('المهام', style: TextStyle(fontWeight: FontWeight.w700)),
                for (final line in _rows.summary(_people)) Padding(padding: const EdgeInsets.only(top: 4), child: Text(line)),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialog), child: const Text('رجوع')),
          FilledButton(onPressed: () => Navigator.pop(dialog, true), child: const Text('وزّع')),
        ],
      ),
    );
    return ok == true;
  }

  Future<void> _publish() async {
    final tasks = _rows.read();
    if (tasks == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('كل مهمة لازم بيها نص وشخص')));
      return;
    }
    final decisions = [for (final d in _decisions) if (d.text.trim().isNotEmpty) d.text.trim()];
    if (!await _review(decisions) || !mounted) return;
    setState(() => _busy = true);
    final done = await attempt(context, () async {
      final meeting = await widget.api.post('/meetings', {
        'title': _title.text.trim(),
        'held_at': DateTime.now().toUtc().toIso8601String(),
        'body': _body.text.trim(),
      }) as Map<String, dynamic>;
      await widget.api.post('/meetings/${meeting['id']}/publish', {'tasks': tasks, 'decisions': decisions});
    });
    if (!mounted) return;
    setState(() {
      _busy = false;
      if (done) {
        _rows = TaskRowsController();
        _body.clear();
        _decisions
          ..clear()
          ..add(TextEditingController());
      }
    });
    if (done) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('وصلت ${tasks.length} مهام لأصحابها')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'محضر الاجتماع',
      subtitle: 'اكتب القرارات والمهام وقت الاجتماع، وراجعها، وبعدين وزّعها. الشخصية يوصلها ملخص',
      action: FilledButton(onPressed: _busy ? null : _publish, child: const Text('مراجعة وتوزيع')),
      child: Loader<List<Map<String, dynamic>>>(
        load: () => widget.api.list('/directory'),
        builder: (context, people, _) {
          _people = people;
          return ListView(
            children: [
              TextField(controller: _title, decoration: const InputDecoration(labelText: 'عنوان الاجتماع')),
              const SizedBox(height: 12),
              TextField(
                controller: _body,
                maxLines: 2,
                decoration: const InputDecoration(labelText: 'ملاحظات المحضر (لك وللشخصية فقط)'),
              ),
              const SizedBox(height: 20),
              const Text('القرارات', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              for (var i = 0; i < _decisions.length; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      Expanded(child: TextField(controller: _decisions[i], decoration: InputDecoration(hintText: 'القرار ${i + 1}'))),
                      IconButton(
                        tooltip: 'حذف القرار',
                        icon: const Icon(Icons.close, color: Ink2.muted),
                        onPressed: _decisions.length == 1 ? null : () => setState(() => _decisions.removeAt(i)),
                      ),
                    ],
                  ),
                ),
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: TextButton(onPressed: () => setState(() => _decisions.add(TextEditingController())), child: const Text('+ أضف قرار')),
              ),
              const SizedBox(height: 16),
              const Text('المهام', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              TaskRows(key: ObjectKey(_rows), people: people, controller: _rows),
            ],
          );
        },
      ),
    );
  }
}

/// إرسال مهمة بدون اجتماع: مدير المكتب ومسؤول المتابعة.
class SendTaskScreen extends StatefulWidget {
  const SendTaskScreen({super.key, required this.api});

  final Api api;

  @override
  State<SendTaskScreen> createState() => _SendTaskScreenState();
}

class _SendTaskScreenState extends State<SendTaskScreen> {
  TaskRowsController _rows = TaskRowsController();
  bool _busy = false;

  Future<void> _send() async {
    final tasks = _rows.read();
    if (tasks == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('كمّل نص كل مهمة والمستلم')));
      return;
    }
    setState(() => _busy = true);
    final done = await attempt(context, () async {
      for (final task in tasks) {
        await widget.api.post('/tasks', task);
      }
    });
    if (!mounted) return;
    setState(() {
      _busy = false;
      if (done) _rows = TaskRowsController();
    });
    if (done) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('وصلت المهام لأصحابها')));
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'إرسال مهمة',
      action: FilledButton(onPressed: _busy ? null : _send, child: const Text('إرسال')),
      child: Loader<List<Map<String, dynamic>>>(
        load: () => widget.api.list('/directory'),
        builder: (context, people, _) => ListView(
          children: [TaskRows(key: ObjectKey(_rows), people: people, controller: _rows)],
        ),
      ),
    );
  }
}
