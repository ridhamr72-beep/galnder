import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/ui.dart';

/// الصلاحيات مجمّعة حسب الشغل، حتى مدير النظام يشوف الدور بنظرة.
const _groups = <String, List<String>>{
  'المهام': ['tasks.read_own', 'tasks.create', 'tasks.read_all', 'tasks.reassign', 'tasks.cancel', 'tasks.review', 'performance.read'],
  'المحاضر والكتب': ['meetings.write', 'letters.read', 'letters.write'],
  'المواعيد والضيوف': ['appointments.write', 'persons.write'],
  'الموظفين والنظام': ['directory.read', 'users.manage', 'roles.manage', 'settings.manage'],
};

/// مدير النظام: الرتب وشنو يگدر يسوي كل وحدة. التغيير يشتغل فوراً على كل من يحمل الرتبة.
class RolesScreen extends StatefulWidget {
  const RolesScreen({super.key, required this.api});

  final Api api;

  @override
  State<RolesScreen> createState() => _RolesScreenState();
}

class _RolesScreenState extends State<RolesScreen> {
  int _version = 0;

  Future<(List<Map<String, dynamic>>, List<Map<String, dynamic>>)> _load() async =>
      (await widget.api.list('/roles'), await widget.api.list('/permissions'));

  Future<void> _newRole() async {
    final name = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialog) => AlertDialog(
        title: const Text('رتبة جديدة'),
        content: SizedBox(width: 380, child: TextField(controller: name, autofocus: true, decoration: const InputDecoration(labelText: 'اسم الرتبة', hintText: 'مثلاً: مسؤول الاستعلامات'))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialog), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(dialog, true), child: const Text('أضف')),
        ],
      ),
    );
    if (ok != true || name.text.trim().isEmpty || !mounted) return;
    final code = 'role_${DateTime.now().millisecondsSinceEpoch.toRadixString(36)}'.replaceAll(RegExp('[0-9]'), 'x');
    final done = await attempt(context, () => widget.api.post('/roles', {'code': code, 'name_ar': name.text.trim(), 'permission_codes': ['tasks.read_own']}));
    if (done) setState(() => _version++);
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'الرتب والصلاحيات',
      subtitle: 'كل رتبة شنو تگدر تسوي. علّم واحفظ، والتغيير يمشي فوراً',
      action: FilledButton.icon(onPressed: _newRole, icon: const Icon(Icons.add), label: const Text('رتبة جديدة')),
      child: Loader<(List<Map<String, dynamic>>, List<Map<String, dynamic>>)>(
        key: ValueKey(_version),
        load: _load,
        builder: (context, data, reload) {
          final (roles, permissions) = data;
          final shown = roles.where((r) => r['code'] != 'principal').toList();
          return ListView.separated(
            itemCount: shown.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (context, i) => _RoleCard(api: widget.api, role: shown[i], permissions: permissions, onSaved: reload),
          );
        },
      ),
    );
  }
}

class _RoleCard extends StatefulWidget {
  const _RoleCard({required this.api, required this.role, required this.permissions, required this.onSaved});

  final Api api;
  final Map<String, dynamic> role;
  final List<Map<String, dynamic>> permissions;
  final VoidCallback onSaved;

  @override
  State<_RoleCard> createState() => _RoleCardState();
}

class _RoleCardState extends State<_RoleCard> {
  late Set<String> _granted = (widget.role['permission_codes'] as List).cast<String>().toSet();
  bool _dirty = false;

  Future<void> _save() async {
    final done = await attempt(context, () => widget.api.patch('/roles/${widget.role['id']}', {'permission_codes': _granted.toList()}));
    if (!mounted) return;
    if (done) {
      setState(() => _dirty = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('انحفظت صلاحيات ${widget.role['name_ar']}')));
      widget.onSaved();
    } else {
      setState(() {
        _granted = (widget.role['permission_codes'] as List).cast<String>().toSet();
        _dirty = false;
      });
    }
  }

  Future<void> _delete() async {
    if (await attempt(context, () => widget.api.delete('/roles/${widget.role['id']}'))) widget.onSaved();
  }

  @override
  Widget build(BuildContext context) {
    final described = {for (final p in widget.permissions) p['code'] as String: p['description'] as String};
    final members = widget.role['members'] as int? ?? 0;
    final listed = _groups.values.expand((codes) => codes).toSet();
    final other = described.keys.where((c) => !listed.contains(c)).toList();
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Text.rich(TextSpan(children: [
                  TextSpan(text: widget.role['name_ar'] as String, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                  TextSpan(text: '   $members ${members == 1 ? 'موظف' : 'موظفين'}', style: const TextStyle(color: Ink2.muted, fontSize: 13)),
                ])),
              ),
              if (_dirty) FilledButton(onPressed: _save, child: const Text('حفظ')),
              if (widget.role['is_system'] != true && members == 0)
                IconButton(tooltip: 'حذف الرتبة', onPressed: _delete, icon: const Icon(Icons.delete_outline, color: Ink2.muted)),
            ],
          ),
          for (final group in {..._groups, if (other.isNotEmpty) 'أخرى': other}.entries)
            if (group.value.any(described.containsKey)) ...[
              const SizedBox(height: 10),
              Text(group.key, style: const TextStyle(color: Ink2.muted, fontSize: 13, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  for (final code in group.value)
                    if (described.containsKey(code))
                      FilterChip(
                        label: Text(described[code]!),
                        selected: _granted.contains(code),
                        onSelected: (on) => setState(() {
                          on ? _granted.add(code) : _granted.remove(code);
                          _dirty = true;
                        }),
                      ),
                ],
              ),
            ],
        ],
      ),
    );
  }
}
