import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/ui.dart';
import 'images.dart';
import 'messages.dart';

class _Block extends StatelessWidget {
  const _Block(this.label, this.text, {this.color = const Color(0xFFF6F6F4)});

  final String label;
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(top: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(10)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(color: Ink2.muted, fontSize: 13)),
            const SizedBox(height: 2),
            SelectableText(text, style: const TextStyle(fontSize: 15, height: 1.6)),
          ],
        ),
      );
}

/// محادثة المهمة: الموظف يوصل فكرته لمرسلها (أو للشخصية إذا هي أرسلتها).
class TaskThread extends StatefulWidget {
  const TaskThread({super.key, required this.api, required this.task});

  final Api api;
  final Map<String, dynamic> task;

  @override
  State<TaskThread> createState() => _TaskThreadState();
}

class _TaskThreadState extends State<TaskThread> {
  int _version = 0;

  Future<void> _write() async {
    final senderId = widget.task['sender_id'] as String?;
    final sent = await showDialog<bool>(
      context: context,
      builder: (_) => ComposeMessage(
        api: widget.api,
        canPickPeople: false,
        taskId: widget.task['id'] as String,
        to: senderId ?? 'principal',
        toName: widget.task['sender_name'] as String? ?? 'الشخصية الأساسية',
      ),
    );
    if (sent == true) setState(() => _version++);
  }

  @override
  Widget build(BuildContext context) {
    return Loader<List<Map<String, dynamic>>>(
      key: ValueKey(_version),
      load: () => widget.api.list('/tasks/${widget.task['id']}/messages'),
      builder: (context, items, _) => Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (final m in items)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text.rich(TextSpan(children: [
                TextSpan(text: '${m['sender_name']}: ', style: const TextStyle(fontWeight: FontWeight.w700)),
                TextSpan(text: m['body'] as String),
                TextSpan(text: '  ${shortTime(m['created_at'] as String?)}', style: const TextStyle(color: Ink2.muted, fontSize: 12)),
              ])),
            ),
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: TextButton.icon(
              onPressed: _write,
              icon: const Icon(Icons.chat_bubble_outline, size: 18),
              label: Text('اكتب لـ${widget.task['sender_name'] ?? 'الشخصية الأساسية'} عن المهمة'),
            ),
          ),
        ],
      ),
    );
  }
}

/// «اليوم 18:00»، «باچر 9:00»، «10/11 14:00»، أو «فات موعدها»: الموعد مثل ما يُگال.
String dueText(String? iso, [DateTime? now]) {
  final due = DateTime.tryParse(iso ?? '')?.toLocal();
  if (due == null) return '-';
  final today = now ?? DateTime.now();
  if (due.isBefore(today)) return 'فات موعدها';
  final days = DateTime(due.year, due.month, due.day).difference(DateTime(today.year, today.month, today.day)).inDays;
  final time = '${due.hour}:${due.minute.toString().padLeft(2, '0')}';
  if (days == 0) return 'اليوم $time';
  if (days == 1) return 'باچر $time';
  return '${due.day}/${due.month} $time';
}

/// مهامي: كل مهمة سطر واحد بزر الخطوة الجاية بس، والتفاصيل تنفتح بالضغط عليها.
class MyTasksScreen extends StatelessWidget {
  const MyTasksScreen({super.key, required this.api, required this.refresh});

  final Api api;
  final Listenable refresh;

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'مهامي',
      child: Loader<List<Map<String, dynamic>>>(
        load: () => api.list('/tasks/mine'),
        refresh: refresh,
        builder: (context, tasks, reload) {
          if (tasks.isEmpty) return const Empty('ما عندك مهام هسه');
          final waiting = tasks.where((t) => t['status'] == 'submitted').toList();
          final current = tasks.where((t) => t['status'] != 'submitted').toList();
          return ListView(
            children: [
              if (current.isNotEmpty) _Heading('تحتاجك', current.length),
              for (final t in current) _TaskCard(api: api, task: t, reload: reload),
              if (waiting.isNotEmpty) ...[
                const SizedBox(height: 16),
                _Heading('سلّمتها، تنتظر الموافقة', waiting.length),
                for (final t in waiting) _TaskCard(api: api, task: t, reload: reload),
              ],
            ],
          );
        },
      ),
    );
  }
}

class _Heading extends StatelessWidget {
  const _Heading(this.text, this.count);

  final String text;
  final int count;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text('$text ($count)', style: const TextStyle(color: Ink2.muted, fontWeight: FontWeight.w700)),
      );
}

class _TaskCard extends StatelessWidget {
  const _TaskCard({required this.api, required this.task, required this.reload});

  final Api api;
  final Map<String, dynamic> task;
  final VoidCallback reload;

  String get _id => task['id'] as String;

  Future<void> _post(BuildContext context, String path) async {
    if (await attempt(context, () => api.post('/tasks/$_id/$path'))) reload();
  }

  Future<void> _submit(BuildContext context) async {
    final done = await showDialog<bool>(context: context, builder: (_) => _SubmitDialog(api: api, taskId: _id));
    if (done == true) reload();
  }

  Future<void> _details(BuildContext context) async {
    await showDialog<void>(context: context, builder: (_) => _Details(api: api, task: task));
    reload();
  }

  @override
  Widget build(BuildContext context) {
    final sealed = task['sealed'] == true;
    final status = task['status'] as String? ?? 'assigned';
    final high = (task['priority'] ?? task['notification_level']) == 'high';
    final due = dueText(task['due_at'] as String?);
    final Widget action = sealed
        ? FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Ink2.ink),
            onPressed: () => _post(context, 'open'),
            child: const Text('افتح المهمة'),
          )
        : switch (status) {
            'opened' => FilledButton(onPressed: () => _post(context, 'start'), child: const Text('بديت بيها')),
            'in_progress' || 'returned' => FilledButton(onPressed: () => _submit(context), child: const Text('خلّصتها')),
            _ => const Tag('تنتظر الموافقة'),
          };
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: sealed ? Ink2.ink : const Color(0xFFF6F4EC),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(4),
          side: BorderSide(color: sealed ? Ink2.ink : Ink2.line),
        ),
        child: InkWell(
          onTap: sealed ? null : () => _details(context),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              border: BorderDirectional(start: BorderSide(color: high ? Ink2.high : (sealed ? Ink2.khaki : Colors.transparent), width: 4)),
            ),
            child: CardRow(
                body: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        sealed ? 'وصلتك مهمة جديدة' : task['title'] as String,
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: sealed ? Colors.white : Ink2.ink),
                      ),
                      const SizedBox(height: 3),
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              sealed ? 'افتحها حتى تشوف شنو المطلوب' : 'من ${task['sender_name'] ?? '-'}  ·  $due',
                              style: TextStyle(color: sealed ? const Color(0xFFD6D5D0) : (due == 'فات موعدها' ? Ink2.high : Ink2.muted)),
                            ),
                          ),
                          if (!sealed && status != 'submitted') ...[const SizedBox(width: 10), Countdown(task['due_at'] as String?)],
                        ],
                      ),
                      if (status == 'returned' && (task['return_note'] as String? ?? '').isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text('رجعت إلك: ${task['return_note']}', style: const TextStyle(color: Ink2.warn, fontWeight: FontWeight.w600)),
                        ),
                    ],
                  ),
                actions: [action],
            ),
          ),
        ),
      ),
    );
  }
}

/// «خلّصتها»: شنو صار، وصورة إذا تحب، وتنرسل.
class _SubmitDialog extends StatefulWidget {
  const _SubmitDialog({required this.api, required this.taskId});

  final Api api;
  final String taskId;

  @override
  State<_SubmitDialog> createState() => _SubmitDialogState();
}

class _SubmitDialogState extends State<_SubmitDialog> {
  final _result = TextEditingController();

  Future<void> _send() async {
    if (_result.text.trim().isEmpty) return;
    final done = await attempt(context, () => widget.api.post('/tasks/${widget.taskId}/submit', {'result_text': _result.text.trim()}));
    if (done && mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('شنو صار؟'),
      content: SizedBox(
        width: 460,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _result,
              autofocus: true,
              maxLines: 3,
              decoration: const InputDecoration(hintText: 'مثلاً: حجزت الموعد الأحد الساعة 10'),
            ),
            const SizedBox(height: 12),
            TaskImages(api: widget.api, taskId: widget.taskId),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
        FilledButton(onPressed: _send, child: const Text('أرسل')),
      ],
    );
  }
}

/// كل تفاصيل المهمة: كلام الشخصية، الصور، والمحادثة ويا المرسل.
class _Details extends StatelessWidget {
  const _Details({required this.api, required this.task});

  final Api api;
  final Map<String, dynamic> task;

  @override
  Widget build(BuildContext context) {
    final status = task['status'] as String;
    return AlertDialog(
      title: Text(task['title'] as String),
      content: SizedBox(
        width: 560,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'من ${task['sender_name'] ?? '-'}  ·  الموعد ${dueText(task['due_at'] as String?)}  ·  ${statusLabels[status] ?? status}',
                style: const TextStyle(color: Ink2.muted),
              ),
              if ((task['original_utterance'] as String? ?? '').isNotEmpty)
                _Block('طلب الشخصية بكلامها', '«${task['original_utterance']}»', color: const Color(0xFFEEF2FF)),
              if ((task['description'] as String? ?? '').isNotEmpty) _Block('التفاصيل', task['description'] as String),
              if ((task['return_note'] as String? ?? '').isNotEmpty && status == 'returned')
                _Block('سبب الإرجاع', task['return_note'] as String, color: const Color(0xFFFFF4E5)),
              if ((task['last_result'] as String? ?? '').isNotEmpty) _Block('شنو كتبت لما سلّمت', task['last_result'] as String),
              const SizedBox(height: 12),
              TaskImages(api: api, taskId: task['id'] as String, canAttach: status != 'closed'),
              const SizedBox(height: 8),
              TaskThread(api: api, task: task),
            ],
          ),
        ),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('سد'))],
    );
  }
}
