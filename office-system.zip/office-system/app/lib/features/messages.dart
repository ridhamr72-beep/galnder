import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/ui.dart';

/// الرسائل: ما وصلني وما أرسلته، والكتابة للشخصية أو لزميل.
class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key, required this.api, required this.refresh, required this.myId, required this.canPickPeople});

  final Api api;
  final Listenable refresh;
  final String myId;
  final bool canPickPeople;

  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  int _version = 0;

  Future<void> _write() async {
    final sent = await showDialog<bool>(
      context: context,
      builder: (_) => ComposeMessage(api: widget.api, canPickPeople: widget.canPickPeople),
    );
    if (sent == true) setState(() => _version++);
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'الرسائل',
      subtitle: 'اكتب للشخصية مباشرة، والذكاء يوصّلها لها',
      action: FilledButton.icon(onPressed: _write, icon: const Icon(Icons.edit_outlined), label: const Text('رسالة جديدة')),
      child: Loader<List<Map<String, dynamic>>>(
        key: ValueKey(_version),
        load: () => widget.api.list('/messages'),
        refresh: widget.refresh,
        builder: (context, items, reload) {
          if (items.isEmpty) return const Empty('ما كو رسائل بعد');
          return ListView.separated(
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) => MessageTile(
              message: items[i],
              mine: items[i]['sender_id'] == widget.myId,
              onRead: items[i]['recipient_id'] == widget.myId && items[i]['read_at'] == null
                  ? () async {
                      if (await attempt(context, () => widget.api.post('/messages/${items[i]['id']}/read'))) reload();
                    }
                  : null,
            ),
          );
        },
      ),
    );
  }
}

class MessageTile extends StatelessWidget {
  const MessageTile({super.key, required this.message, required this.mine, this.onRead});

  final Map<String, dynamic> message;
  final bool mine;
  final VoidCallback? onRead;

  @override
  Widget build(BuildContext context) {
    final fromPrincipal = message['from_ai'] == true;
    return Panel(
      color: fromPrincipal ? const Color(0xFFEEF2FF) : Colors.white,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  mine ? 'إلى ${message['recipient_name']}' : 'من ${message['sender_name']}',
                  style: TextStyle(fontWeight: FontWeight.w700, color: fromPrincipal ? Ink2.blue : Ink2.ink),
                ),
                if (message['task_title'] != null)
                  Text('بخصوص: ${message['task_title']}', style: const TextStyle(color: Ink2.muted, fontSize: 13)),
                const SizedBox(height: 4),
                Text(message['body'] as String, style: const TextStyle(fontSize: 15, height: 1.6)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(shortTime(message['created_at'] as String?), style: const TextStyle(color: Ink2.muted, fontSize: 12)),
              if (onRead != null) TextButton(onPressed: onRead, child: const Text('قرأتها')),
              if (mine && message['recipient_id'] == null)
                Text(message['read_at'] == null ? 'لم تُقرأ بعد' : 'وصلت للشخصية', style: const TextStyle(color: Ink2.muted, fontSize: 12)),
            ],
          ),
        ],
      ),
    );
  }
}

/// رسالة جديدة: للشخصية دائماً، ولزميل إذا كان عند المستخدم قائمة الموظفين.
class ComposeMessage extends StatefulWidget {
  const ComposeMessage({super.key, required this.api, required this.canPickPeople, this.taskId, this.to, this.toName});

  final Api api;
  final bool canPickPeople;
  final String? taskId;
  /// مستلم محدد مسبقاً (مثلاً مرسل المهمة)؛ null مع toName يعني الشخصية.
  final String? to;
  final String? toName;

  @override
  State<ComposeMessage> createState() => _ComposeMessageState();
}

class _ComposeMessageState extends State<ComposeMessage> {
  final _body = TextEditingController();
  late String _to = widget.to ?? 'principal';

  Future<void> _send() async {
    if (_body.text.trim().isEmpty) return;
    final done = await attempt(context, () => widget.api.post('/messages', {
          'to': _to,
          'body': _body.text.trim(),
          if (widget.taskId != null) 'task_id': widget.taskId,
        }));
    if (done && mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final fixed = widget.toName != null;
    return AlertDialog(
      title: Text(fixed ? 'رسالة إلى ${widget.toName}' : 'رسالة جديدة'),
      content: SizedBox(
        width: 440,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (!fixed)
              widget.canPickPeople
                  ? Loader<List<Map<String, dynamic>>>(
                      load: () => widget.api.list('/directory'),
                      builder: (context, people, _) => DropdownButtonFormField<String>(
                        initialValue: _to,
                        decoration: const InputDecoration(labelText: 'إلى'),
                        items: [
                          const DropdownMenuItem(value: 'principal', child: Text('الشخصية الأساسية')),
                          for (final p in people) DropdownMenuItem(value: p['id'] as String, child: Text(p['full_name'] as String)),
                        ],
                        onChanged: (value) => setState(() => _to = value!),
                      ),
                    )
                  : const Text('إلى: الشخصية الأساسية', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            TextField(controller: _body, autofocus: true, maxLines: 4, decoration: const InputDecoration(labelText: 'الرسالة')),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
        FilledButton(onPressed: _send, child: const Text('إرسال')),
      ],
    );
  }
}
