import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/platform.dart';
import '../core/ui.dart';

/// مدير المكتب: المواعيد والمقابلات. كل ما يضاف هنا يعرفه الذكاء.
class AppointmentsScreen extends StatefulWidget {
  const AppointmentsScreen({super.key, required this.api});

  final Api api;

  @override
  State<AppointmentsScreen> createState() => _AppointmentsScreenState();
}

class _AppointmentsScreenState extends State<AppointmentsScreen> {
  int _version = 0;

  Future<void> _add(String kind) async {
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => _NewAppointment(api: widget.api, kind: kind),
    );
    if (saved == true) setState(() => _version++);
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'المواعيد',
      subtitle: 'كل ما تضيفه هنا تعرفه الشخصية من الذكاء',
      action: Wrap(
        spacing: 8,
        children: [
          OutlinedButton(
              onPressed: () => _add('appointment'),
              child: const Text('+ موعد')),
          FilledButton(
              onPressed: () => _add('interview'),
              child: const Text('+ تهيئة مقابلة')),
        ],
      ),
      child: Loader<List<Map<String, dynamic>>>(
        key: ValueKey(_version),
        load: () => widget.api.list('/appointments', {
          'start': DateTime.now()
              .subtract(const Duration(days: 1))
              .toUtc()
              .toIso8601String(),
        }),
        builder: (context, items, reload) {
          if (items.isEmpty) return const Empty('ما كو مواعيد قادمة');
          return ListView.separated(
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final item = items[i];
              final interview = item['kind'] == 'interview';
              return Panel(
                child: CardRow(
                  leading: SizedBox(
                      width: formFactor(context) == FormFactor.phone ? null : 110,
                      child: Text(shortTime(item['starts_at'] as String?),
                          style: const TextStyle(fontWeight: FontWeight.w700, color: Ink2.blue))),
                  body: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item['title'] as String,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 16)),
                          if (item['person_name'] != null)
                            Text('الضيف: ${item['person_name']}'),
                          if (item['notes'] != null)
                            Text('ملاحظة للذكاء: ${item['notes']}',
                                style: const TextStyle(color: Ink2.muted)),
                        ],
                      ),
                  actions: [
                    Tag(interview ? 'مقابلة' : 'موعد',
                        color: interview ? Ink2.blue : Ink2.muted),
                    IconButton(
                      tooltip: 'إلغاء الموعد',
                      icon: const Icon(Icons.close, color: Ink2.muted),
                      onPressed: () async {
                        final cancelled = await attempt(context,
                            () => widget.api.delete('/appointments/${item['id']}'));
                        if (cancelled) reload();
                      },
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _NewAppointment extends StatefulWidget {
  const _NewAppointment({required this.api, required this.kind});

  final Api api;
  final String kind;

  @override
  State<_NewAppointment> createState() => _NewAppointmentState();
}

class _NewAppointmentState extends State<_NewAppointment> {
  final _title = TextEditingController();
  final _notes = TextEditingController();
  final _guestName = TextEditingController();
  final _guestOrg = TextEditingController();
  final _guestFile = TextEditingController();
  List<Map<String, dynamic>> _people = const [];

  /// null = بلا ضيف، 'new' = ضيف جديد، وإلا معرّف ملفه.
  String? _guest;
  DateTime _when = DateTime.now().add(const Duration(days: 1));

  @override
  void initState() {
    super.initState();
    widget.api.list('/persons').then((people) {
      if (mounted) setState(() => _people = people);
    }).catchError((_) {});
  }

  void _pickGuest(String? value) {
    final person = _people.where((p) => p['id'] == value).firstOrNull;
    setState(() {
      _guest = value;
      _guestFile.text = person?['notes'] as String? ?? '';
    });
  }

  /// The guest's file id: an existing one (its notes updated if changed), a new one, or none.
  Future<String?> _guestId() async {
    if (_guest == null) return null;
    final file = _guestFile.text.trim();
    if (_guest == 'new') {
      if (_guestName.text.trim().isEmpty) return null;
      final made = await widget.api.post('/persons', {
        'full_name': _guestName.text.trim(),
        if (_guestOrg.text.trim().isNotEmpty)
          'organization': _guestOrg.text.trim(),
        if (file.isNotEmpty) 'notes': file,
      }) as Map<String, dynamic>;
      return made['id'] as String;
    }
    final before =
        _people.firstWhere((p) => p['id'] == _guest)['notes'] as String? ?? '';
    if (file.isNotEmpty && file != before) {
      await widget.api.patch('/persons/$_guest', {'notes': file});
    }
    return _guest;
  }

  Future<void> _pick() async {
    final day = await showDatePicker(
      context: context,
      initialDate: _when,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 730)),
    );
    if (day == null || !mounted) return;
    final time = await showTimePicker(
        context: context, initialTime: TimeOfDay.fromDateTime(_when));
    if (time == null) return;
    setState(() =>
        _when = DateTime(day.year, day.month, day.day, time.hour, time.minute));
  }

  Future<void> _save() async {
    if (_title.text.trim().isEmpty) return;
    final notes = _notes.text.trim();
    final done = await attempt(context, () async {
      final person = await _guestId();
      await widget.api.post('/appointments', {
        'title': _title.text.trim(),
        'kind': widget.kind,
        'starts_at': _when.toUtc().toIso8601String(),
        if (notes.isNotEmpty) 'notes': notes,
        if (person != null) 'person_id': person,
      });
    });
    if (done && mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.kind == 'interview' ? 'تهيئة مقابلة' : 'موعد جديد'),
      content: SizedBox(
        width: 420,
        child: SingleChildScrollView(
            child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
                controller: _title,
                autofocus: true,
                decoration: const InputDecoration(labelText: 'العنوان')),
            const SizedBox(height: 12),
            OutlinedButton(
                onPressed: _pick,
                child: Text(
                    'الوقت: ${shortTime(_when.toUtc().toIso8601String())}')),
            const SizedBox(height: 12),
            TextField(
                controller: _notes,
                maxLines: 2,
                decoration: const InputDecoration(labelText: 'ملاحظة للذكاء')),
            const SizedBox(height: 12),
            DropdownButtonFormField<String?>(
              initialValue: _guest,
              decoration: const InputDecoration(labelText: 'الضيف'),
              items: [
                const DropdownMenuItem(value: null, child: Text('بلا ضيف')),
                const DropdownMenuItem(value: 'new', child: Text('+ ضيف جديد')),
                for (final p in _people)
                  DropdownMenuItem(
                      value: p['id'] as String,
                      child: Text([p['full_name'], p['organization']]
                          .whereType<String>()
                          .join(' · '))),
              ],
              onChanged: _pickGuest,
            ),
            if (_guest == 'new') ...[
              const SizedBox(height: 10),
              TextField(
                  controller: _guestName,
                  decoration: const InputDecoration(labelText: 'اسم الضيف')),
              const SizedBox(height: 10),
              TextField(
                  controller: _guestOrg,
                  decoration: const InputDecoration(labelText: 'جهته')),
            ],
            if (_guest != null) ...[
              const SizedBox(height: 10),
              TextField(
                controller: _guestFile,
                maxLines: 3,
                decoration: const InputDecoration(
                    labelText: 'ملف الضيف: منو هو وشنو يريد',
                    helperText: 'الذكاء يقرأه للشخصية قبل المقابلة'),
              ),
            ],
          ],
        )),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء')),
        FilledButton(onPressed: _save, child: const Text('حفظ')),
      ],
    );
  }
}
