import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/face_camera.dart';
import '../core/ui.dart';

/// بصمة الوجه للموظف نفسه: يضيف صور لوجهه (لحد خمس) حتى يدخل بالكاميرا، أو يمسحها.
Future<void> showMyFace(BuildContext context, Api api) => showDialog<void>(context: context, builder: (_) => _MyFace(api: api));

class _MyFace extends StatefulWidget {
  const _MyFace({required this.api});

  final Api api;

  @override
  State<_MyFace> createState() => _MyFaceState();
}

class _MyFaceState extends State<_MyFace> {
  int? _prints;
  int _max = 5;
  String? _note;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await widget.api.get('/me/face') as Map<String, dynamic>;
      setState(() {
        _prints = r['prints'] as int;
        _max = r['max'] as int;
      });
    } on ApiError catch (error) {
      setState(() => _note = error.message);
    }
  }

  Future<void> _add() async {
    final image = await captureFace(context, title: 'سجّل وجهك', action: 'احفظ');
    if (image == null) return;
    setState(() => _busy = true);
    try {
      final r = await widget.api.post('/me/face', {'image': image}) as Map<String, dynamic>;
      setState(() {
        _prints = r['prints'] as int;
        _note = 'انحفظت. صورة ثانية بضوء غير تخلي التعرّف أدق.';
      });
    } on ApiError catch (error) {
      setState(() => _note = error.message);
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _wipe() async {
    setState(() => _busy = true);
    try {
      await widget.api.delete('/me/face');
      setState(() {
        _prints = 0;
        _note = 'انمسحت. الدخول بالوجه مسدود لحسابك.';
      });
    } on ApiError catch (error) {
      setState(() => _note = error.message);
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final prints = _prints;
    return AlertDialog(
      title: const Text('بصمة الوجه'),
      content: SizedBox(
        width: 360,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              prints == null
                  ? 'لحظة…'
                  : prints == 0
                      ? 'وجهك مو مسجّل. سجّله حتى تدخل بالكاميرا بدل كلمة المرور.'
                      : 'وجهك مسجّل بـ $prints من $_max صور.',
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 6),
            const Text('تنحفظ أرقام تميّز وجهك بس، مو الصورة. كلمة المرور تبقى تشتغل.', style: TextStyle(color: Ink2.muted, fontSize: 13)),
            if (_note != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(_note!)),
          ],
        ),
      ),
      actions: [
        if ((prints ?? 0) > 0) TextButton(onPressed: _busy ? null : _wipe, style: TextButton.styleFrom(foregroundColor: Ink2.high), child: const Text('امسح وجهي')),
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('سدّ')),
        FilledButton(onPressed: _busy || prints == null ? null : _add, child: Text((prints ?? 0) == 0 ? 'سجّل وجهي' : 'أضف صورة')),
      ],
    );
  }
}
