import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/face_camera.dart';
import '../core/session.dart';
import '../core/ui.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.session});

  final Session session;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _username = TextEditingController();
  final _password = TextEditingController();
  String? _error;
  bool _busy = false;

  Future<void> _submit() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await widget.session.login(_username.text.trim(), _password.text);
    } on ApiError catch (error) {
      setState(() => _error = error.message);
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _face() async {
    final image = await captureFace(context, title: 'الدخول بالوجه', action: 'ادخل');
    if (image == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await widget.session.loginWithFace(image);
    } on ApiError catch (error) {
      setState(() => _error = error.message);
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SizedBox(
          width: 380,
          child: Panel(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('نظام المكتب', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
                  const Text('سجّل دخولك', style: TextStyle(color: Ink2.muted)),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _username,
                    autofocus: true,
                    textDirection: TextDirection.ltr,
                    decoration: const InputDecoration(labelText: 'اسم المستخدم'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _password,
                    obscureText: true,
                    textDirection: TextDirection.ltr,
                    onSubmitted: (_) => _submit(),
                    decoration: const InputDecoration(labelText: 'كلمة المرور'),
                  ),
                  if (_error != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Text(_error!, style: const TextStyle(color: Ink2.high)),
                    ),
                  const SizedBox(height: 16),
                  FilledButton(onPressed: _busy ? null : _submit, child: const Text('دخول')),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _busy ? null : _face,
                    icon: const Icon(Icons.face_retouching_natural_outlined),
                    label: const Text('دخول بالوجه'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
