import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/ui.dart';
import 'images.dart';

/// سجل الكتب الواردة والصادرة. الكتاب الوارد يوصل للشخصية، وهامشها يصير مهمة ويا صورة الكتاب.
class LettersScreen extends StatefulWidget {
  const LettersScreen({super.key, required this.api, required this.refresh, required this.canWrite});

  final Api api;
  final Listenable refresh;
  final bool canWrite;

  @override
  State<LettersScreen> createState() => _LettersScreenState();
}

class _LettersScreenState extends State<LettersScreen> {
  String _direction = 'incoming';
  int _version = 0;

  Future<void> _add() async {
    final saved = await showDialog<bool>(context: context, builder: (_) => NewLetter(api: widget.api, direction: _direction));
    if (saved == true) setState(() => _version++);
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'الكتب',
      subtitle: 'سجّل الكتاب ويا صور صفحاته، والشخصية تهمّشه بصوتها أو على الورق',
      action: widget.canWrite
          ? FilledButton.icon(onPressed: _add, icon: const Icon(Icons.note_add_outlined), label: const Text('تسجيل كتاب'))
          : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'incoming', label: Text('الوارد'), icon: Icon(Icons.move_to_inbox_outlined)),
                ButtonSegment(value: 'outgoing', label: Text('الصادر'), icon: Icon(Icons.outbox_outlined)),
              ],
              selected: {_direction},
              onSelectionChanged: (value) => setState(() => _direction = value.first),
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: Loader<List<Map<String, dynamic>>>(
              key: ValueKey('$_direction-$_version'),
              load: () => widget.api.list('/letters', {'direction': _direction}),
              refresh: widget.refresh,
              builder: (context, letters, reload) {
                if (letters.isEmpty) return Empty(_direction == 'incoming' ? 'ما كو كتب واردة بعد' : 'ما كو كتب صادرة بعد');
                return ListView.separated(
                  itemCount: letters.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, i) => _LetterCard(api: widget.api, letter: letters[i], canWrite: widget.canWrite, reload: reload),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _LetterCard extends StatelessWidget {
  const _LetterCard({required this.api, required this.letter, required this.canWrite, required this.reload});

  final Api api;
  final Map<String, dynamic> letter;
  final bool canWrite;
  final VoidCallback reload;

  Future<void> _paperMargin(BuildContext context) async {
    final done = await showDialog<bool>(context: context, builder: (_) => _PaperMargin(api: api, letter: letter));
    if (done == true) reload();
  }

  @override
  Widget build(BuildContext context) {
    final incoming = letter['direction'] == 'incoming';
    final margin = letter['margin'] as String?;
    final meta = [
      if (letter['party'] != null) '${incoming ? 'من' : 'إلى'} ${letter['party']}',
      if (letter['ref_number'] != null) 'العدد ${letter['ref_number']}',
      if (letter['letter_date'] != null) 'بتاريخ ${(letter['letter_date'] as String).substring(0, 10)}',
    ].join(' · ');
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(child: Text(letter['subject'] as String, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700))),
              if (incoming) Tag(margin == null ? 'بلا هامش' : 'مهمّش', color: margin == null ? Ink2.warn : Ink2.blue),
            ],
          ),
          if (meta.isNotEmpty) Text(meta, style: const TextStyle(color: Ink2.muted)),
          if ((letter['summary'] as String? ?? '').isNotEmpty)
            Padding(padding: const EdgeInsets.only(top: 6), child: Text(letter['summary'] as String, style: const TextStyle(height: 1.6))),
          if (margin != null)
            Container(
              margin: const EdgeInsets.only(top: 8),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: const Color(0xFFEEF2FF), borderRadius: BorderRadius.circular(10)),
              child: Text('الهامش: $margin، إلى ${letter['task_assignee'] ?? '-'} (${statusLabels[letter['task_status']] ?? '-'})'),
            ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Loader<List<Map<String, dynamic>>>(
                  load: () => api.list('/letters/${letter['id']}/images'),
                  builder: (context, pages, _) => Wrap(
                    spacing: 8,
                    children: [for (final p in pages) ImageThumb(api: api, image: {...p, 'purpose': 'letter'})],
                  ),
                ),
              ),
              if (incoming && margin == null && canWrite)
                OutlinedButton(onPressed: () => _paperMargin(context), child: const Text('هامش مكتوب على الورق')),
            ],
          ),
        ],
      ),
    );
  }
}

/// تسجيل كتاب: الموظف يكتب حقوله ويرفق صور صفحاته ويحفظ.
class NewLetter extends StatefulWidget {
  const NewLetter({super.key, required this.api, required this.direction});

  final Api api;
  final String direction;

  @override
  State<NewLetter> createState() => _NewLetterState();
}

class _NewLetterState extends State<NewLetter> {
  final _subject = TextEditingController();
  final _party = TextEditingController();
  final _number = TextEditingController();
  final _date = TextEditingController();
  final _summary = TextEditingController();
  late String _direction = widget.direction;
  final _pages = <XFile>[];

  Future<void> _pick() async {
    final file = await openFile(acceptedTypeGroups: const [
      XTypeGroup(label: 'صور', extensions: ['jpg', 'jpeg', 'png', 'webp']),
    ]);
    if (file == null || !mounted) return;
    setState(() => _pages.add(file));
  }

  Future<void> _save() async {
    if (_subject.text.trim().isEmpty) return;
    final saved = await attempt(context, () async {
      final letter = await widget.api.post('/letters', {
        'direction': _direction,
        'subject': _subject.text.trim(),
        if (_party.text.trim().isNotEmpty) 'party': _party.text.trim(),
        if (_number.text.trim().isNotEmpty) 'ref_number': _number.text.trim(),
        if (RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(_date.text.trim())) 'letter_date': _date.text.trim(),
        if (_summary.text.trim().isNotEmpty) 'summary': _summary.text.trim(),
      }) as Map<String, dynamic>;
      for (final page in _pages) {
        await widget.api.upload('/letters/${letter['id']}/images', page.path);
      }
    });
    if (saved && mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final incoming = _direction == 'incoming';
    return AlertDialog(
      title: const Text('تسجيل كتاب'),
      content: SizedBox(
        width: 520,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SegmentedButton<String>(
                segments: const [ButtonSegment(value: 'incoming', label: Text('وارد')), ButtonSegment(value: 'outgoing', label: Text('صادر'))],
                selected: {_direction},
                onSelectionChanged: (v) => setState(() => _direction = v.first),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  OutlinedButton.icon(
                    onPressed: _pick,
                    icon: const Icon(Icons.add_a_photo_outlined),
                    label: Text(_pages.isEmpty ? 'صورة الكتاب' : 'صفحة ثانية'),
                  ),
                  const SizedBox(width: 12),
                  if (_pages.isNotEmpty) Text('${_pages.length} صفحة', style: const TextStyle(color: Ink2.muted)),
                ],
              ),
              const SizedBox(height: 12),
              TextField(controller: _subject, decoration: const InputDecoration(labelText: 'الموضوع')),
              const SizedBox(height: 10),
              TextField(controller: _party, decoration: InputDecoration(labelText: incoming ? 'الجهة المرسلة' : 'الجهة المرسَل إليها')),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: TextField(controller: _number, decoration: const InputDecoration(labelText: 'العدد'))),
                  const SizedBox(width: 10),
                  Expanded(child: TextField(controller: _date, decoration: const InputDecoration(labelText: 'التاريخ', hintText: '2026-11-07'))),
                ],
              ),
              const SizedBox(height: 10),
              TextField(controller: _summary, maxLines: 3, decoration: const InputDecoration(labelText: 'الملخص')),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
        FilledButton(onPressed: _save, child: const Text('حفظ')),
      ],
    );
  }
}

/// هامش كتبته الشخصية بيدها على الورق: مدير المكتب يدخله فيصير مهمة.
class _PaperMargin extends StatefulWidget {
  const _PaperMargin({required this.api, required this.letter});

  final Api api;
  final Map<String, dynamic> letter;

  @override
  State<_PaperMargin> createState() => _PaperMarginState();
}

class _PaperMarginState extends State<_PaperMargin> {
  final _margin = TextEditingController();
  String? _to;
  String _priority = 'normal';
  int _days = 2;

  Future<void> _save() async {
    if (_to == null || _margin.text.trim().isEmpty) return;
    final done = await attempt(context, () => widget.api.post('/letters/${widget.letter['id']}/margin', {
          'assignee_id': _to,
          'margin': _margin.text.trim(),
          'priority': _priority,
          'due_in_hours': _days * 24,
        }));
    if (done && mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('هامش: ${widget.letter['subject']}'),
      content: SizedBox(
        width: 460,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Loader<List<Map<String, dynamic>>>(
              load: () => widget.api.list('/directory'),
              builder: (context, people, _) => DropdownButtonFormField<String>(
                initialValue: _to,
                decoration: const InputDecoration(labelText: 'إلى'),
                items: [for (final p in people) DropdownMenuItem(value: p['id'] as String, child: Text(p['full_name'] as String))],
                onChanged: (v) => setState(() => _to = v),
              ),
            ),
            const SizedBox(height: 10),
            TextField(controller: _margin, decoration: const InputDecoration(labelText: 'نص الهامش', hintText: 'للدراسة وبيان الرأي')),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<int>(
                    initialValue: _days,
                    decoration: const InputDecoration(labelText: 'المدة'),
                    items: const [
                      DropdownMenuItem(value: 1, child: Text('يوم')),
                      DropdownMenuItem(value: 2, child: Text('يومين')),
                      DropdownMenuItem(value: 7, child: Text('أسبوع')),
                      DropdownMenuItem(value: 30, child: Text('شهر')),
                    ],
                    onChanged: (v) => setState(() => _days = v!),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: _priority,
                    decoration: const InputDecoration(labelText: 'الأهمية'),
                    items: const [
                      DropdownMenuItem(value: 'normal', child: Text('عادية')),
                      DropdownMenuItem(value: 'high', child: Text('عالية')),
                    ],
                    onChanged: (v) => setState(() => _priority = v!),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
        FilledButton(onPressed: _save, child: const Text('حوّلها مهمة')),
      ],
    );
  }
}
