import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/ui.dart';

const _roles = {
  'office_manager': 'مدير المكتب',
  'minutes_officer': 'مسؤول المحاضر',
  'follow_up': 'مسؤول المتابعة',
  'secretary': 'السكرتير',
  'employee': 'موظف',
};

/// مدير النظام: إضافة الموظفين وتغيير أسمائهم ومناصبهم.
class UsersScreen extends StatefulWidget {
  const UsersScreen({super.key, required this.api});

  final Api api;

  @override
  State<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  int _version = 0;

  Future<void> _edit([Map<String, dynamic>? user]) async {
    final saved = await showDialog<bool>(context: context, builder: (_) => _UserForm(api: widget.api, user: user));
    if (saved == true) setState(() => _version++);
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'الموظفون',
      subtitle: 'الاسم والمنصب هنا هو اللي يعرفه الذكاء',
      action: FilledButton(onPressed: _edit, child: const Text('+ موظف')),
      child: Loader<List<Map<String, dynamic>>>(
        key: ValueKey(_version),
        load: () => widget.api.list('/users'),
        builder: (context, users, _) => ListView.separated(
          itemCount: users.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, i) {
            final user = users[i];
            return Panel(
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(user['full_name'] as String, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                        Text(user['job_title'] as String? ?? '-', style: const TextStyle(color: Ink2.muted)),
                      ],
                    ),
                  ),
                  if (user['is_active'] != true) const Tag('معطّل', color: Ink2.high),
                  const SizedBox(width: 8),
                  OutlinedButton(onPressed: () => _edit(user), child: const Text('تعديل')),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _UserForm extends StatefulWidget {
  const _UserForm({required this.api, this.user});

  final Api api;
  final Map<String, dynamic>? user;

  @override
  State<_UserForm> createState() => _UserFormState();
}

class _UserFormState extends State<_UserForm> {
  late final _name = TextEditingController(text: widget.user?['full_name'] as String?);
  late final _job = TextEditingController(text: widget.user?['job_title'] as String?);
  final _username = TextEditingController();
  final _password = TextEditingController();
  String _role = 'employee';

  bool get _isNew => widget.user == null;

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.isEmpty) return;
    final job = _job.text.trim().isEmpty ? null : _job.text.trim();
    final done = await attempt(context, () async {
      if (_isNew) {
        await widget.api.post('/users', {
          'username': _username.text.trim(),
          'full_name': name,
          'job_title': job,
          'role_code': _role,
          'password': _password.text,
        });
      } else {
        await widget.api.patch('/users/${widget.user!['id']}', {'full_name': name, 'job_title': job});
      }
    });
    if (done && mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(_isNew ? 'موظف جديد' : 'تعديل موظف'),
      content: SizedBox(
        width: 420,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(controller: _name, autofocus: true, decoration: const InputDecoration(labelText: 'الاسم')),
            const SizedBox(height: 12),
            TextField(controller: _job, decoration: const InputDecoration(labelText: 'المنصب')),
            if (_isNew) ...[
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: _role,
                decoration: const InputDecoration(labelText: 'الدور'),
                items: [for (final r in _roles.entries) DropdownMenuItem(value: r.key, child: Text(r.value))],
                onChanged: (value) => setState(() => _role = value!),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _username,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(labelText: 'اسم المستخدم'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _password,
                obscureText: true,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(labelText: 'كلمة المرور، 8 أحرف على الأقل'),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
        FilledButton(onPressed: _save, child: const Text('حفظ')),
      ],
    );
  }
}
