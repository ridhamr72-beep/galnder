import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/platform.dart';
import '../core/ui.dart';
import 'images.dart';

/// هل وصلت المهمة، ومتى فُتحت.
class SentScreen extends StatelessWidget {
  const SentScreen({super.key, required this.api, required this.refresh});

  final Api api;
  final Listenable refresh;

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'ما أرسلته',
      subtitle: 'هل وصلت، ومتى انفتحت',
      child: Loader<List<Map<String, dynamic>>>(
        load: () => api.list('/tasks/sent'),
        refresh: refresh,
        builder: (context, tasks, reload) {
          if (tasks.isEmpty) return const Empty('ما أرسلت مهام بعد');
          return ListView.separated(
            itemCount: tasks.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) => TaskLine(task: tasks[i], api: api),
          );
        },
      ),
    );
  }
}

class TaskLine extends StatelessWidget {
  const TaskLine({super.key, required this.task, required this.api});

  final Map<String, dynamic> task;
  final Api api;

  void _images(BuildContext context) {
    final open = task['status'] != 'closed' && task['status'] != 'cancelled';
    showDialog<void>(
      context: context,
      builder: (dialog) => AlertDialog(
        title: Text(task['title'] as String),
        content: SizedBox(width: 460, child: TaskImages(api: api, taskId: task['id'] as String, canAttach: open)),
        actions: [TextButton(onPressed: () => Navigator.pop(dialog), child: const Text('سدّ'))],
      ),
    );
  }

  (String, Color) get _receipt {
    if (task['device_not_reached'] == true) return ('الجهاز غير متصل', Ink2.muted);
    final opened = task['opened_at'] as String?;
    if (opened != null) return ('فُتحت ${shortTime(opened)}', Ink2.good);
    return ('وصلت ولم تُفتح', Ink2.warn);
  }

  @override
  Widget build(BuildContext context) {
    final (receipt, color) = _receipt;
    final tag = Tag(statusLabels[task['status']] ?? '${task['status']}', color: task['is_overdue'] == true ? Ink2.high : Ink2.muted);
    final images = IconButton(tooltip: 'الصور', icon: const Icon(Icons.photo_library_outlined), onPressed: () => _images(context));
    if (formFactor(context) == FormFactor.phone) {
      return Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [Expanded(child: Text(task['title'] as String, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))), tag]),
            const SizedBox(height: 4),
            Row(children: [
              Expanded(child: Text('${task['assignee_name']}  ·  $receipt', style: TextStyle(color: color, fontWeight: FontWeight.w600))),
              images,
            ]),
          ],
        ),
      );
    }
    return Panel(
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(task['title'] as String, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          ),
          Expanded(flex: 2, child: Text(task['assignee_name'] as String)),
          Expanded(flex: 2, child: Text(receipt, style: TextStyle(color: color, fontWeight: FontWeight.w700))),
          tag,
          images,
        ],
      ),
    );
  }
}
