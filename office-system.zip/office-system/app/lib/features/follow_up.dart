import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/platform.dart';
import '../core/ui.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key, required this.api, required this.refresh});

  final Api api;
  final Listenable refresh;

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'اللوحة',
      child: Loader<Map<String, dynamic>>(
        load: () async => await api.get('/dashboard/overview') as Map<String, dynamic>,
        refresh: refresh,
        builder: (context, data, _) {
          final overdue = (data['overdue'] as List).cast<Map<String, dynamic>>();
          final notOpened = (data['not_opened'] as List).cast<Map<String, dynamic>>();
          return ListView(
            children: [
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  _Stat('متأخرة', overdue.length, Ink2.high),
                  _Stat('قريبة الانتهاء', (data['due_soon'] as List).length, Ink2.ink),
                  _Stat('لم تُفتح', notOpened.length, Ink2.ink),
                  _Stat('بانتظار المراجعة', (data['awaiting_review'] as List).length, Ink2.blue),
                ],
              ),
              const SizedBox(height: 24),
              if (overdue.isNotEmpty) ...[
                const Text('المتأخرة', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                const SizedBox(height: 10),
                for (final t in overdue)
                  _Row(t['title'] as String, t['assignee'] as String, 'متأخرة ${duration(t['overdue_s'] as num?)}', Ink2.high),
              ],
              if (notOpened.isNotEmpty) ...[
                const SizedBox(height: 16),
                const Text('لم تُفتح', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                const SizedBox(height: 10),
                for (final t in notOpened)
                  _Row(t['title'] as String, t['assignee'] as String,
                      t['device_not_reached'] == true ? 'الجهاز غير متصل' : 'تنتظر منذ ${duration(t['waiting_s'] as num?)}',
                      t['device_not_reached'] == true ? Ink2.muted : Ink2.warn),
              ],
            ],
          );
        },
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat(this.label, this.value, this.color);

  final String label;
  final int value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    // بالهاتف: مربعين بكل سطر يملون العرض.
    final phone = formFactor(context) == FormFactor.phone;
    return SizedBox(
      width: phone ? (MediaQuery.sizeOf(context).width - pagePadding(context) * 2 - 12) / 2 : 190,
      child: Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(color: Ink2.muted)),
            Text('$value', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w700, color: color)),
          ],
        ),
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row(this.title, this.who, this.state, this.color);

  final String title;
  final String who;
  final String state;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Panel(
        child: formFactor(context) == FormFactor.phone
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Row(children: [Expanded(child: Text(who, style: const TextStyle(color: Ink2.muted))), Text(state, style: TextStyle(color: color, fontWeight: FontWeight.w700))]),
                ],
              )
            : Row(
                children: [
                  Expanded(flex: 3, child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700))),
                  Expanded(flex: 2, child: Text(who)),
                  Text(state, style: TextStyle(color: color, fontWeight: FontWeight.w700)),
                ],
              ),
      ),
    );
  }
}

class ReviewScreen extends StatelessWidget {
  const ReviewScreen({super.key, required this.api, required this.refresh});

  final Api api;
  final Listenable refresh;

  Future<void> _return(BuildContext context, Map<String, dynamic> task, VoidCallback reload) async {
    final note = TextEditingController();
    final send = await showDialog<bool>(
      context: context,
      builder: (dialog) => AlertDialog(
        title: const Text('سبب الإرجاع'),
        content: SizedBox(width: 400, child: TextField(controller: note, autofocus: true, maxLines: 3)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialog), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(dialog, true), child: const Text('إرجاع')),
        ],
      ),
    );
    if (send != true || !context.mounted) return;
    final done = await attempt(context,
        () => api.post('/tasks/${task['id']}/review', {'decision': 'returned', 'note': note.text.trim()}));
    if (done) reload();
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'المراجعة',
      child: Loader<List<Map<String, dynamic>>>(
        load: () => api.list('/tasks/review-queue'),
        refresh: refresh,
        builder: (context, tasks, reload) {
          if (tasks.isEmpty) return const Empty('ما كو شي ينتظر مراجعتك');
          return ListView.separated(
            itemCount: tasks.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final task = tasks[i];
              return Panel(
                child: CardRow(
                  body: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(task['title'] as String, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                      Text('${task['assignee_name']}: ${task['result_text']}', style: const TextStyle(color: Ink2.muted)),
                    ],
                  ),
                  actions: [
                    OutlinedButton(onPressed: () => _return(context, task, reload), child: const Text('إرجاع')),
                    FilledButton(
                      onPressed: () async {
                        final done = await attempt(context, () => api.post('/tasks/${task['id']}/review', {'decision': 'accepted'}));
                        if (done) reload();
                      },
                      child: const Text('إغلاق المهمة'),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class PerformanceScreen extends StatelessWidget {
  const PerformanceScreen({super.key, required this.api});

  final Api api;

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'الالتزام',
      child: Loader<List<Map<String, dynamic>>>(
        load: () => api.list('/dashboard/performance'),
        builder: (context, people, _) {
          if (people.isEmpty) return const Empty('ما كو بيانات بعد');
          return SingleChildScrollView(
            child: Panel(
              // على الهاتف الجدول أعرض من الشاشة: ينسحب يمين ويسار.
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                columns: const [
                  DataColumn(label: Text('الموظف')),
                  DataColumn(label: Text('المهام')),
                  DataColumn(label: Text('أنجز بالموعد')),
                  DataColumn(label: Text('متأخرة الآن')),
                  DataColumn(label: Text('معدل الاستلام')),
                  DataColumn(label: Text('معدل التنفيذ')),
                ],
                rows: [
                  for (final p in people)
                    DataRow(cells: [
                      DataCell(Text(p['assignee'] as String)),
                      DataCell(Text('${p['total_tasks']}')),
                      DataCell(Text('${p['closed_on_time']}')),
                      DataCell(Text('${p['overdue_now']}')),
                      DataCell(Text(duration(p['avg_receipt_delay_s'] as num?))),
                      DataCell(Text(duration(p['avg_execution_s'] as num?))),
                    ]),
                ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
