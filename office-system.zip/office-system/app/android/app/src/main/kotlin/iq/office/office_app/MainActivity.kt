package iq.office.office_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
