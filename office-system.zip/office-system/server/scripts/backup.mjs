// Backs up the database (exported table by table) and .env into a dated folder under BACKUP_DIR
// (default %USERPROFILE%\office-backups), keeping the newest BACKUP_KEEP (default 7). Each backup has a RESTORE.txt
// saying how to put it back.
// Usage: npm run backup              (schedule it nightly with Windows Task Scheduler or cron)
//        npm run backup -- --dry-run (shows what would be copied and deleted, changes nothing)
//        node scripts/backup.mjs --status (the backup folder and its backups as JSON)
// The result is also appended to data/logs/backup.log, since a scheduled run has no window.
import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { backupName, backupSettings, backupSources, backupsToDelete, listBackups, runBackup, savedPath } from './lib/backup.mjs';
import { createLogFile, logSettings, timestamp } from './lib/log-file.mjs';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
dotenv.config({ path: join(root, '.env'), quiet: true });

const logs = logSettings(root);
const log = logs.dir && createLogFile(join(logs.dir, 'backup.log'), { maxBytes: 1024 * 1024, keep: 2 });
const say = (line, out = process.stdout) => {
  out.write(line + '\n');
  log?.write(`${timestamp()} ${line}\n`);
};
const mb = (bytes) => `${(bytes / 1024 / 1024).toFixed(1)} MB`;

try {
  if (process.argv.includes('--status')) {
    // Where backups go, how many are kept, and the finished ones (oldest first), as JSON.
    const { dir, keep } = backupSettings(root, process.env);
    console.log(JSON.stringify({ dir, keep, backups: await listBackups(dir) }));
  } else if (process.argv.includes('--dry-run')) {
    const sources = backupSources(root);
    const { dir, keep } = backupSettings(root, process.env, sources);
    const name = backupName(new Date());
    console.log(`would back up into ${join(dir, name)}:`);
    for (const source of sources) {
      console.log(`  ${source.path} -> files\\${savedPath(root, source)}${existsSync(source.path) ? '' : '  (missing, skipped)'}`);
    }
    const deleted = backupsToDelete([...(await listBackups(dir)), name], keep);
    console.log(`keeping the newest ${keep}${deleted.length ? `, deleting ${deleted.join(', ')}` : ''}`);
  } else {
    const started = Date.now();
    const result = await runBackup({ root });
    const saved = result.items.filter((item) => !item.missing);
    const bytes = saved.reduce((sum, item) => sum + item.bytes, 0);
    const files = saved.reduce((sum, item) => sum + item.files, 0);
    const missing = result.items.filter((item) => item.missing).map((item) => (item.error ? `${item.name} (${item.error})` : item.name));
    say(
      `backup ${result.target}: ${files} files, ${mb(bytes)} in ${((Date.now() - started) / 1000).toFixed(1)} s` +
        (missing.length ? `; not found, skipped: ${missing.join(', ')}` : '') +
        (result.deleted.length ? `; deleted old: ${result.deleted.join(', ')}` : '') +
        `; ${result.kept.length} kept`,
    );
  }
} catch (err) {
  say(`backup failed: ${err.message}`, process.stderr);
  process.exitCode = 1;
} finally {
  log?.close();
}
