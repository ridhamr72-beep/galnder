// One command for a new machine: installs and builds the server and makes .env. Safe to run again: it skips what is
// done. Usage: npm run setup      then: npm start   (the API answers on http://localhost:8000)
// Uses only Node's own modules, so it runs before `npm ci`.
import { spawnSync } from 'node:child_process';
import { copyFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const windows = process.platform === 'win32';
const say = (text) => console.log(`\n\x1b[32m==>\x1b[0m ${text}`);

function run(cmd, args) {
  const r = spawnSync(cmd, args, { cwd: root, stdio: 'inherit', shell: windows });
  if (r.status !== 0) {
    console.error(`\n${cmd} ${args.join(' ')} failed (exit ${r.status}). Fix the error above and run npm run setup again.`);
    process.exit(1);
  }
}

const major = Number(process.versions.node.split('.')[0]);
if (major < 22) {
  console.error(`Node ${process.versions.node} is too old: install Node 22 or newer from https://nodejs.org`);
  process.exit(1);
}

say('1/3 packages (PostgreSQL for a development machine comes with them)');
run('npm', ['ci']);

say('2/3 build');
run('npm', ['run', 'build']);

say('3/3 settings (.env)');
const envPath = join(root, '.env');
if (existsSync(envPath)) {
  console.log('.env is already there: left as it is.');
} else {
  copyFileSync(join(root, '.env.example'), envPath);
  console.log('made .env from .env.example (the demo office is on: OFFICE_DEMO=true)');
}

console.log(`
Done. Start it:

  npm start

The API answers on http://localhost:8000 (GET /health). Demo sign-in for the staff app: sami, mustafa, ali, zainab
or admin, password office-dev-1 (for trying only). A key for the AI system:

  npm run db -- api-key "نظام الذكاء"

The staff app (Flutter) is built from ../app: see ../docs/08-flutter-app.md.
`);
