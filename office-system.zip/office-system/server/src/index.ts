import dotenv from 'dotenv';
import { fileURLToPath } from 'node:url';
import { ConfigError, loadConfig, type Config } from './config.js';
import { startEmbeddedDb, type EmbeddedDb } from './db/embedded.js';
import { DEMO_PASSWORD, seedDemo } from './office/demo.js';
import { buildServer } from './server.js';
import { createLogger } from './utils/logger.js';

dotenv.config({ quiet: true });

let config: Config;
try {
  config = loadConfig();
} catch (err) {
  if (err instanceof ConfigError) {
    console.error(err.message);
    console.error('Copy .env.example to .env and fill in the values.');
    process.exit(1);
  }
  throw err;
}

const logger = createLogger({ level: config.logLevel, pretty: config.logPretty });

// No DATABASE_URL: the server runs its own PostgreSQL (a development machine).
let embeddedDb: EmbeddedDb | undefined;
if (!config.databaseUrl && config.embeddedDb) {
  try {
    embeddedDb = await startEmbeddedDb({ ...config.embeddedDb, log: logger });
    config = { ...config, databaseUrl: embeddedDb.url };
  } catch (err) {
    logger.fatal({ err }, 'the database did not start; set DATABASE_URL to the office PostgreSQL');
    process.exit(1);
  }
}

const app = await buildServer({ config, logger });

// A new machine opens on a working office (OFFICE_DEMO=true): the demo people and a day of work, once.
if (config.officeDemo) {
  try {
    if (await seedDemo(app.office.context, fileURLToPath(new URL('..', import.meta.url)))) {
      app.log.warn(`demo office added: users admin, sami, mustafa, ali, zainab, boss, password ${DEMO_PASSWORD} (for trying only; set OFFICE_DEMO=false for a real office)`);
    }
  } catch (err) {
    app.log.error({ err }, 'could not add the demo office');
  }
}

let shuttingDown = false;
async function shutdown(signal: string): Promise<void> {
  if (shuttingDown) return;
  shuttingDown = true;
  app.log.info({ signal }, 'shutting down: no new requests, waiting for in-flight ones');
  const force = setTimeout(() => {
    app.log.error({ timeoutMs: config.shutdownTimeoutMs }, 'graceful shutdown timed out, forcing exit');
    process.exit(1);
  }, config.shutdownTimeoutMs);
  force.unref();
  try {
    await app.close();
    await embeddedDb?.stop();
    app.log.info('shutdown complete');
    process.exit(0);
  } catch (err) {
    app.log.error({ err }, 'error during shutdown');
    process.exit(1);
  }
}

// SIGBREAK = Ctrl+Break on Windows.
for (const signal of ['SIGINT', 'SIGTERM', 'SIGBREAK'] as const) {
  process.once(signal, () => void shutdown(signal));
}
process.on('unhandledRejection', (reason) => app.log.error({ err: reason }, 'unhandled promise rejection'));
process.on('uncaughtException', (err) => {
  app.log.fatal({ err }, 'uncaught exception');
  void shutdown('uncaughtException');
});

try {
  await app.listen({ host: config.host, port: config.port });
  app.log.info({ port: config.port }, 'office server ready');
} catch (err) {
  app.log.fatal({ err }, 'failed to start server');
  process.exit(1);
}
