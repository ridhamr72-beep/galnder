import { randomBytes } from 'node:crypto';
import type { FastifyInstance, FastifyRequest } from 'fastify';
import { z } from 'zod';
import type { Db } from '../db/index.js';
import { hashToken, requirePermission } from '../office/auth.js';
import type { OfficeContext } from '../office/context.js';
import { recordEvent, SYSTEM, type Actor } from '../office/events.js';
import { AppError } from '../utils/errors.js';
import { parseBody } from '../utils/http.js';

/**
 * Service keys: how another program (the AI system) uses the office. A key is `ok_<prefix>_<secret>`; only its hash is
 * kept and it is shown once, when the admin makes it. Each key carries scopes, so a program gets only what it needs.
 */

export const SCOPES = [
  /** Read: people, tasks, letters, the briefing, the office's facts, announcements, the record of events. */
  'ai.read',
  /** Tasks for the principal: create, cancel, hand to someone else, more time, accept or return, a letter's margin. */
  'ai.tasks.write',
  /** The rest of what the principal does: appointments, messages to staff, marking what she heard. */
  'ai.office.write',
] as const;
export type Scope = (typeof SCOPES)[number];

export interface ServiceKey {
  id: string;
  name: string;
  scopes: Set<string>;
}

/** The actor a service key acts as: the AI, on the principal's behalf, named in every event it causes. */
export const keyActor = (key: ServiceKey): Actor => ({ type: 'ai', keyId: key.id });

export async function createServiceKey(db: Db, createdBy: string | null, name: string, scopes: string[]) {
  const unknown = scopes.filter((s) => !(SCOPES as readonly string[]).includes(s));
  if (unknown.length) throw new AppError(400, 'UNKNOWN_SCOPE', 'نطاق غير معروف', { details: { scopes: unknown, known: SCOPES } });
  const prefix = randomBytes(4).toString('hex');
  const token = `ok_${prefix}_${randomBytes(32).toString('hex')}`;
  const unique = [...new Set(scopes)];
  const [row] = await db.query<{ id: string }>(
    `INSERT INTO api_keys (name, key_prefix, key_hash, scopes, created_by) VALUES ($1, $2, $3, $4, $5) RETURNING id`,
    [name, prefix, hashToken(token), unique, createdBy]);
  await recordEvent(db, createdBy ? { type: 'user', userId: createdBy } : SYSTEM, 'api_key.created', { type: 'api_key', id: row!.id },
    `أُنشئ مفتاح خدمة: ${name}`, { scopes: unique });
  // The only time the key leaves the server.
  return { id: row!.id, name, scopes: unique, api_key: token };
}

function presented(request: FastifyRequest): string | undefined {
  const header = request.headers.authorization;
  if (header?.startsWith('Bearer ')) return header.slice(7).trim();
  const direct = request.headers['x-api-key'];
  return (Array.isArray(direct) ? direct[0] : direct)?.trim() || undefined;
}

/** The key a request carries, if it is a live one. */
export async function authenticateKey(db: Db, token: string): Promise<ServiceKey | undefined> {
  const parts = token.split('_');
  if (parts.length !== 3 || parts[0] !== 'ok' || !parts[1]) return undefined;
  const [key] = await db.query<{ id: string; name: string; scopes: string[] }>(
    `UPDATE api_keys SET last_used_at = now() WHERE key_prefix = $1 AND key_hash = $2 AND revoked_at IS NULL
     RETURNING id, name, scopes`, [parts[1], hashToken(token)]);
  return key && { id: key.id, name: key.name, scopes: new Set(key.scopes) };
}

/** A request from a program with a live key holding `scope`; 401 without a key, 403 without the scope. */
export async function requireScope(db: Db, request: FastifyRequest, scope: Scope): Promise<ServiceKey> {
  const token = presented(request);
  const key = token ? await authenticateKey(db, token) : undefined;
  if (!key) throw new AppError(401, 'INVALID_API_KEY', 'مفتاح الخدمة غير صالح');
  if (!key.scopes.has(scope)) throw new AppError(403, 'MISSING_SCOPE', 'المفتاح لا يملك هذا النطاق', { details: { scope } });
  return key;
}

const KeyBody = z.object({
  name: z.string().trim().min(1).max(100),
  scopes: z.array(z.string()).min(1).default([...SCOPES]),
});

/** The admin's screen for service keys (permission api_keys.manage). */
export function keyRoutes(app: FastifyInstance, office: OfficeContext): void {
  const { db } = office;

  app.get('/api/v1/api-keys', async (request) => {
    requirePermission(await office.user(request), 'api_keys.manage');
    const items = await db.query(
      `SELECT k.id, k.name, k.key_prefix, k.scopes, k.created_at, u.full_name AS created_by, k.last_used_at, k.revoked_at
       FROM api_keys k LEFT JOIN users u ON u.id = k.created_by ORDER BY k.created_at DESC`);
    return { items, scopes: SCOPES, next_cursor: null };
  });

  app.post('/api/v1/api-keys', async (request, reply) => {
    const admin = await office.user(request);
    requirePermission(admin, 'api_keys.manage');
    const body = parseBody(KeyBody, request.body);
    return reply.code(201).send(await office.tx((tx) => createServiceKey(tx, admin.id, body.name, body.scopes)));
  });

  app.post<{ Params: { id: string } }>('/api/v1/api-keys/:id/revoke', async (request, reply) => {
    const admin = await office.user(request);
    requirePermission(admin, 'api_keys.manage');
    await office.tx(async (tx) => {
      const [key] = await tx.query<{ name: string }>(
        'UPDATE api_keys SET revoked_at = now() WHERE id = $1 AND revoked_at IS NULL RETURNING name', [request.params.id]);
      if (!key) throw new AppError(404, 'KEY_NOT_FOUND', 'المفتاح غير موجود');
      await recordEvent(tx, { type: 'user', userId: admin.id }, 'api_key.revoked', { type: 'api_key', id: request.params.id }, `أُلغي مفتاح خدمة: ${key.name}`);
    });
    return reply.code(204).send();
  });
}
