import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { z } from 'zod';
import type { Db } from '../db/index.js';
import { markSpoken, pendingAnnouncements, today } from '../office/announce.js';
import { signedFileUrl } from '../office/attachments.js';
import { buildBriefing, markBriefingSeen } from '../office/briefing.js';
import type { After, OfficeContext } from '../office/context.js';
import { recordEvent } from '../office/events.js';
import { marginLetter } from '../office/letters.js';
import { markRead, sendMessage, unreadForPrincipal } from '../office/messages.js';
import { normalizeArabic, resolvePerson, searchPatterns, staff, type Person } from '../office/people.js';
import { notify } from '../office/push.js';
import { localClock, performance, timeZone, zoneOffset } from '../office/reports.js';
import { cancelTask, createTask, extendTask, reassignTask, resolveDue, reviewTask } from '../office/tasks.js';
import { AppError } from '../utils/errors.js';
import { parseBody } from '../utils/http.js';
import { keyActor, requireScope, type Scope, type ServiceKey } from './keys.js';

/**
 * /api/v1/ai/* — the AI system's door into the office. The AI listens to the principal and decides what she wants;
 * the office does it: finds the person, stores it, rings the staff's phones, keeps the record. The AI never writes to
 * the database: everything goes through the same functions the staff app uses, so the same rules apply.
 *
 * Every change is recorded as done by the AI on the principal's behalf, with the key that did it. A retried order with
 * the same `Idempotency-Key` header gets the first answer again and is not done twice. Contract: docs/07-ai-integration.md.
 */

const Iso = z.iso.datetime({ offset: true });
const Uuid = z.uuid();

/** A staff member as said (`*_query`: a name, a post, a nickname) or by id; the office resolves the first. */
const Who = (field: string) => ({ [`${field}_query`]: z.string().trim().min(1).max(200).optional(), [`${field}_id`]: Uuid.optional() });

const NewTaskBody = z.object({
  ...Who('assignee'),
  title: z.string().trim().min(1).max(300),
  description: z.string().max(10_000).default(''),
  priority: z.enum(['normal', 'high']).default('normal'),
  due_at: Iso.optional(),
  due_in_hours: z.number().int().positive().max(24 * 365).optional(),
  original_utterance: z.string().trim().min(1).max(4000),
});
const ReasonBody = z.object({ reason: z.string().trim().min(1).max(2000) });
const ReassignBody = z.object({ ...Who('assignee'), reason: z.string().trim().min(1).max(2000) });
const ExtendBody = z.object({ due_at: Iso.optional(), due_in_hours: z.number().int().positive().max(24 * 365).optional(), reason: z.string().trim().min(1).max(2000) });
const ReviewBody = z.object({ decision: z.enum(['accepted', 'returned']), note: z.string().trim().max(2000).nullish() });
const MarginBody = z.object({
  ...Who('assignee'),
  margin: z.string().trim().min(1).max(2000),
  priority: z.enum(['normal', 'high']).default('normal'),
  due_at: Iso.optional(),
  due_in_hours: z.number().int().positive().max(24 * 365).optional(),
  // The principal's words as heard: the evidence when a margin went wrong (a spoken task always keeps them).
  original_utterance: z.string().trim().min(1).max(4000),
});
const AppointmentBody = z.object({
  title: z.string().trim().min(1).max(300),
  kind: z.enum(['appointment', 'interview']).default('appointment'),
  starts_at: Iso,
  ends_at: Iso.nullish(),
  location: z.string().trim().max(300).nullish(),
  notes: z.string().trim().max(4000).nullish(),
  /** The guest by name: the one already on file (same name or one of their other names), else a new file. */
  guest: z.string().trim().min(1).max(200).nullish(),
  original_utterance: z.string().trim().max(4000).optional(),
});
const MessageBody = z.object({
  body: z.string().trim().min(1).max(4000),
  /** true = every staff member. */
  all: z.boolean().default(false),
  /** Names as said, or ids. */
  recipients: z.array(z.string().trim().min(1).max(200)).max(50).default([]),
  task_id: Uuid.optional(),
});
const IdsBody = z.object({ ids: z.array(Uuid).min(1).max(200) });

type Answer = { status: number; body: unknown };

const STATUS_AR: Record<string, string> = {
  assigned: 'لم تُفتح بعد', opened: 'فُتحت ولم يباشر بها', in_progress: 'قيد التنفيذ',
  submitted: 'سُلّمت وتنتظر المراجعة', returned: 'رُجّعت للتعديل', closed: 'منتهية', cancelled: 'ملغاة',
};

function onePerson(people: Person[], body: Record<string, unknown>, field: string): Person | undefined {
  const id = body[`${field}_id`] as string | undefined;
  const query = body[`${field}_query`] as string | undefined;
  if (id && query) throw new AppError(400, 'VALIDATION_ERROR', `أرسل ${field}_query أو ${field}_id، لا الاثنين`);
  if (id) {
    const person = people.find((p) => p.id === id);
    if (!person) throw new AppError(400, 'INVALID_ASSIGNEE', 'لا يمكن تكليف هذا المستخدم');
    return person;
  }
  return query ? resolvePerson(people, query) : undefined;
}

function due(db: Db, body: { due_at?: string | undefined; due_in_hours?: number | undefined }): Promise<Date> {
  return resolveDue(db, body.due_at, body.due_in_hours);
}

async function principalId(db: Db): Promise<string | null> {
  const [row] = await db.query<{ id: string }>('SELECT id FROM users WHERE is_principal AND is_active LIMIT 1');
  return row?.id ?? null;
}

const TASK_COLUMNS = `o.id, o.title, o.description, o.priority, o.status, o.source, o.original_utterance, o.assignee_id,
  o.assignee_name AS assignee, o.created_at, o.original_due_at, o.due_at, o.delivered_at, o.opened_at, o.started_at,
  o.completed_at, o.closed_at, o.result_text, o.receipt_delay_s, o.execution_s, o.overdue_s, o.completed_on_time,
  o.is_overdue, o.device_not_reached,
  EXTRACT(EPOCH FROM now() - o.delivered_at)::bigint AS since_delivered_s,
  (SELECT s.result_text FROM task_submissions s WHERE s.task_id = o.id ORDER BY s.attempt_no DESC LIMIT 1) AS handed_in,
  (SELECT s.review_note FROM task_submissions s WHERE s.task_id = o.id AND s.decision = 'returned' ORDER BY s.attempt_no DESC LIMIT 1) AS return_note,
  (SELECT json_build_object('from', CASE WHEN m.from_ai THEN 'الشخصية الأساسية' ELSE u.full_name END, 'body', m.body, 'at', m.created_at)
     FROM messages m LEFT JOIN users u ON u.id = m.sender_id WHERE m.task_id = o.id ORDER BY m.created_at DESC LIMIT 1) AS last_message,
  (SELECT count(*) FROM attachments a WHERE a.task_id = o.id) AS images`;

const LETTER_COLUMNS = `l.id, l.direction, l.ref_number, l.letter_date, l.party, l.subject, l.summary, l.created_at, l.margin,
  l.margined_at, l.task_id, a.full_name AS task_assignee, t.status AS task_status,
  (SELECT count(*) FROM attachments f WHERE f.letter_id = l.id) AS images`;
const LETTER_JOINS = 'FROM letters l LEFT JOIN tasks t ON t.id = l.task_id LEFT JOIN users a ON a.id = t.assignee_id';

/** A guest by name: the one on file (same spelling, or one of their other names), else a new file. */
async function findOrAddPerson(db: Db, name: string): Promise<{ id: string; full_name: string }> {
  const people = await db.query<{ id: string; full_name: string; aliases: string[] }>('SELECT id, full_name, aliases FROM persons');
  const wanted = normalizeArabic(name);
  const known = people.find((p) => [p.full_name, ...p.aliases].some((n) => normalizeArabic(n) === wanted));
  if (known) return known;
  const [row] = await db.query<{ id: string; full_name: string }>('INSERT INTO persons (full_name) VALUES ($1) RETURNING id, full_name', [name]);
  return row!;
}

export function aiRoutes(app: FastifyInstance, office: OfficeContext): void {
  const { db, push } = office;

  const read = (request: FastifyRequest) => requireScope(db, request, 'ai.read');

  /**
   * A change, in one transaction. With an Idempotency-Key the first answer is kept and a retry gets it back; the lock
   * stops two copies of the same order sent at once from both acting.
   */
  function change<P = Record<string, never>>(path: string, scope: Scope,
    act: (tx: Db, after: After, key: ServiceKey, request: FastifyRequest<{ Params: P }>) => Promise<Answer>) {
    app.post<{ Params: P }>(path, async (request, reply: FastifyReply) => {
      const key = await requireScope(db, request, scope);
      const header = request.headers['idempotency-key'];
      const idempotency = typeof header === 'string' && header.trim() ? header.trim().slice(0, 200) : undefined;
      const answer = await office.tx(async (tx, after) => {
        if (idempotency) {
          await tx.query('SELECT pg_advisory_xact_lock(hashtextextended($1, 0))', [`${key.id}:${idempotency}`]);
          const [saved] = await tx.query<{ status: number; response: unknown }>(
            'SELECT status, response FROM idempotency_keys WHERE api_key_id = $1 AND key = $2', [key.id, idempotency]);
          if (saved) return { status: saved.status, body: saved.response, replayed: true };
        }
        const done = await act(tx, after, key, request);
        if (idempotency) {
          await tx.query('INSERT INTO idempotency_keys (api_key_id, key, status, response) VALUES ($1, $2, $3, $4)',
            [key.id, idempotency, done.status, JSON.stringify(done.body ?? null)]);
        }
        return { ...done, replayed: false };
      });
      if (answer.replayed) reply.header('idempotent-replayed', 'true');
      return answer.status === 204 ? reply.code(204).send() : reply.code(answer.status).send(answer.body);
    });
  }

  // ---------- reading ----------

  /** GET /api/v1/ai/health — the key works; which scopes it has. */
  app.get('/api/v1/ai/health', async (request) => {
    const key = await read(request);
    return { status: 'ok', key: key.name, scopes: [...key.scopes].sort() };
  });

  /** GET /api/v1/ai/people — the staff: who a task or a message can go to (never the principal). */
  app.get('/api/v1/ai/people', async (request) => {
    await read(request);
    return { items: await staff(db), next_cursor: null };
  });

  /** GET /api/v1/ai/people/resolve?q= — one person from what was said; 409 with the candidates when two fit. */
  app.get<{ Querystring: { q?: string } }>('/api/v1/ai/people/resolve', async (request) => {
    await read(request);
    const q = request.query.q?.trim();
    if (!q) throw new AppError(400, 'VALIDATION_ERROR', 'q: اكتب الاسم أو المنصب');
    return resolvePerson(await staff(db), q);
  });

  /**
   * GET /api/v1/ai/tasks — without q: the open tasks, soonest due first. With q (words of the title or a name, as said):
   * the best matches over all of history, open ones first. `assignee_id` narrows to one person, `all=true` adds the
   * closed and cancelled ones.
   */
  app.get<{ Querystring: { q?: string; assignee_id?: string; all?: string; limit?: string } }>('/api/v1/ai/tasks', async (request) => {
    await read(request);
    const { q, assignee_id: assignee, all } = request.query;
    if (assignee && !Uuid.safeParse(assignee).success) throw new AppError(400, 'VALIDATION_ERROR', 'assignee_id: uuid');
    const limit = Math.min(Math.max(Number(request.query.limit ?? 30) || 30, 1), 100);
    const patterns = q?.trim() ? searchPatterns(q) : null;
    const rows = await db.query<Record<string, unknown>>(
      `SELECT ${TASK_COLUMNS},
              (SELECT count(*) FROM unnest($1::text[]) p WHERE translate(o.title || ' ' || o.assignee_name, 'أإآةى', 'اااهي') ILIKE p) AS hits
       FROM office_tasks o
       WHERE ($2::uuid IS NULL OR o.assignee_id = $2)
         AND ($1::text[] IS NOT NULL OR $3 OR o.status NOT IN ('closed', 'cancelled'))
       ORDER BY hits DESC, (o.status NOT IN ('closed', 'cancelled')) DESC,
                CASE WHEN $1::text[] IS NULL THEN o.due_at END ASC, o.created_at DESC
       LIMIT $4`,
      [patterns, assignee ?? null, all === 'true', patterns ? 200 : limit]);
    const items = (patterns ? rows.filter((t) => Number(t.hits) > 0).slice(0, limit) : rows)
      .map(({ hits: _hits, ...t }) => ({ ...t, status_ar: STATUS_AR[String(t.status)] ?? t.status }));
    return { items, next_cursor: null };
  });

  /** GET /api/v1/ai/tasks/:id — one task with its handed-in results and messages. */
  app.get<{ Params: { id: string } }>('/api/v1/ai/tasks/:id', async (request) => {
    await read(request);
    if (!Uuid.safeParse(request.params.id).success) throw new AppError(404, 'TASK_NOT_FOUND', 'المهمة غير موجودة');
    const [task] = await db.query(`SELECT ${TASK_COLUMNS} FROM office_tasks o WHERE o.id = $1`, [request.params.id]);
    if (!task) throw new AppError(404, 'TASK_NOT_FOUND', 'المهمة غير موجودة');
    const submissions = await db.query(
      `SELECT attempt_no, result_text, submitted_at, decision, review_note, reviewed_at FROM task_submissions WHERE task_id = $1 ORDER BY attempt_no`,
      [request.params.id]);
    const messages = await db.query(
      `SELECT CASE WHEN m.from_ai THEN 'الشخصية الأساسية' ELSE u.full_name END AS sender, m.body, m.created_at, m.read_at
       FROM messages m LEFT JOIN users u ON u.id = m.sender_id WHERE m.task_id = $1 ORDER BY m.created_at`, [request.params.id]);
    return { ...task, submissions, messages };
  });

  /** GET /api/v1/ai/tasks/:id/images — links good for an hour, to show the principal a task's images. */
  app.get<{ Params: { id: string } }>('/api/v1/ai/tasks/:id/images', async (request) => {
    await read(request);
    if (!Uuid.safeParse(request.params.id).success) throw new AppError(404, 'TASK_NOT_FOUND', 'المهمة غير موجودة');
    const files = await db.query<{ id: string; purpose: string; file_name: string }>(
      'SELECT id, purpose, file_name FROM attachments WHERE task_id = $1 ORDER BY created_at', [request.params.id]);
    return { items: files.map((f) => ({ id: f.id, purpose: f.purpose, file_name: f.file_name, url: signedFileUrl(office.secret, f.id) })) };
  });

  /**
   * GET /api/v1/ai/letters — the last 30 days' letters, newest first; `unmargined=true` only incoming ones still
   * waiting for her margin; with q (words of the subject, sender or number) the best matches first.
   */
  app.get<{ Querystring: { q?: string; unmargined?: string } }>('/api/v1/ai/letters', async (request) => {
    await read(request);
    const patterns = request.query.q?.trim() ? searchPatterns(request.query.q) : null;
    const items = await db.query(
      `SELECT ${LETTER_COLUMNS},
              (SELECT count(*) FROM unnest($1::text[]) p
               WHERE translate(l.subject || ' ' || coalesce(l.party, '') || ' ' || coalesce(l.ref_number, ''), 'أإآةى', 'اااهي') ILIKE p) AS hits
       ${LETTER_JOINS}
       WHERE ($1::text[] IS NOT NULL OR l.created_at > now() - interval '30 days')
         AND (NOT $2 OR (l.direction = 'incoming' AND l.task_id IS NULL))
       ORDER BY hits DESC, (l.task_id IS NULL) DESC, l.created_at DESC LIMIT 30`,
      [patterns, request.query.unmargined === 'true']);
    return { items: patterns ? items.filter((l) => Number(l.hits) > 0) : items, next_cursor: null };
  });

  /** GET /api/v1/ai/letters/:id/images — the letter's pages, as links good for an hour. */
  app.get<{ Params: { id: string } }>('/api/v1/ai/letters/:id/images', async (request) => {
    await read(request);
    if (!Uuid.safeParse(request.params.id).success) throw new AppError(404, 'LETTER_NOT_FOUND', 'الكتاب غير موجود');
    const pages = await db.query<{ id: string }>('SELECT id FROM attachments WHERE letter_id = $1 ORDER BY created_at', [request.params.id]);
    return { items: pages.map((p, i) => ({ id: p.id, page: i + 1, url: signedFileUrl(office.secret, p.id) })) };
  });

  /**
   * GET /api/v1/ai/facts?from=&to=&q= — what the office knows, for answering the principal: the tasks of the days
   * asked (and every open one), or with q the matches over all of history; appointments (the next 7 days when no day
   * is given) with each guest's file; minutes of those days and the decisions of the last month; messages to her not
   * yet read and what she sent this week; letters of the last 14 days; who keeps to time. Dates are YYYY-MM-DD in the
   * office's time zone. Reading marks nothing; POST /api/v1/ai/messages/read when she has heard her messages.
   */
  app.get<{ Querystring: { from?: string; to?: string; q?: string } }>('/api/v1/ai/facts', async (request) => {
    await read(request);
    const day = z.iso.date();
    const { from: rawFrom, to: rawTo, q } = request.query;
    if ((rawFrom && !day.safeParse(rawFrom).success) || (rawTo && !day.safeParse(rawTo).success)) {
      throw new AppError(400, 'VALIDATION_ERROR', 'from/to: YYYY-MM-DD');
    }
    const zone = await timeZone(db);
    const offset = zoneOffset(zone);
    const from = rawFrom ?? localClock(zone).date;
    const to = rawTo ?? rawFrom ?? from;
    if (to < from) throw new AppError(400, 'BAD_PERIOD', 'نهاية الفترة قبل بدايتها');
    const patterns = q?.trim() ? searchPatterns(q) : null;

    const [tasks, appointments, meetings, unread, sent, letters, perf] = await Promise.all([
      db.query(
        `SELECT ${TASK_COLUMNS} FROM office_tasks o
         WHERE CASE WHEN $3::text[] IS NOT NULL
                    THEN translate(o.title || ' ' || o.assignee_name, 'أإآةى', 'اااهي') ILIKE ANY($3) OR o.created_at > now() - interval '1 day'
                    ELSE (o.created_at AT TIME ZONE $4::interval)::date BETWEEN $1::date AND $2::date OR o.status NOT IN ('closed', 'cancelled') END
         ORDER BY o.created_at LIMIT 100`, [from, to, patterns, offset]),
      db.query(
        `SELECT a.id, a.title, a.kind, a.starts_at, a.ends_at, a.location, a.notes, p.full_name AS guest, p.organization, p.notes AS guest_notes,
                (SELECT count(*) FROM appointments b WHERE b.person_id = a.person_id AND b.id <> a.id AND b.cancelled_at IS NULL AND b.starts_at < a.starts_at) AS earlier_visits,
                (SELECT max(b.starts_at) FROM appointments b WHERE b.person_id = a.person_id AND b.id <> a.id AND b.cancelled_at IS NULL AND b.starts_at < a.starts_at) AS last_visit
         FROM appointments a LEFT JOIN persons p ON p.id = a.person_id
         WHERE a.cancelled_at IS NULL AND (a.starts_at AT TIME ZONE $3::interval)::date BETWEEN $1::date AND $2::date + $4::int ORDER BY a.starts_at`,
        [from, to, offset, rawTo || rawFrom ? 0 : 7]),
      db.query(
        `SELECT m.id, m.title, m.held_at, m.location, m.body, m.decisions, u.full_name AS recorded_by
         FROM meetings m JOIN users u ON u.id = m.created_by WHERE m.status = 'published'
           AND ((m.held_at AT TIME ZONE $3::interval)::date BETWEEN $1::date AND $2::date OR (jsonb_array_length(m.decisions) > 0 AND m.held_at > now() - interval '30 days'))
         ORDER BY m.held_at DESC LIMIT 20`, [from, to, offset]),
      unreadForPrincipal(db),
      db.query(
        `SELECT m.id, m.body, u.full_name AS to_name, m.created_at, m.read_at FROM messages m JOIN users u ON u.id = m.recipient_id
         WHERE m.from_ai AND m.created_at > now() - interval '7 days' ORDER BY m.created_at DESC LIMIT 30`),
      db.query(`SELECT ${LETTER_COLUMNS} ${LETTER_JOINS} WHERE l.created_at > now() - interval '14 days' ORDER BY l.created_at DESC LIMIT 30`),
      performance(db),
    ]);
    return {
      now: new Date(), time_zone: zone, period: { from, to }, people: await staff(db),
      tasks, appointments, meetings, messages_to_principal: unread, messages_from_principal: sent, letters, performance: perf,
    };
  });

  /** GET /api/v1/ai/briefing — the principal's briefing: what waits for her, what is late, today, since she last looked. */
  app.get('/api/v1/ai/briefing', async (request) => {
    await read(request);
    return buildBriefing(db);
  });

  /** GET /api/v1/ai/today — today at a glance. */
  app.get('/api/v1/ai/today', async (request) => {
    await read(request);
    return today(db);
  });

  /** GET /api/v1/ai/announcements — what to tell the principal without being asked, urgent first. */
  app.get('/api/v1/ai/announcements', async (request) => {
    await read(request);
    return { items: await pendingAnnouncements(db) };
  });

  /** GET /api/v1/ai/events?after_id=&limit= — the record, in order; keep the last id and nothing is missed. */
  app.get<{ Querystring: { after_id?: string; limit?: string } }>('/api/v1/ai/events', async (request) => {
    await read(request);
    const after = Math.max(Number(request.query.after_id ?? 0) || 0, 0);
    const limit = Math.min(Math.max(Number(request.query.limit ?? 100) || 100, 1), 500);
    const items = await db.query<{ id: number }>(
      `SELECT e.id, e.occurred_at, e.event_type, e.actor_type, u.full_name AS actor_name, e.subject_type, e.subject_id, e.summary, e.visibility
       FROM events e LEFT JOIN users u ON u.id = e.actor_user_id WHERE e.id > $1 ORDER BY e.id LIMIT $2`, [after, limit]);
    return { items, next_cursor: items.at(-1)?.id ?? null };
  });

  // ---------- tasks (ai.tasks.write) ----------

  /** POST /api/v1/ai/tasks — the principal gives someone a task. */
  change('/api/v1/ai/tasks', 'ai.tasks.write', async (tx, after, key, request) => {
    const body = parseBody(NewTaskBody, request.body);
    const person = onePerson(await staff(tx), body, 'assignee');
    if (!person) throw new AppError(400, 'VALIDATION_ERROR', 'أرسل assignee_query أو assignee_id');
    const task = await createTask(tx, push, after, keyActor(key), {
      title: body.title, description: body.description, assigneeId: person.id, priority: body.priority,
      source: 'voice_ai', utterance: body.original_utterance, due: await due(tx, body),
    });
    return { status: 201, body: { id: task.id, status: task.status, priority: task.priority, due_at: task.due_at, assignee: { id: person.id, full_name: task.assignee_name } } };
  });

  /** POST /api/v1/ai/tasks/:id/cancel — { reason }. */
  change<{ id: string }>('/api/v1/ai/tasks/:id/cancel', 'ai.tasks.write', async (tx, after, key, request) => {
    const { reason } = parseBody(ReasonBody, request.body);
    return { status: 200, body: await cancelTask(tx, push, after, taskId(request.params.id), keyActor(key), reason) };
  });

  /** POST /api/v1/ai/tasks/:id/reassign — { assignee_query | assignee_id, reason }: sealed again for the new person. */
  change<{ id: string }>('/api/v1/ai/tasks/:id/reassign', 'ai.tasks.write', async (tx, after, key, request) => {
    const body = parseBody(ReassignBody, request.body);
    const person = onePerson(await staff(tx), body, 'assignee');
    if (!person) throw new AppError(400, 'VALIDATION_ERROR', 'أرسل assignee_query أو assignee_id');
    const moved = await reassignTask(tx, push, after, keyActor(key), taskId(request.params.id), person.id, body.reason);
    return { status: 200, body: { id: moved.id, title: moved.title, assignee: { id: person.id, full_name: moved.assignee_name } } };
  });

  /** POST /api/v1/ai/tasks/:id/extend — { due_at | due_in_hours, reason }; the first due date stays on record. */
  change<{ id: string }>('/api/v1/ai/tasks/:id/extend', 'ai.tasks.write', async (tx, after, key, request) => {
    const body = parseBody(ExtendBody, request.body);
    if (!body.due_at && !body.due_in_hours) throw new AppError(400, 'VALIDATION_ERROR', 'أرسل due_at أو due_in_hours');
    const done = await extendTask(tx, push, after, keyActor(key), taskId(request.params.id), await due(tx, body), body.reason);
    return { status: 200, body: done };
  });

  /** POST /api/v1/ai/tasks/:id/review — { decision: accepted | returned, note }: the principal closes a handed-in task or sends it back. */
  change<{ id: string }>('/api/v1/ai/tasks/:id/review', 'ai.tasks.write', async (tx, after, key, request) => {
    const body = parseBody(ReviewBody, request.body);
    const done = await reviewTask(tx, push, after, keyActor(key), await principalId(tx), taskId(request.params.id), body.decision,
      body.decision === 'returned' ? (body.note ?? null) : null, 'الشخصية الأساسية');
    return { status: 200, body: done };
  });

  /**
   * POST /api/v1/ai/letters/:id/margin — the principal's margin on an incoming letter becomes a task with the letter's
   * pages. With nobody named it goes back to whoever registered the letter, to act on it.
   */
  change<{ id: string }>('/api/v1/ai/letters/:id/margin', 'ai.tasks.write', async (tx, after, key, request) => {
    const body = parseBody(MarginBody, request.body);
    if (!Uuid.safeParse(request.params.id).success) throw new AppError(404, 'LETTER_NOT_FOUND', 'الكتاب غير موجود');
    const people = await staff(tx);
    let person = onePerson(people, body, 'assignee');
    if (!person) {
      const [letter] = await tx.query<{ registered_by: string }>('SELECT registered_by FROM letters WHERE id = $1', [request.params.id]);
      if (!letter) throw new AppError(404, 'LETTER_NOT_FOUND', 'الكتاب غير موجود');
      person = people.find((p) => p.id === letter.registered_by);
      if (!person) throw new AppError(400, 'ASSIGNEE_REQUIRED', 'سجّل الكتاب شخص غير موجود الآن: حدّد لمن الهامش');
    }
    const done = await marginLetter(tx, push, after, keyActor(key), request.params.id, {
      assigneeId: person.id, margin: body.margin, priority: body.priority, due: await due(tx, body), utterance: body.original_utterance,
    });
    return { status: 201, body: { task_id: done.task.id, subject: done.subject, due_at: done.task.due_at, assignee: { id: person.id, full_name: done.task.assignee_name } } };
  });

  // ---------- the rest of the office (ai.office.write) ----------

  /** POST /api/v1/ai/appointments — an appointment for the principal herself; whoever keeps the diary hears of it. */
  change('/api/v1/ai/appointments', 'ai.office.write', async (tx, after, key, request) => {
    const body = parseBody(AppointmentBody, request.body);
    const startsAt = new Date(body.starts_at);
    if (startsAt.getTime() <= Date.now()) throw new AppError(400, 'IN_PAST', 'الموعد في الماضي');
    const principal = await principalId(tx);
    if (!principal) throw new AppError(409, 'NO_PRINCIPAL', 'ما كو حساب للشخصية بالنظام، خلي مدير النظام يضيفه');
    const guest = body.guest ? await findOrAddPerson(tx, body.guest) : null;
    const notes = [body.notes, body.original_utterance && `سجّلته الشخصية بالصوت: ${body.original_utterance}`].filter(Boolean).join('\n') || null;
    const [row] = await tx.query<{ id: string }>(
      `INSERT INTO appointments (title, kind, starts_at, ends_at, location, notes, person_id, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id, title, kind, starts_at, ends_at, location, notes, person_id`,
      [body.title, body.kind, startsAt, body.ends_at ?? null, body.location ?? null, notes, guest?.id ?? null, principal]);
    await recordEvent(tx, keyActor(key), 'appointment.created', { type: 'appointment', id: row!.id }, `موعد جديد للشخصية: ${body.title}`);
    const keepers = await tx.query<{ id: string }>(
      `SELECT DISTINCT u.id FROM users u JOIN role_permissions p ON p.role_id = u.role_id
       WHERE p.permission_code = 'appointments.write' AND u.is_active AND NOT u.is_principal`);
    for (const k of keepers) await notify(tx, push, after, k.id, 'appointment', 'normal', null, false);
    return { status: 201, body: { ...row, guest } };
  });

  /** POST /api/v1/ai/messages — words from the principal to staff, with no task: { body, all | recipients }. */
  change('/api/v1/ai/messages', 'ai.office.write', async (tx, after, key, request) => {
    const body = parseBody(MessageBody, request.body);
    if (body.all === Boolean(body.recipients.length)) throw new AppError(400, 'VALIDATION_ERROR', 'أرسل all: true أو recipients، واحد منهم');
    const everyone = await staff(tx);
    const recipients = body.all ? everyone : body.recipients.map((said) =>
      Uuid.safeParse(said).success ? onePerson(everyone, { recipient_id: said }, 'recipient')! : resolvePerson(everyone, said));
    const unique = [...new Map(recipients.map((p) => [p.id, p])).values()];
    if (!unique.length) throw new AppError(409, 'NO_STAFF', 'ما كو موظفين بالنظام بعد');
    if (body.task_id) {
      const [task] = await tx.query('SELECT 1 FROM tasks WHERE id = $1', [body.task_id]);
      if (!task) throw new AppError(404, 'TASK_NOT_FOUND', 'المهمة غير موجودة');
    }
    const ids: string[] = [];
    for (const person of unique) {
      ids.push(await sendMessage(tx, push, after, { fromAi: true, aiActor: keyActor(key), toUserId: person.id, body: body.body,
        ...(body.task_id ? { taskId: body.task_id } : {}) }));
    }
    return { status: 201, body: { ids, recipients: unique.map((p) => ({ id: p.id, full_name: p.full_name })) } };
  });

  /** POST /api/v1/ai/messages/read — { ids }: the principal heard these messages. */
  change('/api/v1/ai/messages/read', 'ai.office.write', async (tx, _after, _key, request) => {
    const { ids } = parseBody(IdsBody, request.body);
    await markRead(tx, ids);
    return { status: 204, body: null };
  });

  /** POST /api/v1/ai/announcements/:id/spoken — said to the principal (a message said aloud counts as read). */
  change<{ id: string }>('/api/v1/ai/announcements/:id/spoken', 'ai.office.write', async (tx, _after, _key, request) => {
    if (!Uuid.safeParse(request.params.id).success) throw new AppError(404, 'ANNOUNCEMENT_NOT_FOUND', 'التبليغ غير موجود');
    await markSpoken(tx, [request.params.id]);
    return { status: 204, body: null };
  });

  /** POST /api/v1/ai/briefing/seen — she heard the briefing: the next one starts from now. */
  change('/api/v1/ai/briefing/seen', 'ai.office.write', async (tx) => {
    await markBriefingSeen(tx);
    return { status: 204, body: null };
  });
}

function taskId(id: string): string {
  if (!Uuid.safeParse(id).success) throw new AppError(404, 'TASK_NOT_FOUND', 'المهمة غير موجودة');
  return id;
}
