import { pino, type Logger } from 'pino';

export interface LoggerOptions {
  level: string;
  pretty?: boolean;
}

export function createLogger({ level, pretty = false }: LoggerOptions): Logger {
  return pino({
    level,
    // Never write tokens or service keys to the logs.
    redact: {
      paths: ['req.headers["x-api-key"]', 'req.headers.authorization', 'headers["x-api-key"]', 'headers.authorization'],
      censor: '[redacted]',
    },
    ...(pretty
      ? {
          transport: {
            target: 'pino-pretty',
            options: { translateTime: 'SYS:HH:MM:ss.l', ignore: 'pid,hostname', singleLine: true },
          },
        }
      : {}),
  });
}
