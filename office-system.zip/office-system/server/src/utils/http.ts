import { readFileSync } from 'node:fs';
import type { ZodType } from 'zod';

/** Validates a request body with zod; ZodError is turned into a 400 by the error handler. */
export function parseBody<T>(schema: ZodType<T>, body: unknown): T {
  return schema.parse(body ?? {});
}

let cachedVersion: string | undefined;
export function appVersion(): string {
  if (cachedVersion === undefined) {
    try {
      // Same relative path from src/utils and dist/utils.
      const pkg = JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf8')) as { version?: string };
      cachedVersion = pkg.version ?? '0.0.0';
    } catch {
      cachedVersion = '0.0.0';
    }
  }
  return cachedVersion;
}
