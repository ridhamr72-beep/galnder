import { ZodError } from 'zod';

/** An error that maps directly to an HTTP response `{ error: { code, message } }`. */
export class AppError extends Error {
  readonly statusCode: number;
  readonly code: string;
  readonly headers: Record<string, string>;
  readonly details: unknown;

  constructor(
    statusCode: number,
    code: string,
    message: string,
    extra: { headers?: Record<string, string>; details?: unknown; cause?: unknown } = {},
  ) {
    super(message, extra.cause === undefined ? undefined : { cause: extra.cause });
    this.name = 'AppError';
    this.statusCode = statusCode;
    this.code = code;
    this.headers = extra.headers ?? {};
    this.details = extra.details;
  }
}

export interface ErrorBody {
  error: { code: string; message: string; requestId?: string; details?: unknown };
}

export function errorBody(err: AppError, requestId?: string): ErrorBody {
  return {
    error: {
      code: err.code,
      message: err.message,
      ...(requestId ? { requestId } : {}),
      ...(err.details !== undefined ? { details: err.details } : {}),
    },
  };
}

const FASTIFY_CODES: Record<string, [number, string]> = {
  FST_ERR_CTP_INVALID_JSON_BODY: [400, 'INVALID_JSON'],
  FST_ERR_CTP_EMPTY_JSON_BODY: [400, 'INVALID_JSON'],
  FST_ERR_CTP_BODY_TOO_LARGE: [413, 'PAYLOAD_TOO_LARGE'],
  FST_REQ_FILE_TOO_LARGE: [413, 'PAYLOAD_TOO_LARGE'], // a multipart upload over its file size limit
  FST_FILES_LIMIT: [413, 'PAYLOAD_TOO_LARGE'],
  FST_PARTS_LIMIT: [413, 'PAYLOAD_TOO_LARGE'],
  FST_FIELDS_LIMIT: [413, 'PAYLOAD_TOO_LARGE'],
  FST_ERR_CTP_INVALID_MEDIA_TYPE: [415, 'UNSUPPORTED_MEDIA_TYPE'],
  FST_ERR_CTP_INVALID_CONTENT_LENGTH: [400, 'BAD_REQUEST'],
};

/** Maps any thrown value to an AppError with a stable error code. */
export function toAppError(err: unknown): AppError {
  if (err instanceof AppError) return err;

  if (err instanceof ZodError) {
    const details = err.issues.map((i) => ({ path: i.path.join('.') || '(body)', message: i.message }));
    const first = details[0];
    return new AppError(400, 'VALIDATION_ERROR', first ? `${first.path}: ${first.message}` : 'Invalid request', {
      details,
    });
  }
  const fastifyErr = err as { code?: unknown; statusCode?: unknown; message?: unknown };
  const known = typeof fastifyErr.code === 'string' ? FASTIFY_CODES[fastifyErr.code] : undefined;
  if (known) return new AppError(known[0], known[1], String(fastifyErr.message));
  if (typeof fastifyErr.statusCode === 'number' && fastifyErr.statusCode >= 400 && fastifyErr.statusCode < 500) {
    return new AppError(fastifyErr.statusCode, 'BAD_REQUEST', String(fastifyErr.message));
  }
  return new AppError(500, 'INTERNAL_ERROR', 'Internal server error', { cause: err });
}
