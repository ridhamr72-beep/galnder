import type { Config } from '../config.js';
import type { Db } from '../db/index.js';
import type { Office } from '../office/index.js';

declare module 'fastify' {
  interface FastifyInstance {
    config: Config;
    /** The office's PostgreSQL. */
    db: Db;
    office: Office;
  }
}
