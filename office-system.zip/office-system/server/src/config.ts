import { resolve } from 'node:path';
import { z } from 'zod';

const TRUE_VALUES = new Set(['true', '1', 'yes', 'on']);
const FALSE_VALUES = new Set(['false', '0', 'no', 'off']);

const int = (min: number) => z.coerce.number().int().min(min);

const bool = (fallback: boolean) =>
  z
    .string()
    .trim()
    .toLowerCase()
    .optional()
    .transform((value, ctx) => {
      if (value === undefined) return fallback;
      if (TRUE_VALUES.has(value)) return true;
      if (FALSE_VALUES.has(value)) return false;
      ctx.addIssue({ code: 'custom', message: `Expected a boolean (true/false), got "${value}"` });
      return z.NEVER;
    });

const url = (fallback: string) =>
  z
    .url({ protocol: /^https?$/ })
    .default(fallback)
    .transform((value) => value.replace(/\/+$/, ''));

const EnvSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  // 0.0.0.0 = reachable from the office's phones and computers. 127.0.0.1 = this machine only.
  HOST: z.string().min(1).default('0.0.0.0'),
  PORT: int(1).max(65535).default(8000),
  // The office's PostgreSQL. Unset (or "embedded"): the server runs its own (EMBEDDED_PG_DIR, EMBEDDED_PG_PORT),
  // for a development machine.
  DATABASE_URL: z.union([
    z.literal('embedded'),
    z.string().trim().regex(/^postgres(ql)?:\/\//, 'must be postgres://... or embedded'),
  ]).optional(),
  EMBEDDED_PG_DIR: z.string().trim().default('data/postgres'),
  EMBEDDED_PG_PORT: int(1).max(65535).default(5433),
  // First start with no people yet: the demo office (seed/). For trying the system only.
  OFFICE_DEMO: bool(false),
  // The AI system's face model, used for face sign-in: POST <FACE_URL>/embed (see docs/06-face-login.md).
  FACE_URL: url('http://127.0.0.1:8006'),
  CORS_ORIGINS: z.string().trim().default('*'),
  BODY_LIMIT_MB: z.coerce.number().positive().default(20),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  LOG_PRETTY: z.string().optional(),
  SHUTDOWN_TIMEOUT_MS: int(0).default(30_000),
});

export interface Config {
  env: 'development' | 'production' | 'test';
  host: string;
  port: number;
  /** The office's PostgreSQL; never logged. */
  databaseUrl?: string;
  /** No DATABASE_URL: the server's own PostgreSQL. */
  embeddedDb?: { dir: string; port: number };
  /** Fill an empty office with the demo people and a day of work (src/office/demo.ts). */
  officeDemo: boolean;
  /** The AI system's face model, for face sign-in. */
  faceUrl: string;
  corsOrigins: '*' | string[];
  bodyLimitBytes: number;
  logLevel: string;
  logPretty: boolean;
  shutdownTimeoutMs: number;
}

export class ConfigError extends Error {
  override name = 'ConfigError';
}

/** Validates environment variables and returns a typed, frozen config. Throws ConfigError on bad input. */
export function loadConfig(env: Record<string, string | undefined> = process.env): Config {
  // Treat empty values ("PORT=") as unset so defaults apply.
  const cleaned = Object.fromEntries(Object.entries(env).filter(([, value]) => value !== undefined && value.trim() !== ''));
  const parsed = EnvSchema.safeParse(cleaned);
  if (!parsed.success) throw new ConfigError(`Invalid configuration:\n${z.prettifyError(parsed.error)}`);
  const e = parsed.data;
  const origins = e.CORS_ORIGINS.split(',').map((origin) => origin.trim()).filter(Boolean);
  const external = e.DATABASE_URL && e.DATABASE_URL !== 'embedded' ? e.DATABASE_URL : undefined;

  return Object.freeze({
    env: e.NODE_ENV,
    host: e.HOST,
    port: e.PORT,
    ...(external ? { databaseUrl: external } : { embeddedDb: { dir: resolve(e.EMBEDDED_PG_DIR), port: e.EMBEDDED_PG_PORT } }),
    officeDemo: e.OFFICE_DEMO,
    faceUrl: e.FACE_URL,
    corsOrigins: origins.length === 0 || origins.includes('*') ? '*' : origins,
    bodyLimitBytes: Math.round(e.BODY_LIMIT_MB * 1024 * 1024),
    logLevel: e.LOG_LEVEL,
    logPretty: e.LOG_PRETTY === undefined ? Boolean(process.stdout.isTTY) : TRUE_VALUES.has(e.LOG_PRETTY.toLowerCase()),
    shutdownTimeoutMs: e.SHUTDOWN_TIMEOUT_MS,
  });
}
