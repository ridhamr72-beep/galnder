/**
 * npm run db -- migrate                               applies the database migrations
 * npm run db -- create-admin <username> "<full name>" first office admin; the password comes from OFFICE_ADMIN_PASSWORD
 * npm run db -- restore "<backup folder>"            puts a backup's database back (only into an empty database)
 * npm run db -- seed-users [file]                     adds the office's people (default seed/users.json);
 *                                                     their first password comes from OFFICE_SEED_PASSWORD
 *
 * npm run db -- api-key "<name>" [scope ...]          a service key for the AI system (default scopes: all three)
 *
 * Reads DATABASE_URL from .env like the server (no DATABASE_URL: the server's own embedded database).
 */
import 'dotenv/config';
import { createServiceKey, SCOPES } from '../ai/keys.js';
import { loadConfig } from '../config.js';
import { createAdmin } from '../office/admin.js';
import pino from 'pino';
import { startEmbeddedDb } from './embedded.js';
import { migrate, PgDb } from './index.js';
import { restoreDatabase } from './restore.js';
import { seedUsers } from './seed.js';

async function main(): Promise<void> {
  const command = process.argv[2];
  const config = loadConfig();
  // The server's own database: reached if the server runs, else started for this command and stopped after.
  const embedded = !config.databaseUrl && config.embeddedDb
    ? await startEmbeddedDb({ ...config.embeddedDb, log: pino({ level: 'info' }) })
    : undefined;
  const url = config.databaseUrl ?? embedded?.url;
  if (!url) throw new Error('no database: set DATABASE_URL in .env');
  const db = new PgDb(url);
  try {
    const applied = await migrate(db);
    console.log(applied.length ? `migrated: ${applied.join(', ')}` : 'database is up to date');
    if (command === 'create-admin') {
      const [username, fullName] = process.argv.slice(3);
      const password = process.env.OFFICE_ADMIN_PASSWORD ?? '';
      if (!username || !fullName || password.length < 8) {
        throw new Error('usage: OFFICE_ADMIN_PASSWORD=<8+ chars> npm run db -- create-admin <username> "<full name>"');
      }
      await createAdmin(db, username, fullName, password);
      console.log(`admin ${username} created`);
    } else if (command === 'seed-users') {
      const { added, skipped } = await seedUsers(db, process.argv[3] ?? 'seed/users.json', process.env.OFFICE_SEED_PASSWORD ?? '');
      console.log(`added: ${added.join(', ') || 'none'}${skipped.length ? `; already there: ${skipped.join(', ')}` : ''}`);
    } else if (command === 'restore') {
      const folder = process.argv[3];
      if (!folder) throw new Error('usage: npm run db -- restore "<backup folder>"');
      const counts = await restoreDatabase(db, folder);
      console.log(`restored: ${Object.entries(counts).filter(([, n]) => n).map(([t, n]) => `${t} ${n}`).join(', ')}`);
    } else if (command === 'api-key') {
      const [name, ...scopes] = process.argv.slice(3);
      if (!name) throw new Error(`usage: npm run db -- api-key "<name>" [${SCOPES.join(' ')}]`);
      const made = await createServiceKey(db, null, name, scopes.length ? scopes : [...SCOPES]);
      console.log(`key "${made.name}" (${made.scopes.join(', ')}): ${made.api_key}`);
      console.log('it is shown this once only: put it in the AI system now');
    } else if (command !== 'migrate') {
      throw new Error('usage: npm run db -- migrate | create-admin | seed-users | restore | api-key');
    }
  } finally {
    await db.close();
    await embedded?.stop();
  }
}

main().catch((err: unknown) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
