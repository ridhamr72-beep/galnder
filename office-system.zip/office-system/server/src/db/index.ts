import pg from 'pg';
import { MIGRATIONS } from './migrations.js';

// Counts and durations are bigint in SQL; as strings in JSON the app would have to guess. Every one here fits a double.
pg.types.setTypeParser(pg.types.builtins.INT8, (value) => Number(value));

/**
 * The office's database (PostgreSQL): the server is the only program that writes to it.
 * A small surface on purpose, so tests can run the same code on an in-memory Postgres.
 */
export interface Db {
  query<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T[]>;
  /** Several statements at once, no parameters (migrations). */
  exec(sql: string): Promise<void>;
  /** Runs `fn` in one transaction: all of it is kept, or none. */
  tx<T>(fn: (db: Db) => Promise<T>): Promise<T>;
  close(): Promise<void>;
}

type Queryable = pg.Pool | pg.PoolClient;

class PgClientDb implements Db {
  constructor(private readonly client: Queryable) {}

  async query<T>(sql: string, params: unknown[] = []): Promise<T[]> {
    return (await this.client.query(sql, params)).rows as T[];
  }

  async exec(sql: string): Promise<void> {
    await this.client.query(sql);
  }

  tx<T>(fn: (db: Db) => Promise<T>): Promise<T> {
    return fn(this); // already inside the caller's transaction
  }

  async close(): Promise<void> {}
}

export class PgDb implements Db {
  private readonly pool: pg.Pool;

  constructor(connectionString: string) {
    this.pool = new pg.Pool({ connectionString, max: 10 });
  }

  async query<T>(sql: string, params: unknown[] = []): Promise<T[]> {
    return (await this.pool.query(sql, params)).rows as T[];
  }

  async exec(sql: string): Promise<void> {
    await this.pool.query(sql);
  }

  async tx<T>(fn: (db: Db) => Promise<T>): Promise<T> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const result = await fn(new PgClientDb(client));
      await client.query('COMMIT');
      return result;
    } catch (err) {
      await client.query('ROLLBACK').catch(() => undefined);
      throw err;
    } finally {
      client.release();
    }
  }

  async close(): Promise<void> {
    await this.pool.end();
  }
}

/** Applies every migration not applied yet, each in its own transaction. Safe to run on every start. */
export async function migrate(db: Db): Promise<string[]> {
  await db.exec('CREATE TABLE IF NOT EXISTS schema_migrations (id text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())');
  const done = new Set((await db.query<{ id: string }>('SELECT id FROM schema_migrations')).map((r) => r.id));
  const applied: string[] = [];
  for (const migration of MIGRATIONS) {
    if (done.has(migration.id)) continue;
    await db.tx(async (tx) => {
      await tx.exec(migration.sql);
      await tx.query('INSERT INTO schema_migrations (id) VALUES ($1)', [migration.id]);
    });
    applied.push(migration.id);
  }
  return applied;
}

/** bytea comes back as a Buffer from node-postgres and as a Uint8Array from other drivers. */
export function toBuffer(value: unknown): Buffer {
  if (Buffer.isBuffer(value)) return value;
  if (value instanceof Uint8Array) return Buffer.from(value.buffer, value.byteOffset, value.byteLength);
  throw new TypeError('expected binary data');
}
