import { readFile } from 'node:fs/promises';
import { hashPassword } from '../office/auth.js';
import type { Db } from './index.js';

interface SeedUser {
  username: string;
  full_name: string;
  job_title?: string | null;
  role: string;
  aliases?: string[];
  is_principal?: boolean;
}

/**
 * Adds the office's people from a file like office/seed/users.json. The file holds no passwords: everyone starts
 * with `password` and changes it (the admin can set a new one from the app). A username already there is left as it is.
 */
export async function seedUsers(db: Db, file: string, password: string): Promise<{ added: string[]; skipped: string[] }> {
  if (password.length < 8) throw new Error('OFFICE_SEED_PASSWORD must be 8 characters or more');
  const { users } = JSON.parse(await readFile(file, 'utf8')) as { users: SeedUser[] };
  const hash = await hashPassword(password);
  const added: string[] = [];
  const skipped: string[] = [];
  await db.tx(async (tx) => {
    for (const u of users) {
      const [role] = await tx.query<{ id: string }>('SELECT id FROM roles WHERE code = $1', [u.role]);
      if (!role) throw new Error(`${u.username}: no role "${u.role}"`);
      const [row] = await tx.query<{ id: string }>(
        `INSERT INTO users (username, full_name, job_title, aliases, role_id, password_hash, is_principal)
         VALUES ($1, $2, $3, $4, $5, $6, $7) ON CONFLICT (username) DO NOTHING RETURNING id`,
        [u.username, u.full_name, u.job_title ?? null, u.aliases ?? [], role.id, hash, u.is_principal ?? false]);
      (row ? added : skipped).push(u.username);
    }
  });
  return { added, skipped };
}
