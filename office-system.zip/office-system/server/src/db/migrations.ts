import { OFFICE_SCHEMA } from '../office/schema.js';

/**
 * Database changes, in order. Never edit one that has shipped: add the next one.
 * Kept as strings in code (not .sql files) so the build output carries them.
 *
 * The ids are the ones these changes had when the office lived inside the AI gateway, so a database that already has
 * them is not changed twice. 001 (knowledge base) and 006 (phrase bank) belong to the AI system and are not here.
 */
export const MIGRATIONS: ReadonlyArray<{ id: string; sql: string }> = [
  { id: '002_office', sql: OFFICE_SCHEMA },
  {
    id: '003_office_messages',
    // Both ways: the principal (through the AI) to staff, and staff to the principal or to each other, alone or about a task.
    sql: `
      ALTER TYPE notification_kind ADD VALUE 'message';
      CREATE TABLE messages (
        id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        task_id      uuid REFERENCES tasks(id) ON DELETE CASCADE,
        sender_id    uuid REFERENCES users(id),
        from_ai      boolean NOT NULL DEFAULT false,
        recipient_id uuid REFERENCES users(id),
        body         text NOT NULL CHECK (length(btrim(body)) > 0),
        created_at   timestamptz NOT NULL DEFAULT now(),
        read_at      timestamptz,
        CHECK ((sender_id IS NOT NULL) <> from_ai),
        CHECK (recipient_id IS NOT NULL OR NOT from_ai)
      );
      COMMENT ON COLUMN messages.recipient_id IS 'NULL = to the principal (read out by the AI)';
      CREATE INDEX messages_recipient ON messages (recipient_id, created_at DESC);
      CREATE INDEX messages_task ON messages (task_id, created_at);
      ALTER TABLE notifications ADD COLUMN message_id uuid REFERENCES messages(id) ON DELETE CASCADE;
    `,
  },
  {
    id: '004_office_announcements',
    // What the AI tells the principal by itself; subject_key makes each happening said once.
    sql: `
      CREATE TABLE announcements (
        id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        kind        text NOT NULL,
        subject_key text NOT NULL UNIQUE,
        text        text NOT NULL,
        urgent      boolean NOT NULL DEFAULT false,
        message_id  uuid REFERENCES messages(id) ON DELETE CASCADE,
        created_at  timestamptz NOT NULL DEFAULT now(),
        spoken_at   timestamptz
      );
      CREATE INDEX announcements_unspoken ON announcements (created_at) WHERE spoken_at IS NULL;
      INSERT INTO settings (key, value) VALUES
        ('announce.unopened_minutes', '15'), ('announce.appointment_minutes', '15')
      ON CONFLICT (key) DO NOTHING;
    `,
  },
  {
    id: '005_office_letters',
    // Official letters in and out. The principal's margin (الهامش) on an incoming letter becomes a task with the letter's images.
    sql: `
      CREATE TYPE letter_direction AS ENUM ('incoming', 'outgoing');
      CREATE TABLE letters (
        id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        direction     letter_direction NOT NULL DEFAULT 'incoming',
        ref_number    text,
        letter_date   date,
        party         text,
        subject       text NOT NULL CHECK (length(btrim(subject)) > 0),
        summary       text,
        registered_by uuid NOT NULL REFERENCES users(id),
        created_at    timestamptz NOT NULL DEFAULT now(),
        margin        text,
        margined_at   timestamptz,
        task_id       uuid REFERENCES tasks(id) ON DELETE SET NULL
      );
      COMMENT ON COLUMN letters.party IS 'incoming: who sent it; outgoing: who it goes to';
      CREATE INDEX letters_recent ON letters (created_at DESC);
      ALTER TABLE attachments ALTER COLUMN task_id DROP NOT NULL;
      ALTER TABLE attachments ADD COLUMN letter_id uuid REFERENCES letters(id) ON DELETE CASCADE;
      ALTER TABLE attachments DROP CONSTRAINT attachments_purpose_check;
      ALTER TABLE attachments ADD CONSTRAINT attachments_purpose_check CHECK (purpose IN ('task', 'result', 'letter'));
      ALTER TABLE attachments ADD CONSTRAINT attachments_one_owner CHECK ((task_id IS NULL) <> (letter_id IS NULL));
      CREATE INDEX attachments_letter ON attachments (letter_id) WHERE letter_id IS NOT NULL;
      INSERT INTO permissions (code, description) VALUES
        ('letters.write', 'يسجّل الكتب الواردة والصادرة'), ('letters.read', 'يرى سجل الكتب')
      ON CONFLICT (code) DO NOTHING;
      INSERT INTO role_permissions (role_id, permission_code)
      SELECT r.id, p.code FROM roles r JOIN (VALUES
        ('office_manager', 'letters.write'), ('office_manager', 'letters.read'), ('follow_up', 'letters.read')
      ) AS p(role_code, code) ON p.role_code = r.code
      ON CONFLICT DO NOTHING;
    `,
  },
  {
    id: '007_office_meeting_decisions',
    // What was decided in a meeting, kept apart from its tasks: the AI answers «شنو قررنا عن ...؟» from it.
    sql: `ALTER TABLE meetings ADD COLUMN decisions jsonb NOT NULL DEFAULT '[]';`,
  },
  {
    id: '008_office_manager_oversight',
    // The office manager runs the office: sees every task and who keeps to time, like the follow-up officer.
    sql: `
      INSERT INTO role_permissions (role_id, permission_code)
      SELECT r.id, p.code FROM roles r JOIN (VALUES ('office_manager', 'tasks.read_all'), ('office_manager', 'performance.read'))
        AS p(role_code, code) ON p.role_code = r.code
      ON CONFLICT DO NOTHING;
    `,
  },
  {
    id: '009_office_more_alerts',
    // The assignee hears when their task is accepted, given a new time, cancelled or moved away; the appointment
    // keepers hear of an appointment the principal booked by talking.
    sql: `
      ALTER TYPE notification_kind ADD VALUE IF NOT EXISTS 'task_closed';
      ALTER TYPE notification_kind ADD VALUE IF NOT EXISTS 'task_extended';
      ALTER TYPE notification_kind ADD VALUE IF NOT EXISTS 'task_cancelled';
      ALTER TYPE notification_kind ADD VALUE IF NOT EXISTS 'appointment';
    `,
  },
  {
    id: '010_office_face_prints',
    // Face sign-in: up to five prints per person (128 numbers each, made by the AI system's face model), never the photo itself.
    sql: `
      CREATE TABLE face_prints (
        id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        embedding  real[] NOT NULL CHECK (cardinality(embedding) = 128),
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX face_prints_user ON face_prints (user_id);
    `,
  },
  {
    id: '011_office_service_keys',
    // Keys for programs that use the office through /api/v1/ai/* (the AI system). Only the hash is kept; the key is shown
    // once when it is made. Each key has scopes; every event it causes names it, so the record says which program acted.
    sql: `
      CREATE TABLE api_keys (
        id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        name         text NOT NULL CHECK (length(btrim(name)) > 0),
        key_prefix   text NOT NULL UNIQUE,
        key_hash     text NOT NULL,
        scopes       text[] NOT NULL CHECK (cardinality(scopes) > 0),
        created_by   uuid REFERENCES users(id),
        created_at   timestamptz NOT NULL DEFAULT now(),
        last_used_at timestamptz,
        revoked_at   timestamptz
      );
      -- A retried order (the same Idempotency-Key) gets the first answer again instead of acting twice.
      CREATE TABLE idempotency_keys (
        api_key_id uuid NOT NULL REFERENCES api_keys(id) ON DELETE CASCADE,
        key        text NOT NULL,
        status     integer NOT NULL,
        response   jsonb NOT NULL,
        created_at timestamptz NOT NULL DEFAULT now(),
        PRIMARY KEY (api_key_id, key)
      );
      ALTER TABLE events ADD COLUMN actor_key_id uuid REFERENCES api_keys(id);
      INSERT INTO permissions (code, description) VALUES ('api_keys.manage', 'يدير مفاتيح الخدمات (نظام الذكاء)')
      ON CONFLICT (code) DO NOTHING;
      INSERT INTO role_permissions (role_id, permission_code)
      SELECT id, 'api_keys.manage' FROM roles WHERE code = 'admin'
      ON CONFLICT DO NOTHING;
    `,
  },
];
