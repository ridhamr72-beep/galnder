import { randomBytes } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { chmod, mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import type { FastifyBaseLogger } from 'fastify';
import pg from 'pg';

/**
 * A PostgreSQL of the server's own, for a development machine: the binaries come with `npm install`
 * (embedded-postgres), the data lives in EMBEDDED_PG_DIR, and it listens on 127.0.0.1 only. It starts with the server
 * and stops with it. In the office itself, DATABASE_URL points at the office's PostgreSQL instead.
 * The password is made once and kept next to the data folder.
 */

const USER = 'office';
const DATABASE = 'office';

export interface EmbeddedDb {
  url: string;
  stop(): Promise<void>;
}

async function password(dir: string): Promise<string> {
  const file = `${dir}.secret`;
  if (existsSync(file)) return (await readFile(file, 'utf8')).trim();
  const made = randomBytes(24).toString('base64url');
  await mkdir(dirname(file), { recursive: true });
  await writeFile(file, made, { mode: 0o600 });
  await chmod(file, 0o600).catch(() => undefined);
  return made;
}

/**
 * A server killed hard (Task Manager, a closed console) takes the main PostgreSQL process with it, but on Windows one
 * of its child processes can live on and keep the port open without answering, so nothing starts. When the main
 * process named in postmaster.pid is gone, its leftover children are stopped.
 */
function clearLeftovers(dir: string, log: FastifyBaseLogger): void {
  const pidFile = join(dir, 'postmaster.pid');
  if (!existsSync(pidFile)) return;
  const pid = Number(readFileSync(pidFile, 'utf8').split(/\r?\n/)[0]);
  if (!Number.isInteger(pid) || pid <= 0) return;
  try {
    process.kill(pid, 0);
    return; // still running: not ours to stop
  } catch {
    // gone: its children may remain
  }
  if (process.platform !== 'win32') return;
  const r = spawnSync('powershell', ['-NoProfile', '-Command',
    `Get-CimInstance Win32_Process -Filter "Name='postgres.exe' AND ParentProcessId=${pid}" | ForEach-Object { Stop-Process -Id $_.ProcessId -Force; $_.ProcessId }`],
  { encoding: 'utf8', timeout: 15_000 });
  const stopped = (r.stdout ?? '').split(/\s+/).filter(Boolean);
  if (stopped.length) log.warn({ stopped, parent: pid }, 'stopped database processes left by a server that was killed');
}

const urlFor = (secret: string, port: number) => `postgres://${USER}:${encodeURIComponent(secret)}@127.0.0.1:${port}/${DATABASE}`;

/** True when our database already answers: left running by a server that crashed, or by `npm run db` alongside. */
async function answers(url: string): Promise<boolean> {
  // A few seconds at most: one left by a server that was killed can hold the port without ever answering.
  const client = new pg.Client({ connectionString: url, connectionTimeoutMillis: 3000, query_timeout: 3000 });
  try {
    await client.connect();
    await client.query('SELECT 1');
    return true;
  } catch {
    return false;
  } finally {
    await client.end().catch(() => undefined);
  }
}

export async function startEmbeddedDb(options: { dir: string; port: number; log: FastifyBaseLogger }): Promise<EmbeddedDb> {
  const { dir, port, log } = options;
  const secret = await password(dir);
  if (existsSync(join(dir, 'PG_VERSION')) && (await answers(urlFor(secret, port)))) {
    log.info({ port }, 'database already running: using it');
    return { url: urlFor(secret, port), stop: async () => undefined };
  }
  clearLeftovers(dir, log);
  const { default: EmbeddedPostgres } = await import('embedded-postgres');
  const pg = new EmbeddedPostgres({
    databaseDir: dir, port, user: USER, password: secret, persistent: true, authMethod: 'scram-sha-256',
    // UTF-8 whatever the Windows language: initdb otherwise takes WIN1252 from the system and refuses Arabic.
    initdbFlags: ['--encoding=UTF8', '--locale=C'],
    // Only this machine: the apps reach the server, never the database.
    postgresFlags: ['-c', 'listen_addresses=127.0.0.1'],
    onLog: (message) => log.debug({ pg: String(message).trim() }, 'postgres'),
    onError: (err) => log.warn({ pg: err instanceof Error ? err.message : String(err).trim() }, 'postgres'),
  });

  const fresh = !existsSync(join(dir, 'PG_VERSION'));
  if (fresh) {
    log.info({ dir }, 'first start: making the database (one time, a few seconds)');
    await pg.initialise();
  }
  await pg.start();
  if (fresh) await pg.createDatabase(DATABASE);
  log.info({ port, dir }, 'database ready (embedded PostgreSQL)');
  return { url: urlFor(secret, port), stop: () => pg.stop() };
}

