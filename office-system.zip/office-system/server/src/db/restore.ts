import { createReadStream, existsSync } from 'node:fs';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createInterface } from 'node:readline';
import type { Db } from './index.js';
import { migrate } from './index.js';

/**
 * Puts a backup's database (scripts/lib/db-dump.mjs: one JSON line per row, tables in reference order) into this
 * database. Only into one with no users yet, so a restore never mixes with live data; the
 * tables the migrations fill (roles, permissions, settings) are replaced by the backup's.
 */
export async function restoreDatabase(db: Db, folder: string): Promise<Record<string, number>> {
  const dir = existsSync(join(folder, 'database', 'tables.json')) ? join(folder, 'database') : folder;
  const index = JSON.parse(await readFile(join(dir, 'tables.json'), 'utf8')) as { order: string[] };
  await migrate(db);
  const [{ users }] = (await db.query<{ users: number }>('SELECT count(*)::int AS users FROM users')) as [{ users: number }];
  if (users > 0) throw new Error(`this database already has ${users} users: restore only into an empty one`);

  // Tables this version has (a backup made with the AI system's tables in it brings only the office's); the migrations
  // record itself stays as this version made it.
  const here = new Set((await db.query<{ name: string }>(
    `SELECT tablename AS name FROM pg_tables WHERE schemaname = 'public'`)).map((t) => t.name));
  const tables = index.order.filter((t) => here.has(t) && t !== 'schema_migrations');
  const counts: Record<string, number> = {};
  await db.tx(async (tx) => {
    await tx.query(`TRUNCATE ${tables.map((t) => `"${t}"`).join(', ')} CASCADE`);
    for (const table of tables) {
      const file = join(dir, `${table}.jsonl`);
      if (!existsSync(file)) continue;
      let n = 0;
      for await (const line of createInterface({ input: createReadStream(file, { encoding: 'utf8' }), crlfDelay: Infinity })) {
        if (!line.trim()) continue;
        // json_populate_record turns each field back into its column's type (bytea from its \x text included).
        await tx.query(`INSERT INTO "${table}" OVERRIDING SYSTEM VALUE SELECT * FROM json_populate_record(NULL::"${table}", $1::json)`, [line]);
        n++;
      }
      counts[table] = n;
    }
    // Identity columns continue after the restored rows.
    const identities = await tx.query<{ table_name: string; column_name: string }>(
      `SELECT table_name, column_name FROM information_schema.columns WHERE table_schema = 'public' AND is_identity = 'YES'`);
    for (const c of identities) {
      await tx.query(`SELECT setval(pg_get_serial_sequence('"${c.table_name}"', '${c.column_name}'),
                      GREATEST((SELECT COALESCE(max("${c.column_name}"), 0) FROM "${c.table_name}"), 1))`);
    }
  });
  return counts;
}
