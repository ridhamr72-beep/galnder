import { randomUUID } from 'node:crypto';
import cors from '@fastify/cors';
import multipart from '@fastify/multipart';
import Fastify, { type FastifyBaseLogger, type FastifyInstance } from 'fastify';
import type { Logger } from 'pino';
import { aiRoutes } from './ai/door.js';
import { keyRoutes } from './ai/keys.js';
import type { Config } from './config.js';
import { migrate, PgDb, type Db } from './db/index.js';
import type { FaceClient } from './office/face.js';
import { registerOffice } from './office/index.js';
import { AppError, errorBody, toAppError } from './utils/errors.js';
import { appVersion } from './utils/http.js';
import { createLogger } from './utils/logger.js';

export interface BuildServerOptions {
  config: Config;
  logger?: Logger;
  /** Inject the database (tests); otherwise one is opened from config.databaseUrl. */
  db?: Db;
  /** Tests turn the background timer off and run its steps by hand. */
  worker?: boolean;
  /** Inject the face model client (tests). */
  face?: FaceClient;
}

const REQUEST_ID_PATTERN = /^[\w.:-]{1,128}$/;
const startedAt = Date.now();

/** Builds the office server with all its routes; does not start listening. */
export async function buildServer({ config, logger, db: givenDb, worker, face }: BuildServerOptions): Promise<FastifyInstance> {
  const loggerInstance: FastifyBaseLogger = logger ?? createLogger({ level: config.logLevel, pretty: config.logPretty });
  const app = Fastify({
    loggerInstance,
    // Reuse a caller-supplied x-request-id when it looks safe, otherwise generate one.
    requestIdHeader: false,
    genReqId: (req) => {
      const incoming = req.headers['x-request-id'];
      return typeof incoming === 'string' && REQUEST_ID_PATTERN.test(incoming) ? incoming : randomUUID();
    },
    bodyLimit: config.bodyLimitBytes,
    return503OnClosing: true,
    forceCloseConnections: 'idle',
  });

  if (!givenDb && !config.databaseUrl) throw new Error('no database: set DATABASE_URL, or start the embedded one first');
  const db = givenDb ?? new PgDb(config.databaseUrl!);
  const applied = await migrate(db);
  if (applied.length) app.log.info({ applied }, 'database migrated');
  // A database the caller passed in is the caller's to close.
  if (!givenDb) app.addHook('onClose', async () => db.close());

  app.decorate('config', config);
  app.decorate('db', db);

  app.addHook('onRequest', async (request, reply) => {
    reply.header('x-request-id', request.id);
  });

  await app.register(multipart, { limits: { fileSize: config.bodyLimitBytes, files: 1, fields: 10 } });
  await app.register(cors, {
    origin: config.corsOrigins === '*' ? '*' : config.corsOrigins,
    methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['content-type', 'authorization', 'x-api-key', 'x-request-id', 'idempotency-key'],
    exposedHeaders: ['x-request-id', 'idempotent-replayed'],
    maxAge: 600,
  });

  // Every error leaves the server as `{ error: { code, message, requestId } }`.
  app.setErrorHandler((err, request, reply) => {
    const appError = toAppError(err);
    if (appError.statusCode >= 500) request.log.error({ err }, appError.message);
    else request.log.info({ code: appError.code, status: appError.statusCode }, appError.message);
    if (reply.sent || reply.raw.headersSent) return;
    reply.code(appError.statusCode).headers({ ...appError.headers, 'x-request-id': request.id }).send(errorBody(appError, request.id));
  });
  app.setNotFoundHandler((request, reply) => {
    reply.code(404).send(errorBody(new AppError(404, 'NOT_FOUND', `Route ${request.method} ${request.url} not found`), request.id));
  });

  /** GET /health — public: the server and its database. */
  app.get('/health', async (_request, reply) => {
    const database = await db.query('SELECT 1').then(() => 'up', () => 'down');
    return reply.code(database === 'up' ? 200 : 503).send({
      status: database === 'up' ? 'ok' : 'degraded',
      version: appVersion(),
      uptimeSec: Math.round((Date.now() - startedAt) / 1000),
      database,
    });
  });

  const office = await registerOffice(app, db, { worker: worker !== false, ...(face ? { face } : {}) });
  app.decorate('office', office);
  keyRoutes(app, office.context);
  aiRoutes(app, office.context);
  return app;
}
