import type { FastifyInstance, FastifyRequest } from 'fastify';
import { z } from 'zod';
import type { Db } from '../db/index.js';
import { AppError } from '../utils/errors.js';
import { parseBody } from '../utils/http.js';
import { imageType, MAX_BYTES } from './attachments.js';
import { requirePermission } from './auth.js';
import type { After, OfficeContext } from './context.js';
import { recordEvent, type Actor } from './events.js';
import type { PushHub } from './push.js';
import { createTask, resolveDue } from './tasks.js';

/**
 * Official letters in and out. The office manager registers an incoming letter (number, date, sender, subject, a short
 * summary) with photos of its pages. The principal's margin (الهامش) becomes a task for whoever she names, with the
 * letter's images: entered from the app (a margin written on the paper) or sent by the AI system (a spoken one).
 */

const LetterBody = z.object({
  direction: z.enum(['incoming', 'outgoing']).default('incoming'),
  ref_number: z.string().trim().max(100).nullish(),
  letter_date: z.iso.date().nullish(),
  party: z.string().trim().max(300).nullish(),
  subject: z.string().trim().min(1, 'اكتب موضوع الكتاب').max(500),
  summary: z.string().trim().max(4000).nullish(),
});

/** The principal's margin: a task for the person she named, the letter's images copied onto it, the letter marked. */
export async function marginLetter(db: Db, hub: PushHub, after: After, actor: Actor, letterId: string,
  input: { assigneeId: string; margin: string; due: Date; priority: 'normal' | 'high'; utterance?: string }) {
  const [letter] = await db.query<{ id: string; subject: string; party: string | null; ref_number: string | null; summary: string | null; task_id: string | null }>(
    'SELECT id, subject, party, ref_number, summary, task_id FROM letters WHERE id = $1 FOR UPDATE', [letterId]);
  if (!letter) throw new AppError(404, 'LETTER_NOT_FOUND', 'الكتاب غير موجود');
  if (letter.task_id) throw new AppError(409, 'LETTER_MARGINED', 'هذا الكتاب مهمّش من قبل');
  const about = [letter.party && `من ${letter.party}`, letter.ref_number && `العدد ${letter.ref_number}`].filter(Boolean).join('، ');
  const task = await createTask(db, hub, after, actor, {
    title: `هامش: ${letter.subject}`.slice(0, 300),
    description: [`الهامش: ${input.margin}`, about && `الكتاب ${about}`, letter.summary && `ملخصه: ${letter.summary}`].filter(Boolean).join('\n'),
    assigneeId: input.assigneeId, priority: input.priority, source: actor.type === 'ai' ? 'voice_ai' : 'app',
    ...(input.utterance ? { utterance: input.utterance } : {}), due: input.due,
  });
  await db.query(
    `INSERT INTO attachments (task_id, purpose, file_name, content_type, size_bytes, data, uploaded_by)
     SELECT $1, 'task', file_name, content_type, size_bytes, data, uploaded_by FROM attachments WHERE letter_id = $2 ORDER BY created_at`,
    [task.id, letterId]);
  await db.query('UPDATE letters SET margin = $2, margined_at = now(), task_id = $3 WHERE id = $1', [letterId, input.margin, task.id]);
  await recordEvent(db, actor, 'letter.margined', { type: 'letter', id: letterId }, `هُمّش الكتاب «${letter.subject}» إلى ${task.assignee_name}: ${input.margin}`);
  return { task, subject: letter.subject };
}

const LETTER_COLUMNS = `l.id, l.direction, l.ref_number, l.letter_date, l.party, l.subject, l.summary, l.created_at, l.margin, l.margined_at,
  l.task_id, u.full_name AS registered_by_name, t.status AS task_status, a.full_name AS task_assignee,
  (SELECT count(*) FROM attachments f WHERE f.letter_id = l.id) AS images`;
const LETTER_JOINS = `FROM letters l JOIN users u ON u.id = l.registered_by LEFT JOIN tasks t ON t.id = l.task_id LEFT JOIN users a ON a.id = t.assignee_id`;

export function letterRoutes(app: FastifyInstance, office: OfficeContext): void {
  const { db } = office;

  app.get<{ Querystring: { direction?: string } }>('/api/v1/letters', async (request) => {
    requirePermission(await office.user(request), 'letters.read');
    const direction = request.query.direction === 'outgoing' || request.query.direction === 'incoming' ? request.query.direction : null;
    const items = await db.query(
      `SELECT ${LETTER_COLUMNS} ${LETTER_JOINS} WHERE ($1::letter_direction IS NULL OR l.direction = $1) ORDER BY l.created_at DESC LIMIT 200`,
      [direction]);
    return { items, next_cursor: null };
  });

  app.post('/api/v1/letters', async (request, reply) => {
    const user = await office.user(request);
    requirePermission(user, 'letters.write');
    const body = parseBody(LetterBody, request.body);
    const id = await office.tx(async (tx) => {
      const [row] = await tx.query<{ id: string }>(
        `INSERT INTO letters (direction, ref_number, letter_date, party, subject, summary, registered_by) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
        [body.direction, body.ref_number || null, body.letter_date || null, body.party || null, body.subject, body.summary || null, user.id]);
      await recordEvent(tx, { type: 'user', userId: user.id }, 'letter.registered', { type: 'letter', id: row!.id },
        `${body.direction === 'incoming' ? 'كتاب وارد' : 'كتاب صادر'}: ${body.subject}${body.party ? ` (${body.party})` : ''}`);
      return row!.id;
    });
    const [letter] = await db.query(`SELECT ${LETTER_COLUMNS} ${LETTER_JOINS} WHERE l.id = $1`, [id]);
    return reply.code(201).send(letter);
  });

  /** POST /api/v1/letters/:id/images — multipart `file`, one page at a time. */
  app.post<{ Params: { id: string } }>('/api/v1/letters/:id/images', async (request, reply) => {
    const user = await office.user(request);
    requirePermission(user, 'letters.write');
    const image = await uploadedImage(request);
    const [letter] = await db.query('SELECT 1 FROM letters WHERE id = $1', [request.params.id]);
    if (!letter) throw new AppError(404, 'LETTER_NOT_FOUND', 'الكتاب غير موجود');
    const [row] = await db.query(
      `INSERT INTO attachments (letter_id, purpose, file_name, content_type, size_bytes, data, uploaded_by)
       VALUES ($1, 'letter', $2, $3, $4, $5, $6) RETURNING id, file_name, content_type, size_bytes, created_at`,
      [request.params.id, image.name, image.type, image.data.length, image.data, user.id]);
    return reply.code(201).send(row);
  });

  app.get<{ Params: { id: string } }>('/api/v1/letters/:id/images', async (request) => {
    requirePermission(await office.user(request), 'letters.read');
    const items = await db.query(
      'SELECT id, file_name, content_type, size_bytes, created_at FROM attachments WHERE letter_id = $1 ORDER BY created_at', [request.params.id]);
    return { items, next_cursor: null };
  });

  /** POST /api/v1/letters/:id/margin — a margin the principal wrote by hand on the paper, entered by the office manager. */
  app.post<{ Params: { id: string } }>('/api/v1/letters/:id/margin', async (request, reply) => {
    const user = await office.user(request);
    requirePermission(user, 'letters.write');
    const body = parseBody(z.object({
      assignee_id: z.uuid(), margin: z.string().trim().min(1, 'اكتب الهامش').max(2000),
      priority: z.enum(['normal', 'high']).default('normal'), due_in_hours: z.number().int().positive().max(24 * 365).nullish(),
    }), request.body);
    const done = await office.tx(async (tx, after) => marginLetter(tx, office.push, after, { type: 'user', userId: user.id }, request.params.id, {
      assigneeId: body.assignee_id, margin: body.margin, priority: body.priority, due: await resolveDue(tx, undefined, body.due_in_hours ?? undefined),
    }));
    return reply.code(201).send({ task_id: done.task.id, assignee_name: done.task.assignee_name });
  });
}

async function uploadedImage(request: FastifyRequest) {
  const file = await request.file();
  if (!file) throw new AppError(400, 'NO_FILE', 'أرفق صورة');
  const data = await file.toBuffer();
  if (data.length > MAX_BYTES) throw new AppError(413, 'PAYLOAD_TOO_LARGE', 'أكبر صورة 5 ميغا');
  const type = imageType(data);
  if (!type) throw new AppError(400, 'UNSUPPORTED_FILE', 'الصور فقط: jpg أو png أو webp');
  return { data, type, name: file.filename.slice(0, 200) || 'letter' };
}
