import { createHmac, timingSafeEqual } from 'node:crypto';
import type { FastifyInstance } from 'fastify';
import type { Db } from '../db/index.js';
import { AppError } from '../utils/errors.js';
import { can, type OfficeUser } from './auth.js';
import type { OfficeContext } from './context.js';

export const MAX_BYTES = 5 * 1024 * 1024;
const LINK_SECONDS = 3600;

const signature = (secret: string, id: string, exp: string) => createHmac('sha256', secret).update(`file:${id}:${exp}`).digest('base64url');

function validSignature(secret: string, id: string, exp: string, sig: string): boolean {
  const expected = Buffer.from(signature(secret, id, exp));
  const given = Buffer.from(sig);
  return given.length === expected.length && timingSafeEqual(given, expected);
}

/** A link to an attachment that works for an hour without signing in: what the AI system shows the principal. */
export function signedFileUrl(secret: string, id: string): string {
  const exp = String(Math.floor(Date.now() / 1000) + LINK_SECONDS);
  return `/api/v1/files/${id}?exp=${exp}&sig=${signature(secret, id, exp)}`;
}

/** The file's first bytes decide the type, not its name or the header the client sends. */
export function imageType(data: Buffer): string | undefined {
  if (data.subarray(0, 3).equals(Buffer.from([0xff, 0xd8, 0xff]))) return 'image/jpeg';
  if (data.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (data.subarray(0, 4).toString('latin1') === 'RIFF' && data.subarray(8, 12).toString('latin1') === 'WEBP') return 'image/webp';
  return undefined;
}

interface TaskAccess {
  assignee_id: string;
  created_by_user: string | null;
  opened_at: Date | null;
  status: string;
}

const notFound = () => new AppError(404, 'TASK_NOT_FOUND', 'المهمة غير موجودة');

/**
 * Who may see a task's images: its sender, whoever reads every task, and the assignee only once it is opened
 * (a sealed task shows nothing, images included).
 */
export async function access(db: Db, taskId: string, user: OfficeUser): Promise<TaskAccess & { asAssignee: boolean }> {
  const [task] = await db.query<TaskAccess>('SELECT assignee_id, created_by_user, opened_at, status FROM tasks WHERE id = $1', [taskId]);
  if (!task) throw notFound();
  const asAssignee = task.assignee_id === user.id;
  const allowed = task.created_by_user === user.id || can(user, 'tasks.read_all') || (asAssignee && task.opened_at !== null);
  if (!allowed) throw notFound();
  return { ...task, asAssignee };
}

export function attachmentRoutes(app: FastifyInstance, office: OfficeContext): void {
  const { db } = office;

  /** POST /api/v1/tasks/:id/attachments — multipart `file`. The sender attaches to the task, the assignee to the result. */
  app.post<{ Params: { id: string } }>('/api/v1/tasks/:id/attachments', async (request, reply) => {
    const user = await office.user(request);
    const task = await access(db, request.params.id, user);
    const purpose = task.asAssignee ? 'result' : task.created_by_user === user.id ? 'task' : undefined;
    if (!purpose) throw new AppError(403, 'FORBIDDEN', 'يرفق الصورة المرسل أو المكلَّف فقط');
    if (task.status === 'closed' || task.status === 'cancelled') throw new AppError(409, 'TASK_BAD_STATE', 'المهمة منتهية');

    const file = await request.file();
    if (!file) throw new AppError(400, 'NO_FILE', 'أرفق صورة');
    const data = await file.toBuffer();
    if (data.length > MAX_BYTES) throw new AppError(413, 'PAYLOAD_TOO_LARGE', 'أكبر صورة 5 ميغا');
    const type = imageType(data);
    if (!type) throw new AppError(400, 'UNSUPPORTED_FILE', 'الصور فقط: jpg أو png أو webp');

    const [row] = await db.query(
      `INSERT INTO attachments (task_id, purpose, file_name, content_type, size_bytes, data, uploaded_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id, purpose, file_name, content_type, size_bytes, created_at`,
      [request.params.id, purpose, file.filename.slice(0, 200) || 'image', type, data.length, data, user.id]);
    return reply.code(201).send(row);
  });

  app.get<{ Params: { id: string } }>('/api/v1/tasks/:id/attachments', async (request) => {
    await access(db, request.params.id, await office.user(request));
    const items = await db.query(
      'SELECT id, purpose, file_name, content_type, size_bytes, created_at FROM attachments WHERE task_id = $1 ORDER BY created_at',
      [request.params.id]);
    return { items, next_cursor: null };
  });

  /**
   * GET /api/v1/files/:id?exp=&sig= — an image the AI system shows the principal. Its screen has no user token and an
   * <img> cannot send a key, so the link itself is the permission: signed, and good for an hour.
   */
  app.get<{ Params: { id: string }; Querystring: { exp?: string; sig?: string } }>(
    '/api/v1/files/:id', async (request, reply) => {
      const { exp, sig } = request.query;
      if (!exp || !sig || Number(exp) * 1000 < Date.now() || !validSignature(office.secret, request.params.id, exp, sig)) {
        throw new AppError(403, 'LINK_EXPIRED', 'الرابط انتهى');
      }
      const [row] = await db.query<{ content_type: string; data: Buffer }>('SELECT content_type, data FROM attachments WHERE id = $1', [request.params.id]);
      if (!row) throw new AppError(404, 'ATTACHMENT_NOT_FOUND', 'الصورة غير موجودة');
      return reply.header('content-type', row.content_type).header('cache-control', 'private, max-age=3600').send(Buffer.from(row.data));
    });

  app.get<{ Params: { id: string } }>('/api/v1/attachments/:id', async (request, reply) => {
    const user = await office.user(request);
    const [row] = await db.query<{ task_id: string | null; content_type: string; data: Buffer }>(
      'SELECT task_id, content_type, data FROM attachments WHERE id = $1', [request.params.id]);
    if (!row) throw new AppError(404, 'ATTACHMENT_NOT_FOUND', 'الصورة غير موجودة');
    // A letter's own image: for whoever keeps the letters register (the assignee gets a copy on the margin's task).
    if (row.task_id === null) {
      if (!can(user, 'letters.read')) throw new AppError(404, 'ATTACHMENT_NOT_FOUND', 'الصورة غير موجودة');
    } else {
      await access(db, row.task_id, user);
    }
    return reply.header('content-type', row.content_type).header('cache-control', 'private, no-store').send(Buffer.from(row.data));
  });
}
