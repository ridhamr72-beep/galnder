import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import type { Db } from '../db/index.js';
import { AppError } from '../utils/errors.js';
import { parseBody } from '../utils/http.js';
import { access } from './attachments.js';
import type { After, OfficeContext } from './context.js';
import { recordEvent, type Actor } from './events.js';
import type { PushHub } from './push.js';

const MessageBody = z.object({
  /** A user id, or "principal": staff write to the principal, who hears it from the AI. */
  to: z.union([z.uuid(), z.literal('principal')]),
  body: z.string().trim().min(1).max(4000),
  task_id: z.uuid().optional(),
});

const MESSAGE_COLUMNS = `m.id, m.task_id, t.title AS task_title, m.body, m.created_at, m.read_at, m.from_ai, m.sender_id, m.recipient_id,
  CASE WHEN m.from_ai THEN 'الشخصية الأساسية' ELSE s.full_name END AS sender_name,
  CASE WHEN m.recipient_id IS NULL THEN 'الشخصية الأساسية' ELSE r.full_name END AS recipient_name`;
const MESSAGE_JOINS = `FROM messages m LEFT JOIN users s ON s.id = m.sender_id LEFT JOIN users r ON r.id = m.recipient_id
  LEFT JOIN tasks t ON t.id = m.task_id`;

export interface NewMessage {
  fromUserId?: string;
  fromAi?: boolean;
  /** Who acted when fromAi: the service key of the AI system. */
  aiActor?: Actor;
  /** undefined = to the principal. */
  toUserId?: string;
  body: string;
  taskId?: string;
}

/** Stores a message and rings the recipient's devices once committed. A message to the principal waits for the AI. */
export async function sendMessage(db: Db, hub: PushHub, after: After, message: NewMessage): Promise<string> {
  if (message.toUserId) {
    const [to] = await db.query('SELECT 1 FROM users WHERE id = $1 AND is_active AND NOT is_principal', [message.toUserId]);
    if (!to) throw new AppError(400, 'INVALID_RECIPIENT', 'لا يمكن الإرسال لهذا المستخدم');
  }
  const [row] = await db.query<{ id: string }>(
    `INSERT INTO messages (task_id, sender_id, from_ai, recipient_id, body) VALUES ($1, $2, $3, $4, $5) RETURNING id`,
    [message.taskId ?? null, message.fromUserId ?? null, message.fromAi ?? false, message.toUserId ?? null, message.body]);
  const id = row!.id;
  if (message.toUserId) {
    const [n] = await db.query<{ id: string }>(
      `INSERT INTO notifications (user_id, kind, level, task_id, message_id) VALUES ($1, 'message', 'normal', $2, $3) RETURNING id`,
      [message.toUserId, message.taskId ?? null, id]);
    after(() => void hub.send(n!.id));
  }
  await recordEvent(db, message.fromAi ? (message.aiActor ?? { type: 'ai' }) : { type: 'user', userId: message.fromUserId! }, 'message.sent',
    { type: 'message', id }, `رسالة: ${message.body.slice(0, 200)}`, { task_id: message.taskId ?? null }, message.toUserId ? 'general' : 'principal');
  return id;
}

/** Messages to the principal not yet read out, oldest first. */
export async function unreadForPrincipal(db: Db) {
  return db.query<{ id: string; sender_name: string; body: string; task_title: string | null; created_at: Date }>(
    `SELECT ${MESSAGE_COLUMNS} ${MESSAGE_JOINS} WHERE m.recipient_id IS NULL AND m.read_at IS NULL ORDER BY m.created_at`);
}

export async function markRead(db: Db, ids: string[]): Promise<void> {
  if (ids.length) await db.query('UPDATE messages SET read_at = now() WHERE id = ANY($1::uuid[]) AND read_at IS NULL', [ids]);
}

export function messageRoutes(app: FastifyInstance, office: OfficeContext): void {
  const { db, push } = office;

  /** GET /api/v1/messages — what I sent and what I received, newest first. */
  app.get('/api/v1/messages', async (request) => {
    const user = await office.user(request);
    const items = await db.query(
      `SELECT ${MESSAGE_COLUMNS} ${MESSAGE_JOINS} WHERE m.recipient_id = $1 OR m.sender_id = $1 ORDER BY m.created_at DESC LIMIT 200`, [user.id]);
    return { items, next_cursor: null };
  });

  app.post('/api/v1/messages', async (request, reply) => {
    const user = await office.user(request);
    const body = parseBody(MessageBody, request.body);
    // A message about a task goes only to someone who may see that task: no leaking a sealed task through a chat.
    if (body.task_id) await access(db, body.task_id, user);
    const id = await office.tx((tx, after) => sendMessage(tx, push, after, {
      fromUserId: user.id, body: body.body, ...(body.to === 'principal' ? {} : { toUserId: body.to }), ...(body.task_id ? { taskId: body.task_id } : {}),
    }));
    const [message] = await db.query(`SELECT ${MESSAGE_COLUMNS} ${MESSAGE_JOINS} WHERE m.id = $1`, [id]);
    return reply.code(201).send(message);
  });

  app.post<{ Params: { id: string } }>('/api/v1/messages/:id/read', async (request, reply) => {
    const user = await office.user(request);
    const read = await db.query('UPDATE messages SET read_at = COALESCE(read_at, now()) WHERE id = $1 AND recipient_id = $2 RETURNING id', [request.params.id, user.id]);
    if (!read.length) throw new AppError(404, 'MESSAGE_NOT_FOUND', 'الرسالة غير موجودة');
    const stopped = await db.query<{ id: string }>(
      `UPDATE notifications SET opened_at = now(), next_alert_at = NULL WHERE message_id = $1 AND opened_at IS NULL RETURNING id`, [request.params.id]);
    stopped.forEach((n) => push.dismiss(user.id, n.id));
    return reply.code(204).send();
  });

  /** GET /api/v1/tasks/:id/messages — the conversation about one task, for whoever may see the task. */
  app.get<{ Params: { id: string } }>('/api/v1/tasks/:id/messages', async (request) => {
    await access(db, request.params.id, await office.user(request));
    const items = await db.query(`SELECT ${MESSAGE_COLUMNS} ${MESSAGE_JOINS} WHERE m.task_id = $1 ORDER BY m.created_at`, [request.params.id]);
    return { items, next_cursor: null };
  });
}
