import type { Db } from '../db/index.js';

export interface Actor {
  type: 'user' | 'ai' | 'system';
  userId?: string;
  /** The service key that acted (the AI system), so the record says which program did it. */
  keyId?: string;
}

export const SYSTEM: Actor = { type: 'system' };

/** Adds to the record of what happened. Called inside the change's own transaction, so neither exists without the other. */
export async function recordEvent(
  db: Db,
  actor: Actor,
  eventType: string,
  subject: { type: string; id: string },
  summary: string,
  payload: Record<string, unknown> = {},
  visibility: 'general' | 'principal' = 'general',
): Promise<void> {
  await db.query(
    `INSERT INTO events (event_type, actor_type, actor_user_id, actor_key_id, subject_type, subject_id, summary, payload, visibility)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
    [eventType, actor.type, actor.userId ?? null, actor.keyId ?? null, subject.type, subject.id, summary, JSON.stringify(payload), visibility],
  );
}

export async function getSetting<T>(db: Db, key: string): Promise<T> {
  const [row] = await db.query<{ value: T }>('SELECT value FROM settings WHERE key = $1', [key]);
  return row!.value;
}
