import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import type { Db } from '../db/index.js';
import { AppError } from '../utils/errors.js';
import { parseBody } from '../utils/http.js';
import { requirePermission, type OfficeUser } from './auth.js';
import type { OfficeContext } from './context.js';
import { recordEvent } from './events.js';
import { createTask, Due, resolveDue } from './tasks.js';

const MeetingBody = z.object({
  title: z.string().trim().min(1).max(300),
  held_at: z.iso.datetime({ offset: true }),
  location: z.string().nullish(),
  body: z.string().default(''),
});
const MeetingPatch = MeetingBody.partial();
const PublishBody = z.object({
  decisions: z.array(z.string().trim().min(1).max(1000)).max(100).default([]),
  tasks: z.array(z.object({
    title: z.string().trim().min(1).max(300),
    description: z.string().default(''),
    assignee_id: z.uuid(),
    priority: z.enum(['normal', 'high']).default('normal'),
    ...Due,
  })).default([]),
});

// Another writer gets the same answer as for a missing one: they do not even learn it exists.
const notFound = () => new AppError(404, 'MEETING_NOT_FOUND', 'المحضر غير موجود');

async function own(db: Db, id: string, userId: string, forUpdate = false) {
  const [meeting] = await db.query<Record<string, unknown>>(
    `SELECT * FROM meetings WHERE id = $1 AND created_by = $2 ${forUpdate ? 'FOR UPDATE' : ''}`, [id, userId]);
  if (!meeting) throw notFound();
  return meeting;
}

async function detail(db: Db, id: string, userId: string) {
  const meeting = await own(db, id, userId);
  const tasks = await db.query(
    `SELECT id, title, priority, status, assignee_name, due_at, opened_at, completed_at, completed_on_time, is_overdue
     FROM office_tasks WHERE meeting_id = $1 ORDER BY created_at`, [id]);
  return { ...meeting, tasks };
}

/** The minutes officer's meetings: only their own, and the minutes text never reaches an employee. */
export function meetingRoutes(app: FastifyInstance, office: OfficeContext): void {
  const { db, push } = office;
  const writer = async (request: Parameters<OfficeContext['user']>[0]): Promise<OfficeUser> => {
    const user = await office.user(request);
    requirePermission(user, 'meetings.write');
    return user;
  };

  app.get('/api/v1/meetings', async (request) => {
    const user = await writer(request);
    const items = await db.query(
      'SELECT id, title, held_at, location, status, published_at, updated_at FROM meetings WHERE created_by = $1 ORDER BY held_at DESC', [user.id]);
    return { items, next_cursor: null };
  });

  app.post('/api/v1/meetings', async (request, reply) => {
    const user = await writer(request);
    const body = parseBody(MeetingBody, request.body);
    const [meeting] = await db.query<{ id: string }>(
      'INSERT INTO meetings (title, held_at, location, body, created_by) VALUES ($1, $2, $3, $4, $5) RETURNING id',
      [body.title, body.held_at, body.location ?? null, body.body, user.id]);
    return reply.code(201).send(await detail(db, meeting!.id, user.id));
  });

  app.get<{ Params: { id: string } }>('/api/v1/meetings/:id', async (request) => detail(db, request.params.id, (await writer(request)).id));

  app.patch<{ Params: { id: string } }>('/api/v1/meetings/:id', async (request) => {
    const user = await writer(request);
    const body = parseBody(MeetingPatch, request.body);
    const meeting = await own(db, request.params.id, user.id, true);
    if (meeting.status !== 'draft') throw new AppError(409, 'MEETING_PUBLISHED', 'لا يمكن تعديل محضر منشور');
    await db.query(
      `UPDATE meetings SET title = COALESCE($2, title), held_at = COALESCE($3, held_at),
         location = CASE WHEN $4 THEN $5 ELSE location END, body = COALESCE($6, body), updated_at = now() WHERE id = $1`,
      [request.params.id, body.title ?? null, body.held_at ?? null, body.location !== undefined, body.location ?? null, body.body ?? null]);
    return detail(db, request.params.id, user.id);
  });

  /** POST /api/v1/meetings/:id/publish — every task at once, or none: one bad row cancels the whole publish. */
  app.post<{ Params: { id: string } }>('/api/v1/meetings/:id/publish', async (request) => {
    const user = await writer(request);
    const body = parseBody(PublishBody, request.body);
    await office.tx(async (tx, after) => {
      const meeting = await own(tx, request.params.id, user.id, true);
      if (meeting.status !== 'draft') throw new AppError(409, 'MEETING_PUBLISHED', 'المحضر منشور سابقاً');
      await tx.query(`UPDATE meetings SET status = 'published', published_at = now(), decisions = $2, updated_at = now() WHERE id = $1`,
        [meeting.id, JSON.stringify(body.decisions)]);
      for (const t of body.tasks) {
        await createTask(tx, push, after, { type: 'user', userId: user.id }, {
          title: t.title, description: t.description, assigneeId: t.assignee_id, priority: t.priority, source: 'meeting',
          meetingId: String(meeting.id), due: await resolveDue(tx, t.due_at, t.due_in_hours),
        });
      }
      await recordEvent(tx, { type: 'user', userId: user.id }, 'meeting.published', { type: 'meeting', id: String(meeting.id) },
        `محضر اجتماع: ${String(meeting.title)}. ${body.decisions.length} قرارات، ووُزّعت ${body.tasks.length} مهام`,
        { tasks: body.tasks.length, decisions: body.decisions.length }, 'principal');
    });
    return detail(db, request.params.id, user.id);
  });
}
