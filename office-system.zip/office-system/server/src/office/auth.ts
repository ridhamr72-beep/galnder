import { createHash, createHmac, randomBytes, scrypt as scryptCb, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import type { FastifyRequest } from 'fastify';
import type { Db } from '../db/index.js';
import { AppError } from '../utils/errors.js';

const scrypt = promisify(scryptCb) as (password: string, salt: Buffer, keylen: number) => Promise<Buffer>;
const KEY_LENGTH = 64;
const ACCESS_TOKEN_SECONDS = 15 * 60;

/** scrypt$salt$hash, both base64. Built into Node, so no native password library to install on Windows. */
export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const hash = await scrypt(password, salt, KEY_LENGTH);
  return `scrypt$${salt.toString('base64')}$${hash.toString('base64')}`;
}

// Compared against when the user does not exist, so the answer takes as long either way.
const DUMMY_HASH = `scrypt$${Buffer.alloc(16).toString('base64')}$${Buffer.alloc(KEY_LENGTH).toString('base64')}`;

export async function verifyPassword(password: string, stored: string | null): Promise<boolean> {
  const [scheme, salt, hash] = (stored ?? DUMMY_HASH).split('$');
  if (scheme !== 'scrypt' || !salt || !hash) return false;
  const expected = Buffer.from(hash, 'base64');
  const actual = await scrypt(password, Buffer.from(salt, 'base64'), expected.length);
  return timingSafeEqual(actual, expected) && stored !== null;
}

export const newToken = () => randomBytes(32).toString('base64url');
export const hashToken = (token: string) => createHash('sha256').update(token).digest('hex');

const b64 = (value: object) => Buffer.from(JSON.stringify(value)).toString('base64url');

export function signAccessToken(secret: string, userId: string, deviceId: string): string {
  const body = `${b64({ alg: 'HS256', typ: 'JWT' })}.${b64({ sub: userId, did: deviceId, exp: Math.floor(Date.now() / 1000) + ACCESS_TOKEN_SECONDS })}`;
  return `${body}.${createHmac('sha256', secret).update(body).digest('base64url')}`;
}

export function readAccessToken(secret: string, token: string): { userId: string; deviceId: string } | undefined {
  const [header, payload, signature] = token.split('.');
  if (!header || !payload || !signature) return undefined;
  const expected = createHmac('sha256', secret).update(`${header}.${payload}`).digest();
  const given = Buffer.from(signature, 'base64url');
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return undefined;
  try {
    const claims = JSON.parse(Buffer.from(payload, 'base64url').toString()) as { sub?: string; did?: string; exp?: number };
    if (!claims.sub || !claims.did || !claims.exp || claims.exp * 1000 < Date.now()) return undefined;
    return { userId: claims.sub, deviceId: claims.did };
  } catch {
    return undefined;
  }
}

/** The signing secret lives in the database, made on first start: nothing to set by hand, and the same on every restart. */
export async function signingSecret(db: Db): Promise<string> {
  await db.query(
    `INSERT INTO settings (key, value) VALUES ('secret.jwt', to_jsonb($1::text)) ON CONFLICT (key) DO NOTHING`,
    [randomBytes(48).toString('base64url')],
  );
  const [row] = await db.query<{ value: string }>(`SELECT value #>> '{}' AS value FROM settings WHERE key = 'secret.jwt'`);
  return row!.value;
}

export interface OfficeUser {
  id: string;
  deviceId: string;
  username: string;
  fullName: string;
  roleCode: string;
  permissions: Set<string>;
}

export const can = (user: OfficeUser, permission: string) => user.permissions.has(permission);

const unauthorized = () => new AppError(401, 'UNAUTHORIZED', 'سجّل الدخول أوّلاً');

function bearer(request: FastifyRequest): string | undefined {
  const header = request.headers.authorization;
  return header?.startsWith('Bearer ') ? header.slice(7).trim() : undefined;
}

/** The signed-in user of an /api/v1 request, with the permissions of their role right now. */
export async function currentUser(db: Db, secret: string, request: FastifyRequest): Promise<OfficeUser> {
  const token = bearer(request);
  const claims = token ? readAccessToken(secret, token) : undefined;
  if (!claims) throw unauthorized();
  const [user] = await db.query<{ id: string; username: string; full_name: string; role_id: string; role_code: string }>(
    `SELECT u.id, u.username, u.full_name, r.id AS role_id, r.code AS role_code
     FROM users u JOIN roles r ON r.id = u.role_id JOIN devices d ON d.user_id = u.id
     WHERE u.id = $1 AND u.is_active AND d.id = $2 AND d.revoked_at IS NULL`,
    [claims.userId, claims.deviceId],
  );
  if (!user) throw unauthorized();
  const granted = await db.query<{ permission_code: string }>('SELECT permission_code FROM role_permissions WHERE role_id = $1', [user.role_id]);
  return {
    id: user.id,
    deviceId: claims.deviceId,
    username: user.username,
    fullName: user.full_name,
    roleCode: user.role_code,
    permissions: new Set(granted.map((g) => g.permission_code)),
  };
}

export function requirePermission(user: OfficeUser, permission: string): void {
  if (!can(user, permission)) throw new AppError(403, 'FORBIDDEN', 'لا تملك هذه الصلاحية');
}
