import type { Db } from '../db/index.js';
import { readable, speakDuration } from './words.js';
import { getSetting } from './events.js';
import { localClock, timeZone, zoneOffset } from './reports.js';

/**
 * The principal's briefing when she opens her screen, built by code from the data (nothing invented), in the order
 * executive assistants use: what waits for her decision, what is late, today's appointments with a line on each
 * guest, what happened since she last looked, and yesterday in short. Each item is something she can act on by voice.
 */

export interface BriefingItem {
  text: string;
  /** What she can say about it, e.g. «سكّرها» or «همّشه لسامي». */
  say?: string;
  urgent?: boolean;
}

export interface Briefing {
  greeting: string;
  since: string | null;
  sections: Array<{ key: string; title: string; items: BriefingItem[] }>;
  /** The whole briefing as a few spoken sentences. */
  spoken: string;
}

const count = (n: number, one: string, two: string, many: string) => (n === 1 ? one : n === 2 ? two : `${n} ${many}`);

export async function buildBriefing(db: Db, now = new Date()): Promise<Briefing> {
  const zone = await timeZone(db);
  const offset = zoneOffset(zone);
  const seen = await getSetting<string | null>(db, 'principal.last_seen').catch(() => null);
  const since = seen ? new Date(seen) : new Date(now.getTime() - 24 * 3_600_000);
  const today = localClock(zone, now).date;
  const hour = Number(localClock(zone, now).time.slice(0, 2));

  const [letters, results, late, appointments, sinceResults, sinceMessages, yesterday] = await Promise.all([
    db.query<{ subject: string; party: string | null }>(
      `SELECT subject, party FROM letters WHERE direction = 'incoming' AND task_id IS NULL ORDER BY created_at DESC LIMIT 10`),
    db.query<{ title: string; assignee: string; result: string }>(
      `SELECT t.title, u.full_name AS assignee, s.result_text AS result FROM tasks t JOIN users u ON u.id = t.assignee_id
       JOIN task_submissions s ON s.task_id = t.id AND s.decision IS NULL WHERE t.status = 'submitted' AND t.created_by_ai ORDER BY s.submitted_at`),
    db.query<{ assignee: string; titles: string[]; worst_s: number }>(
      `SELECT assignee_name AS assignee, array_agg(title ORDER BY overdue_s DESC) AS titles, max(overdue_s) AS worst_s
       FROM office_tasks WHERE is_overdue AND status <> 'submitted' GROUP BY assignee_name ORDER BY max(overdue_s) DESC`),
    db.query<{ title: string; kind: string; starts_at: Date; guest: string | null; organization: string | null; notes: string | null }>(
      `SELECT a.title, a.kind, a.starts_at, p.full_name AS guest, p.organization, p.notes FROM appointments a
       LEFT JOIN persons p ON p.id = a.person_id
       WHERE a.cancelled_at IS NULL AND (a.starts_at AT TIME ZONE $1::interval)::date = $2::date AND a.starts_at > $3
       ORDER BY a.starts_at`, [offset, today, now]),
    db.query<{ title: string; assignee: string; status: string }>(
      `SELECT t.title, u.full_name AS assignee, t.status FROM tasks t JOIN users u ON u.id = t.assignee_id
       WHERE (t.closed_at > $1) OR (t.status = 'submitted' AND t.updated_at > $1 AND NOT t.created_by_ai) ORDER BY t.updated_at DESC LIMIT 8`, [since]),
    db.query<{ sender: string; body: string }>(
      `SELECT u.full_name AS sender, m.body FROM messages m JOIN users u ON u.id = m.sender_id
       WHERE m.recipient_id IS NULL AND m.read_at IS NULL ORDER BY m.created_at`),
    db.query<{ made: number; closed: number; late: number }>(
      `SELECT count(*) FILTER (WHERE (created_at AT TIME ZONE $1::interval)::date = $2::date - 1)::int AS made,
              count(*) FILTER (WHERE (closed_at AT TIME ZONE $1::interval)::date = $2::date - 1)::int AS closed,
              count(*) FILTER (WHERE is_overdue AND (due_at AT TIME ZONE $1::interval)::date = $2::date - 1)::int AS late
       FROM office_tasks`, [offset, today]),
  ]);

  const sections: Briefing['sections'] = [];
  const decisions: BriefingItem[] = [
    ...letters.map((l) => ({ text: `كتاب «${l.subject}»${l.party ? ` من ${l.party}` : ''} ينتظر هامش`, say: 'همّشه لـ... أو وافق عليه' })),
    ...results.map((r) => ({ text: `${r.assignee} سلّم «${r.title}»: ${r.result}`, say: 'سكّرها، أو رجّعها ويا السبب' })),
  ];
  if (decisions.length) sections.push({ key: 'decisions', title: 'تنتظر قرارك', items: decisions });
  if (late.length) {
    sections.push({ key: 'late', title: 'المتأخر', items: late.map((l) => ({
      text: `${l.assignee}: ${l.titles.slice(0, 2).map((t) => `«${t}»`).join(' و')}${l.titles.length > 2 ? ` و${l.titles.length - 2} غيرها` : ''}، أكثرها متأخرة ${speakDuration(l.worst_s)}`,
      say: 'مدّدها، أو حوّلها لـ...', urgent: true })) });
  }
  if (appointments.length) {
    sections.push({ key: 'today', title: 'مواعيد اليوم', items: appointments.map((a) => ({
      text: `${readable(a.starts_at, zone).replace(/^.* الساعة /, 'الساعة ')}: ${a.title}${a.guest ? `، الضيف ${a.guest}${a.organization ? ` من ${a.organization}` : ''}${a.notes ? ` (${a.notes})` : ''}` : ''}` })) });
  }
  const news: BriefingItem[] = [
    ...sinceMessages.map((m) => ({ text: `رسالة من ${m.sender}: ${m.body}` })),
    ...sinceResults.map((r) => ({ text: r.status === 'closed' ? `انسكّرت «${r.title}» عند ${r.assignee}` : `${r.assignee} سلّم «${r.title}»` })),
  ];
  if (news.length) sections.push({ key: 'since', title: seen ? 'من آخر مرة فتحت' : 'آخر 24 ساعة', items: news });
  const y = yesterday[0]!;
  if (y.made || y.closed || y.late) {
    sections.push({ key: 'yesterday', title: 'البارحة', items: [{
      text: `انطت ${count(y.made, 'مهمة وحدة', 'مهمتين', 'مهام')}، وانسكّرت ${count(y.closed, 'وحدة', 'ثنتين', '')}${y.late ? `، وتأخرت ${count(y.late, 'وحدة', 'ثنتين', '')}` : ''}.`.replace(/ +،/g, '،').replace(/  +/g, ' ') }] });
  }

  const greeting = hour < 12 ? 'صباح الخير' : hour < 17 ? 'مساء الخير' : 'مساء النور';
  const spoken = [
    `${greeting}.`,
    decisions.length ? `تنتظر قرار حضرتك ${count(decisions.length, 'شغلة وحدة', 'شغلتين', 'أشياء')}: ${decisions.slice(0, 2).map((d) => d.text).join('، و')}.` : '',
    late.length ? `متأخر: ${late.slice(0, 2).map((l) => `${l.assignee} بـ«${l.titles[0]}»`).join('، و')}.` : 'ماكو شي متأخر.',
    appointments.length ? `اليوم عند حضرتك ${count(appointments.length, 'موعد واحد', 'موعدين', 'مواعيد')}، أولها ${appointments[0]!.title} ${readable(appointments[0]!.starts_at, zone).replace(/^.* الساعة /, 'الساعة ')}.` : '',
    sinceMessages.length ? `ووصلتك ${count(sinceMessages.length, 'رسالة', 'رسالتين', 'رسائل')}.` : '',
  ].filter(Boolean).join(' ');
  return { greeting, since: seen, sections, spoken };
}

/** She heard it: the next briefing starts from now. */
export async function markBriefingSeen(db: Db): Promise<void> {
  await db.query(
    `INSERT INTO settings (key, value) VALUES ('principal.last_seen', to_jsonb(now()::text))
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`);
}
