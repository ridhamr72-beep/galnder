import { localClock } from './reports.js';

/**
 * Times and durations as Arabic words, for the texts the office writes itself: announcements, the briefing, reports.
 */

const WEEKDAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

/** «الاثنين 9/11 الساعة 14:00» in the office's time zone. */
export function readable(value: Date | string | null | undefined, zone: string): string {
  if (!value) return 'غير معروف';
  const moment = new Date(value);
  const { time } = localClock(zone, moment);
  const day = new Date(moment.toLocaleString('en-US', { timeZone: zone }));
  return `${WEEKDAYS[day.getDay()]} ${day.getDate()}/${day.getMonth() + 1} الساعة ${time}`;
}

/** «5 دقيقة»، «3 ساعة»، «2 يوم». */
export function speakDuration(seconds: number | string | null | undefined): string {
  if (seconds === null || seconds === undefined) return 'غير معروف';
  const s = Number(seconds);
  if (s < 3600) return `${Math.max(1, Math.round(s / 60))} دقيقة`;
  const hours = s / 3600;
  return hours < 48 ? `${Math.round(hours)} ساعة` : `${Math.round(hours / 24)} يوم`;
}
