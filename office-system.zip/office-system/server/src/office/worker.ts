import type { FastifyBaseLogger } from 'fastify';
import type { Db } from '../db/index.js';
import { collectAnnouncements } from './announce.js';
import type { OfficeContext } from './context.js';
import { getSetting, recordEvent, SYSTEM } from './events.js';
import { notify, repeatMinutes } from './push.js';
import { generateReport, localClock, timeZone } from './reports.js';

/** Rings again what is still unopened, at its level's interval. */
export async function realertUnopened(office: OfficeContext): Promise<number> {
  return office.tx(async (tx, after) => {
    const due = await tx.query<{ id: string; level: string }>(
      `SELECT id, level FROM notifications
       WHERE next_alert_at <= now() AND opened_at IS NULL AND dismissed_at IS NULL FOR UPDATE SKIP LOCKED`);
    for (const n of due) {
      await tx.query(
        `UPDATE notifications SET alert_count = alert_count + 1, next_alert_at = now() + make_interval(mins => $2) WHERE id = $1`,
        [n.id, await repeatMinutes(tx, n.level)]);
      after(() => void office.push.send(n.id));
    }
    return due.length;
  });
}

/** Sends the reminders whose time has come; one whose task changed due date or is done is skipped. */
export async function runDueJobs(office: OfficeContext): Promise<number> {
  return office.tx(async (tx, after) => {
    const jobs = await tx.query<{ id: string; kind: string; payload: { task_id: string; due_at: string } }>(
      `SELECT id, kind, payload FROM jobs WHERE done_at IS NULL AND run_at <= now() ORDER BY run_at LIMIT 100 FOR UPDATE SKIP LOCKED`);
    for (const job of jobs) {
      if (job.kind === 'task_reminder') {
        const [task] = await tx.query<{ id: string; title: string; assignee_id: string; priority: string; due_at: Date }>(
          `SELECT id, title, assignee_id, priority, due_at FROM tasks WHERE id = $1 AND status NOT IN ('submitted', 'closed', 'cancelled')`,
          [job.payload.task_id]);
        if (task && new Date(task.due_at).getTime() === new Date(job.payload.due_at).getTime()) {
          await notify(tx, office.push, after, task.assignee_id, 'task_reminder', task.priority, task.id, false);
          await recordEvent(tx, SYSTEM, 'task.reminder_sent', { type: 'task', id: task.id }, `ذُكّر الموظف بالمهمة: ${task.title}`);
        }
      }
      await tx.query('UPDATE jobs SET done_at = now() WHERE id = $1', [job.id]);
    }
    return jobs.length;
  });
}

export async function generateDueReports(db: Db, now = new Date()): Promise<string[]> {
  const { date, time } = localClock(await timeZone(db), now);
  const made: string[] = [];
  for (const slot of ['morning', 'evening'] as const) {
    const at = await getSetting<string>(db, `report.${slot}_time`);
    if (time >= at && (await generateReport(db, date, slot))) made.push(slot);
  }
  return made;
}

/** The office's background work, inside the server: no extra service to run. */
export function startWorker(office: OfficeContext, log: FastifyBaseLogger, everyMs = 15_000): () => void {
  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    // Each step on its own: a failing report must not stop the reminders.
    for (const [name, step] of [
      ['realert', () => realertUnopened(office)],
      ['jobs', () => runDueJobs(office)],
      ['reports', () => generateDueReports(office.db)],
      ['announce', () => collectAnnouncements(office.db)],
    ] as const) {
      await step().catch((err: unknown) => log.error({ err, step: name }, 'office worker step failed'));
    }
    running = false;
  };
  const timer = setInterval(() => void tick(), everyMs);
  timer.unref();
  return () => clearInterval(timer);
}
