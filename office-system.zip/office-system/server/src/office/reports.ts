import type { FastifyInstance } from 'fastify';
import type { Db } from '../db/index.js';
import { requirePermission } from './auth.js';
import type { OfficeContext } from './context.js';
import { getSetting, recordEvent, SYSTEM } from './events.js';

const COLUMNS = 'id AS task_id, title, assignee_name AS assignee';

/** How things stand now: shared by the follow-up dashboard and the morning and evening reports. */
export async function overview(db: Db) {
  const [overdue, dueSoon, notOpened, awaitingReview] = await Promise.all([
    db.query(`SELECT ${COLUMNS}, priority, due_at, overdue_s FROM office_tasks WHERE is_overdue ORDER BY overdue_s DESC`),
    db.query(`SELECT ${COLUMNS}, priority, due_at FROM office_tasks
              WHERE status NOT IN ('closed', 'cancelled') AND NOT is_overdue AND due_at < now() + interval '24 hours' ORDER BY due_at`),
    db.query(`SELECT ${COLUMNS}, device_not_reached, EXTRACT(EPOCH FROM now() - created_at)::bigint AS waiting_s
              FROM office_tasks WHERE opened_at IS NULL AND status = 'assigned' ORDER BY created_at`),
    db.query(`SELECT ${COLUMNS}, priority, due_at FROM office_tasks WHERE status = 'submitted' ORDER BY due_at`),
  ]);
  return { overdue, due_soon: dueSoon, not_opened: notOpened, awaiting_review: awaitingReview };
}

export async function performance(db: Db, start?: Date | string | null, end?: Date | string | null) {
  return db.query(
    `SELECT assignee_id, assignee_name AS assignee,
            count(*) FILTER (WHERE status <> 'cancelled') AS total_tasks,
            count(*) FILTER (WHERE status = 'closed') AS closed_tasks,
            count(*) FILTER (WHERE status = 'closed' AND completed_on_time) AS closed_on_time,
            count(*) FILTER (WHERE is_overdue) AS overdue_now,
            avg(receipt_delay_s)::bigint AS avg_receipt_delay_s, avg(execution_s)::bigint AS avg_execution_s
     FROM office_tasks
     WHERE ($1::timestamptz IS NULL OR created_at >= $1) AND ($2::timestamptz IS NULL OR created_at < $2)
     GROUP BY assignee_id, assignee_name ORDER BY assignee_name`, [start ?? null, end ?? null]);
}

/** The time of day in the office's time zone, as HH:mm and as a date. */
export function localClock(timeZone: string, now = new Date()): { date: string; time: string } {
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-CA', {
    timeZone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  }).formatToParts(now).map((p) => [p.type, p.value]));
  return { date: `${parts.year}-${parts.month}-${parts.day}`, time: `${parts.hour}:${parts.minute}` };
}

/** Makes the report of `slot` for `date` once; false when it already exists. */
export async function generateReport(db: Db, date: string, slot: 'morning' | 'evening'): Promise<boolean> {
  const state = await overview(db);
  const [last] = await db.query<{ at: Date | null }>('SELECT max(generated_at) AS at FROM daily_reports');
  const completed = await db.query(
    `SELECT ${COLUMNS}, completed_on_time, execution_s FROM office_tasks
     WHERE status = 'closed' AND ($1::timestamptz IS NULL OR closed_at > $1) ORDER BY execution_s`, [last?.at ?? null]);
  const content = { report_date: date, slot, overdue: state.overdue, due_soon: state.due_soon, not_opened: state.not_opened, completed };
  const [row] = await db.query<{ id: string }>(
    `INSERT INTO daily_reports (report_date, slot, content) VALUES ($1, $2, $3) ON CONFLICT (report_date, slot) DO NOTHING RETURNING id`,
    [date, slot, JSON.stringify(content)]);
  if (!row) return false;
  await recordEvent(db, SYSTEM, 'report.ready', { type: 'report', id: row.id },
    `تقرير ${slot === 'morning' ? 'صباحي' : 'مسائي'}: ${state.overdue.length} متأخرة و${state.due_soon.length} قريبة الانتهاء`);
  return true;
}

/**
 * The zone's offset now as an SQL interval ("+03:00"), for `AT TIME ZONE $n::interval`: a PostgreSQL without
 * time zone data (seen on Windows) rejects "Asia/Baghdad", and an interval needs none. Iraq keeps no daylight saving.
 */
export function zoneOffset(zone: string, at = new Date()): string {
  const name = new Intl.DateTimeFormat('en-US', { timeZone: zone, timeZoneName: 'longOffset' })
    .formatToParts(at).find((p) => p.type === 'timeZoneName')?.value ?? 'GMT';
  const match = /GMT([+-]\d{2}):?(\d{2})?/.exec(name);
  return match ? `${match[1]}:${match[2] ?? '00'}` : '+00:00';
}

export async function timeZone(db: Db): Promise<string> {
  return getSetting<string>(db, 'timezone');
}

export function reportRoutes(app: FastifyInstance, office: OfficeContext): void {
  app.get('/api/v1/dashboard/overview', async (request) => {
    requirePermission(await office.user(request), 'performance.read');
    return overview(office.db);
  });

  app.get<{ Querystring: { start?: string; end?: string } }>('/api/v1/dashboard/performance', async (request) => {
    requirePermission(await office.user(request), 'performance.read');
    return { items: await performance(office.db, request.query.start, request.query.end), next_cursor: null };
  });
}
