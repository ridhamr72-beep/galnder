import type { Db } from '../db/index.js';
import { AppError } from '../utils/errors.js';

/**
 * Finding a person or a task from what someone said. A program that speaks for the principal (the AI system) sends
 * the name or the words as they were said; the office decides who or what is meant, and asks back instead of guessing.
 */

export interface Person {
  id: string;
  full_name: string;
  job_title: string | null;
  role_name: string;
  aliases: string[];
}

/** One spelling for the same name: «مديرُ المكتب» and «مدير مكتب» match. */
export function normalizeArabic(text: string): string {
  return text.trim().toLowerCase()
    .replace(/[ً-ْـ]/g, '')
    .replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي')
    .split(/\s+/).map((w) => (w.startsWith('ال') && w.length > 3 ? w.slice(2) : w)).join(' ');
}

/** The staff (everyone active but the principal), by name. */
export const staff = (db: Db) => db.query<Person>(
  `SELECT u.id, u.full_name, u.job_title, r.name_ar AS role_name, u.aliases FROM users u JOIN roles r ON r.id = u.role_id
   WHERE u.is_active AND NOT u.is_principal ORDER BY u.full_name`);

/** Turns what was said (a name, a post, a nickname) into one person; with two candidates it refuses instead of guessing. */
export function resolvePerson(people: Person[], said: string): Person {
  const wanted = normalizeArabic(said);
  const words = new Set(wanted.split(' '));
  const names = (p: Person) => [p.full_name, p.job_title, p.role_name, ...p.aliases].filter(Boolean).map((n) => normalizeArabic(n!));
  const exact = people.filter((p) => names(p).includes(wanted));
  const partial = people.filter((p) => names(p).some((n) => [...words].every((w) => n.split(' ').includes(w))));
  const found = exact.length ? exact : partial;
  if (!found.length) throw new AppError(404, 'ASSIGNEE_NOT_FOUND', `ما لكيت أحد باسم ${said}.`);
  if (found.length > 1) {
    throw new AppError(409, 'AMBIGUOUS_ASSIGNEE', `منو تقصد، ${found.map((p) => p.full_name).join(' لو ')}؟`, {
      details: { candidates: found.map((p) => ({ id: p.id, full_name: p.full_name, job_title: p.job_title })) },
    });
  }
  return found[0]!;
}

// Words that come with every question and tell no task from another.
const GENERIC_WORDS = new Set(['مهمه', 'المهمه', 'مهام', 'المهام', 'موضوع', 'الموضوع', 'شغل', 'الشغل', 'صور', 'الصور']);

/** ILIKE patterns for the words of a search, written the way the search column is (`translate(..., 'أإآةى', 'اااهي')`). */
export function searchPatterns(text: string): string[] {
  const words = normalizeArabic(text).split(' ').filter((w) => !GENERIC_WORDS.has(w) && w.length > 1);
  return (words.length ? words : [normalizeArabic(text)]).map((w) => `%${w}%`);
}
