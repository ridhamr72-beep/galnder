import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import type { Db } from '../db/index.js';
import { AppError } from '../utils/errors.js';
import { parseBody } from '../utils/http.js';
import { can, requirePermission, type OfficeUser } from './auth.js';
import type { After, OfficeContext } from './context.js';
import { getSetting, recordEvent, type Actor } from './events.js';
import { notify, stopTaskAlerts, type PushHub } from './push.js';

type Row = Record<string, unknown>;

const EMPLOYEE_COLUMNS = 'id, title, description, priority, status, due_at, created_at, delivered_at, opened_at, started_at, closed_at';

const Priority = z.enum(['normal', 'high']);
export const Due = { due_at: z.iso.datetime({ offset: true }).optional(), due_in_hours: z.number().int().positive().optional() };
const TaskCreate = z.object({
  title: z.string().trim().min(1).max(300),
  description: z.string().default(''),
  assignee_id: z.uuid(),
  priority: Priority.default('normal'),
  ...Due,
});

const notFound = () => new AppError(404, 'TASK_NOT_FOUND', 'المهمة غير موجودة');
const badState = (status: unknown) => new AppError(409, 'TASK_BAD_STATE', 'حالة المهمة لا تسمح بهذا الفعل', { details: { status } });

export async function resolveDue(db: Db, dueAt?: string, dueInHours?: number): Promise<Date> {
  if (dueAt && dueInHours) throw new AppError(400, 'VALIDATION_ERROR', 'أرسل due_at أو due_in_hours، لا الاثنين');
  if (dueAt) {
    const due = new Date(dueAt);
    if (due.getTime() <= Date.now()) throw new AppError(400, 'DUE_IN_PAST', 'الموعد في الماضي');
    return due;
  }
  const hours = dueInHours ?? (await getSetting<number>(db, 'task.default_due_hours'));
  return new Date(Date.now() + hours * 3_600_000);
}

async function assigneeName(db: Db, id: string): Promise<string> {
  const [user] = await db.query<{ full_name: string; is_principal: boolean }>('SELECT full_name, is_principal FROM users WHERE id = $1 AND is_active', [id]);
  if (!user || user.is_principal) throw new AppError(400, 'INVALID_ASSIGNEE', 'لا يمكن تكليف هذا المستخدم');
  return user.full_name;
}

async function scheduleReminders(db: Db, taskId: string, due: Date): Promise<void> {
  for (const hours of [...(await getSetting<number[]>(db, 'reminder.before_due_hours')), 0]) {
    const runAt = new Date(due.getTime() - hours * 3_600_000);
    if (runAt.getTime() <= Date.now()) continue;
    await db.query(
      `INSERT INTO jobs (kind, payload, dedupe_key, run_at) VALUES ('task_reminder', $1, $2, $3) ON CONFLICT (dedupe_key) DO NOTHING`,
      [JSON.stringify({ task_id: taskId, due_at: due.toISOString() }), `reminder:${taskId}:${due.getTime()}:${hours}`, runAt]);
  }
}

export interface NewTask {
  title: string;
  description: string;
  assigneeId: string;
  priority: 'normal' | 'high';
  due: Date;
  source: 'voice_ai' | 'meeting' | 'app';
  utterance?: string;
  meetingId?: string;
}

/** Creates a task, records it, notifies the assignee once committed, and plans its reminders. */
export async function createTask(db: Db, hub: PushHub, after: After, actor: Actor, task: NewTask) {
  const name = await assigneeName(db, task.assigneeId);
  const [row] = await db.query<{ id: string; status: string; due_at: Date; priority: string }>(
    `INSERT INTO tasks (title, description, priority, source, original_utterance, meeting_id, assignee_id,
                        created_by_user, created_by_ai, original_due_at, due_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $10) RETURNING id, status, due_at, priority`,
    [task.title, task.description, task.priority, task.source, task.utterance ?? null, task.meetingId ?? null,
      task.assigneeId, actor.type === 'user' ? actor.userId : null, actor.type === 'ai', task.due]);
  await recordEvent(db, actor, 'task.created', { type: 'task', id: row!.id }, `كُلّف ${name} بمهمة: ${task.title}`,
    { assignee_id: task.assigneeId, priority: task.priority, source: task.source });
  await notify(db, hub, after, task.assigneeId, 'task_assigned', task.priority, row!.id, true);
  await scheduleReminders(db, row!.id, task.due);
  return { ...row!, assignee_id: task.assigneeId, assignee_name: name };
}

async function lock(db: Db, id: string): Promise<Row> {
  const [task] = await db.query('SELECT * FROM tasks WHERE id = $1 FOR UPDATE', [id]);
  if (!task) throw notFound();
  return task;
}

async function lockOwn(db: Db, id: string, userId: string): Promise<Row> {
  const task = await lock(db, id);
  if (task.assignee_id !== userId) throw notFound();
  return task;
}

/**
 * Everything the assignee needs to act without asking back: who sent it, the principal's own words when it came by
 * voice, priority and due. Never the minutes text of a meeting task.
 */
async function employeeView(db: Db, id: string) {
  const [task] = await db.query<Record<string, unknown>>(
    // No `source`: that a task came out of a private meeting is itself not for the assignee.
    `SELECT t.id, t.title, t.description, t.priority, t.status, t.due_at, t.created_at, t.delivered_at,
            t.opened_at, t.started_at, t.closed_at, t.original_utterance,
            CASE WHEN t.created_by_ai THEN 'الشخصية الأساسية' ELSE s.full_name END AS sender_name, t.created_by_user AS sender_id,
            (SELECT count(*) FROM attachments a WHERE a.task_id = t.id) AS attachments,
            (SELECT count(*) FROM messages m WHERE m.task_id = t.id) AS messages
     FROM tasks t LEFT JOIN users s ON s.id = t.created_by_user WHERE t.id = $1`, [id]);
  const [returned] = await db.query<{ review_note: string }>(
    `SELECT review_note FROM task_submissions WHERE task_id = $1 AND decision = 'returned' ORDER BY attempt_no DESC LIMIT 1`, [id]);
  const [result] = await db.query<{ result_text: string }>(
    `SELECT result_text FROM task_submissions WHERE task_id = $1 ORDER BY attempt_no DESC LIMIT 1`, [id]);
  return { ...task, sealed: false, return_note: returned?.review_note ?? null, last_result: result?.result_text ?? null };
}

export async function cancelTask(db: Db, hub: PushHub, after: After, id: string, actor: Actor, reason: string) {
  const task = await lock(db, id);
  if (task.status === 'closed' || task.status === 'cancelled') throw badState(task.status);
  await db.query(`UPDATE tasks SET status = 'cancelled', cancelled_at = now(), cancel_reason = $2, updated_at = now() WHERE id = $1`, [id, reason]);
  await stopTaskAlerts(db, hub, after, id, 'dismissed_at');
  await notify(db, hub, after, String(task.assignee_id), 'task_cancelled', 'normal', id, false);
  await recordEvent(db, actor, 'task.cancelled', { type: 'task', id }, `أُلغيت المهمة ${String(task.title)}. السبب: ${reason}`);
  return (await db.query('SELECT id, status, cancelled_at FROM tasks WHERE id = $1', [id]))[0];
}

/**
 * Closes a handed-in task or sends it back with a reason. The follow-up officer does it from the app, the principal by
 * talking (then `by` is her account and `who` her title).
 */
export async function reviewTask(db: Db, hub: PushHub, after: After, actor: Actor, by: string | null, id: string,
  decision: 'accepted' | 'returned', note: string | null, who: string) {
  if (decision === 'returned' && !note?.trim()) throw new AppError(400, 'RETURN_NEEDS_REASON', 'اكتب سبب الإرجاع');
  const task = await lock(db, id);
  if (task.status !== 'submitted') throw badState(task.status);
  await db.query(
    `UPDATE task_submissions SET decision = $2, review_note = $3, reviewed_by = $4, reviewed_at = now() WHERE task_id = $1 AND decision IS NULL`,
    [task.id, decision, note, by]);
  await stopTaskAlerts(db, hub, after, String(task.id), 'dismissed_at'); // every reviewer's "review needed"
  if (decision === 'accepted') {
    await db.query(`UPDATE tasks SET status = 'closed', closed_at = now(), closed_by = $2, updated_at = now() WHERE id = $1`, [task.id, by]);
    await recordEvent(db, actor, 'task.closed', { type: 'task', id: String(task.id) }, `أغلق ${who} المهمة: ${String(task.title)}`);
    await notify(db, hub, after, String(task.assignee_id), 'task_closed', 'normal', String(task.id), false);
  } else {
    await db.query(`UPDATE tasks SET status = 'returned', updated_at = now() WHERE id = $1`, [task.id]);
    await recordEvent(db, actor, 'task.returned', { type: 'task', id: String(task.id) }, `رجّع ${who} المهمة: ${String(task.title)}. السبب: ${note}`);
    await notify(db, hub, after, String(task.assignee_id), 'task_returned', String(task.priority), String(task.id), true);
  }
  return (await db.query<{ id: string; status: string; closed_at: Date | null }>('SELECT id, status, closed_at FROM tasks WHERE id = $1', [task.id]))[0]!;
}

/** Hands a task to someone else: it is sealed again for them and their delivery and opening times start over. */
export async function reassignTask(db: Db, hub: PushHub, after: After, actor: Actor, id: string, assigneeId: string, reason: string) {
  const task = await lock(db, id);
  // A submission waiting for review is reviewed first, so it never hangs under someone else's name.
  if (['closed', 'cancelled', 'submitted'].includes(String(task.status))) throw badState(task.status);
  if (assigneeId === task.assignee_id) throw new AppError(409, 'SAME_ASSIGNEE', 'المهمة مكلّف بها نفس الشخص');
  const name = await assigneeName(db, assigneeId);
  await stopTaskAlerts(db, hub, after, id, 'dismissed_at');
  await db.query(
    `UPDATE tasks SET assignee_id = $2, status = 'assigned', delivered_at = NULL, opened_at = NULL, started_at = NULL, updated_at = now() WHERE id = $1`,
    [id, assigneeId]);
  await recordEvent(db, actor, 'task.reassigned', { type: 'task', id }, `حُوّلت المهمة ${String(task.title)} إلى ${name}. السبب: ${reason}`,
    { from: task.assignee_id, to: assigneeId });
  await notify(db, hub, after, assigneeId, 'task_assigned', String(task.priority), id, true);
  // The one it was taken from hears it too, so it does not stay on their mind.
  await notify(db, hub, after, String(task.assignee_id), 'task_reassigned', 'normal', id, false);
  return { id, title: String(task.title), assignee_name: name };
}

/** A new due date; the original stays recorded, so lateness is still judged fairly. */
export async function extendTask(db: Db, hub: PushHub, after: After, actor: Actor, id: string, due: Date, reason: string) {
  const task = await lock(db, id);
  if (task.status === 'closed' || task.status === 'cancelled') throw badState(task.status);
  if (due.getTime() <= Date.now()) throw new AppError(400, 'DUE_IN_PAST', 'الموعد في الماضي');
  await db.query('UPDATE tasks SET due_at = $2, updated_at = now() WHERE id = $1', [id, due]);
  await recordEvent(db, actor, 'task.extended', { type: 'task', id }, `مُدّد موعد المهمة ${String(task.title)}. السبب: ${reason}`);
  await scheduleReminders(db, id, due);
  await notify(db, hub, after, String(task.assignee_id), 'task_extended', 'normal', id, false);
  return { id, title: String(task.title), due_at: due };
}

async function reviewers(db: Db): Promise<string[]> {
  const rows = await db.query<{ id: string }>(
    `SELECT u.id FROM users u JOIN role_permissions p ON p.role_id = u.role_id WHERE p.permission_code = 'tasks.review' AND u.is_active`);
  return rows.map((r) => r.id);
}

export function taskRoutes(app: FastifyInstance, office: OfficeContext): void {
  const { db, push } = office;
  const actor = (u: OfficeUser): Actor => ({ type: 'user', userId: u.id });

  app.get('/api/v1/tasks/mine', async (request) => {
    const user = await office.user(request);
    const tasks = await db.query<Row>(
      `SELECT ${EMPLOYEE_COLUMNS} FROM tasks WHERE assignee_id = $1 AND status NOT IN ('closed', 'cancelled')
       ORDER BY opened_at IS NOT NULL, priority DESC, due_at`, [user.id]);
    // Before it is opened nothing of the task leaves the server: that is what "sealed" means.
    const items = await Promise.all(tasks.map(async (t) => t.opened_at
      ? employeeView(db, String(t.id))
      : { id: t.id, sealed: true, notification_level: t.priority, created_at: t.created_at }));
    return { items, next_cursor: null };
  });

  app.get('/api/v1/tasks/sent', async (request) => {
    const user = await office.user(request);
    const items = await db.query(
      `SELECT id, title, priority, status, assignee_name, created_at, due_at, delivered_at, opened_at, started_at, completed_at,
              receipt_delay_s, is_overdue, device_not_reached
       FROM office_tasks WHERE created_by_user = $1 ORDER BY created_at DESC`, [user.id]);
    return { items, next_cursor: null };
  });

  app.get('/api/v1/tasks/review-queue', async (request) => {
    requirePermission(await office.user(request), 'tasks.review');
    const items = await db.query(
      `SELECT t.id, t.title, t.description, t.priority, t.due_at, u.full_name AS assignee_name,
              s.id AS submission_id, s.attempt_no, s.result_text, s.submitted_at
       FROM tasks t JOIN users u ON u.id = t.assignee_id JOIN task_submissions s ON s.task_id = t.id AND s.decision IS NULL
       WHERE t.status = 'submitted' ORDER BY s.submitted_at`);
    return { items, next_cursor: null };
  });

  app.get<{ Querystring: Record<string, string | undefined> }>('/api/v1/tasks', async (request) => {
    requirePermission(await office.user(request), 'tasks.read_all');
    const q = request.query;
    const limit = Math.min(Math.max(Number(q.limit ?? 50) || 50, 1), 200);
    const items = await db.query<Row>(
      `SELECT * FROM office_tasks
       WHERE ($1::task_status IS NULL OR status = $1) AND ($2::uuid IS NULL OR assignee_id = $2)
         AND ($3::boolean IS NULL OR is_overdue = $3) AND ($4::timestamptz IS NULL OR created_at < $4)
       ORDER BY created_at DESC LIMIT $5`,
      [q.status ?? null, q.assignee_id ?? null, q.overdue === undefined ? null : q.overdue === 'true', q.before ?? null, limit + 1]);
    return { items: items.slice(0, limit), next_cursor: items.length > limit ? items[limit - 1]!.created_at : null };
  });

  app.post('/api/v1/tasks', async (request, reply) => {
    const user = await office.user(request);
    requirePermission(user, 'tasks.create');
    const body = parseBody(TaskCreate, request.body);
    const task = await office.tx(async (tx, after) => createTask(tx, push, after, actor(user), {
      title: body.title, description: body.description, assigneeId: body.assignee_id, priority: body.priority, source: 'app',
      due: await resolveDue(tx, body.due_at, body.due_in_hours),
    }));
    return reply.code(201).send(task);
  });

  /** POST /api/v1/tasks/:id/open — shows the task and records when; safe to repeat (the first time stays). */
  app.post<{ Params: { id: string } }>('/api/v1/tasks/:id/open', async (request) => {
    const user = await office.user(request);
    return office.tx(async (tx, after) => {
      const task = await lockOwn(tx, request.params.id, user.id);
      if (task.status === 'cancelled') throw notFound();
      if (!task.opened_at) {
        await tx.query(
          `UPDATE tasks SET status = 'opened', opened_at = now(), delivered_at = COALESCE(delivered_at, now()), updated_at = now() WHERE id = $1`,
          [task.id]);
        await recordEvent(tx, actor(user), 'task.opened', { type: 'task', id: String(task.id) }, `فتح ${user.fullName} المهمة: ${String(task.title)}`);
      }
      // Outside the "first time" branch: a returned task's alert also stops when it is opened again.
      await stopTaskAlerts(tx, push, after, String(task.id), 'opened_at', user.id);
      return employeeView(tx, String(task.id));
    });
  });

  app.get<{ Params: { id: string } }>('/api/v1/tasks/:id', async (request) => {
    const user = await office.user(request);
    if (can(user, 'tasks.read_all')) {
      const [task] = await db.query('SELECT * FROM office_tasks WHERE id = $1', [request.params.id]);
      if (!task) throw notFound();
      return task;
    }
    const [own] = await db.query('SELECT id FROM tasks WHERE id = $1 AND assignee_id = $2 AND opened_at IS NOT NULL', [request.params.id, user.id]);
    if (!own) throw notFound();
    return employeeView(db, request.params.id);
  });

  app.get<{ Params: { id: string } }>('/api/v1/tasks/:id/timeline', async (request) => {
    requirePermission(await office.user(request), 'tasks.read_all');
    const items = await db.query(
      `SELECT e.occurred_at, e.event_type, e.actor_type, u.full_name AS actor_name, e.summary
       FROM events e LEFT JOIN users u ON u.id = e.actor_user_id WHERE e.subject_type = 'task' AND e.subject_id = $1 ORDER BY e.id`,
      [request.params.id]);
    return { items, next_cursor: null };
  });

  app.post<{ Params: { id: string } }>('/api/v1/tasks/:id/start', async (request) => {
    const user = await office.user(request);
    return office.tx(async (tx) => {
      const task = await lockOwn(tx, request.params.id, user.id);
      if (task.status !== 'opened') throw badState(task.status);
      await tx.query(`UPDATE tasks SET status = 'in_progress', started_at = now(), updated_at = now() WHERE id = $1`, [task.id]);
      await recordEvent(tx, actor(user), 'task.started', { type: 'task', id: String(task.id) }, `باشر ${user.fullName} بالمهمة: ${String(task.title)}`);
      return employeeView(tx, String(task.id));
    });
  });

  app.post<{ Params: { id: string } }>('/api/v1/tasks/:id/submit', async (request) => {
    const user = await office.user(request);
    const { result_text } = parseBody(z.object({ result_text: z.string().trim().min(1) }), request.body);
    return office.tx(async (tx, after) => {
      const task = await lockOwn(tx, request.params.id, user.id);
      if (task.status !== 'in_progress' && task.status !== 'returned') throw badState(task.status);
      const [{ next }] = await tx.query<{ next: number }>('SELECT COALESCE(max(attempt_no), 0) + 1 AS next FROM task_submissions WHERE task_id = $1', [task.id]) as [{ next: number }];
      await tx.query('INSERT INTO task_submissions (task_id, attempt_no, result_text, submitted_by) VALUES ($1, $2, $3, $4)', [task.id, next, result_text, user.id]);
      await tx.query(`UPDATE tasks SET status = 'submitted', updated_at = now() WHERE id = $1`, [task.id]);
      await recordEvent(tx, actor(user), 'task.submitted', { type: 'task', id: String(task.id) },
        `سلّم ${user.fullName} نتيجة المهمة: ${String(task.title)}. النتيجة: ${result_text}`);
      for (const reviewer of await reviewers(tx)) await notify(tx, push, after, reviewer, 'review_needed', 'normal', String(task.id), false);
      return employeeView(tx, String(task.id));
    });
  });

  app.post<{ Params: { id: string } }>('/api/v1/tasks/:id/review', async (request) => {
    const user = await office.user(request);
    requirePermission(user, 'tasks.review');
    const body = parseBody(z.object({ decision: z.enum(['accepted', 'returned']), note: z.string().nullish() }), request.body);
    return office.tx((tx, after) => reviewTask(tx, push, after, actor(user), user.id, request.params.id, body.decision, body.note ?? null, user.fullName));
  });

  app.post<{ Params: { id: string } }>('/api/v1/tasks/:id/reassign', async (request) => {
    const user = await office.user(request);
    requirePermission(user, 'tasks.reassign');
    const body = parseBody(z.object({ assignee_id: z.uuid(), reason: z.string().trim().min(1) }), request.body);
    return office.tx(async (tx, after) => {
      await reassignTask(tx, push, after, actor(user), request.params.id, body.assignee_id, body.reason);
      return (await tx.query('SELECT id, status, assignee_id FROM tasks WHERE id = $1', [request.params.id]))[0];
    });
  });

  app.post<{ Params: { id: string } }>('/api/v1/tasks/:id/extend', async (request) => {
    const user = await office.user(request);
    requirePermission(user, 'tasks.reassign');
    const body = parseBody(z.object({ due_at: z.iso.datetime({ offset: true }), reason: z.string().trim().min(1) }), request.body);
    return office.tx(async (tx, after) => {
      await extendTask(tx, office.push, after, actor(user), request.params.id, new Date(body.due_at), body.reason);
      return (await tx.query('SELECT id, due_at, original_due_at FROM tasks WHERE id = $1', [request.params.id]))[0];
    });
  });

  app.post<{ Params: { id: string } }>('/api/v1/tasks/:id/cancel', async (request) => {
    const user = await office.user(request);
    requirePermission(user, 'tasks.cancel');
    const { reason } = parseBody(z.object({ reason: z.string().trim().min(1) }), request.body);
    return office.tx((tx, after) => cancelTask(tx, push, after, request.params.id, actor(user), reason));
  });

  app.get<{ Querystring: { after_seq?: string } }>('/api/v1/notifications/mine', async (request) => {
    const user = await office.user(request);
    const items = await db.query(
      `SELECT id, seq, kind, level, task_id, alert_count AS alert, created_at, delivered_at, opened_at FROM notifications
       WHERE user_id = $1 AND seq > $2 AND dismissed_at IS NULL ORDER BY seq`, [user.id, Number(request.query.after_seq ?? 0)]);
    return { items, next_cursor: null };
  });

  app.post<{ Params: { id: string } }>('/api/v1/notifications/:id/read', async (request, reply) => {
    const user = await office.user(request);
    const read = await db.query(
      `UPDATE notifications SET opened_at = now(), next_alert_at = NULL WHERE id = $1 AND user_id = $2 AND opened_at IS NULL RETURNING id`,
      [request.params.id, user.id]);
    if (!read.length) throw new AppError(404, 'NOTIFICATION_NOT_FOUND', 'الإشعار غير موجود');
    push.dismiss(user.id, request.params.id);
    return reply.code(204).send();
  });
}
