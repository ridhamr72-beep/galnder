import { randomUUID } from 'node:crypto';
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import type { Db } from '../db/index.js';
import { AppError } from '../utils/errors.js';
import { parseBody } from '../utils/http.js';
import { hashPassword, newToken, hashToken, signAccessToken, verifyPassword, type OfficeUser, requirePermission } from './auth.js';
import { getSetting, recordEvent, SYSTEM } from './events.js';
import type { OfficeContext } from './context.js';

const REFRESH_DAYS = 30;

export const Device = z.object({
  id: z.uuid().optional(),
  platform: z.enum(['android', 'windows']),
  name: z.string().trim().min(1).max(100),
  app_version: z.string().max(40).optional(),
});
const LoginBody = z.object({ username: z.string().trim().min(1), password: z.string().min(1), device: Device });
const RefreshBody = z.object({ refresh_token: z.string().min(1) });

const UserCreate = z.object({
  username: z.string().trim().min(2).max(50),
  full_name: z.string().trim().min(1).max(100),
  job_title: z.string().trim().max(100).nullish(),
  aliases: z.array(z.string()).default([]),
  role_code: z.string(),
  password: z.string().min(8).optional(),
});
const UserUpdate = z.object({
  full_name: z.string().trim().min(1).max(100).optional(),
  job_title: z.string().trim().max(100).nullish(),
  aliases: z.array(z.string()).optional(),
  role_code: z.string().optional(),
  is_active: z.boolean().optional(),
});
const RoleBody = z.object({
  code: z.string().regex(/^[a-z_]{2,40}$/).optional(),
  name_ar: z.string().trim().min(1).optional(),
  permission_codes: z.array(z.string()).optional(),
});

const invalidLogin = () => new AppError(401, 'INVALID_CREDENTIALS', 'اسم المستخدم أو كلمة المرور غير صحيحة');
const USER_COLUMNS = `u.id, u.username, u.full_name, u.job_title, u.aliases, u.is_active, u.is_principal, r.code AS role_code, r.name_ar AS role_name`;

async function issueTokens(db: Db, secret: string, userId: string, deviceId: string, withPush: boolean) {
  const refresh = newToken();
  await db.query(
    `INSERT INTO refresh_tokens (user_id, device_id, token_hash, expires_at) VALUES ($1, $2, $3, now() + make_interval(days => $4))`,
    [userId, deviceId, hashToken(refresh), REFRESH_DAYS],
  );
  const push = withPush ? newToken() : undefined;
  if (push) await db.query('UPDATE devices SET push_token_hash = $1 WHERE id = $2', [hashToken(push), deviceId]);
  return { access_token: signAccessToken(secret, userId, deviceId), refresh_token: refresh, device_id: deviceId, ...(push ? { push_token: push } : {}) };
}

/** Signs a user in on a device (known or new): the tokens and this device's push token. Password or face. */
export async function signIn(db: Db, secret: string, userId: string, device: z.infer<typeof Device>, how: string) {
  return db.tx(async (tx) => {
    const [known] = device.id
      ? await tx.query<{ id: string }>(
          `UPDATE devices SET name = $1, app_version = $2, last_seen_at = now()
           WHERE id = $3 AND user_id = $4 AND revoked_at IS NULL RETURNING id`,
          [device.name, device.app_version ?? null, device.id, userId])
      : [];
    const deviceId = known?.id ?? (await tx.query<{ id: string }>(
      `INSERT INTO devices (user_id, platform, name, app_version, last_seen_at) VALUES ($1, $2, $3, $4, now()) RETURNING id`,
      [userId, device.platform, device.name, device.app_version ?? null]))[0]!.id;
    await recordEvent(tx, { type: 'user', userId }, 'auth.login', { type: 'user', id: userId }, how);
    return issueTokens(tx, secret, userId, deviceId, true);
  });
}

async function isLocked(db: Db, userId: string): Promise<boolean> {
  const limit = await getSetting<number>(db, 'auth.max_failed_attempts');
  const minutes = await getSetting<number>(db, 'auth.lock_minutes');
  const [row] = await db.query<{ n: string }>(
    `SELECT count(*) AS n FROM events
     WHERE event_type = 'auth.login_failed' AND subject_id = $1 AND occurred_at > now() - make_interval(mins => $2)
       AND id > COALESCE((SELECT max(id) FROM events WHERE event_type = 'auth.login' AND subject_id = $1), 0)`,
    [userId, minutes],
  );
  return Number(row!.n) >= limit;
}

async function roleId(db: Db, code: string): Promise<string> {
  const [role] = await db.query<{ id: string }>('SELECT id FROM roles WHERE code = $1', [code]);
  if (!role) throw new AppError(400, 'UNKNOWN_ROLE', 'الدور غير موجود');
  return role.id;
}

async function userView(db: Db, id: string) {
  const [user] = await db.query(`SELECT ${USER_COLUMNS} FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = $1`, [id]);
  if (!user) throw new AppError(404, 'USER_NOT_FOUND', 'المستخدم غير موجود');
  return user;
}

async function roleView(db: Db, id: string) {
  const [role] = await db.query<{ id: string; code: string; name_ar: string; is_system: boolean }>(
    'SELECT id, code, name_ar, is_system FROM roles WHERE id = $1', [id]);
  if (!role) throw new AppError(404, 'ROLE_NOT_FOUND', 'الدور غير موجود');
  const codes = await db.query<{ permission_code: string }>('SELECT permission_code FROM role_permissions WHERE role_id = $1 ORDER BY 1', [id]);
  const [{ members }] = (await db.query<{ members: number }>('SELECT count(*)::int AS members FROM users WHERE role_id = $1 AND is_active', [id])) as [{ members: number }];
  return { ...role, members, permission_codes: codes.map((c) => c.permission_code) };
}

async function setPermissions(db: Db, id: string, codes: string[]): Promise<void> {
  const known = new Set((await db.query<{ code: string }>('SELECT code FROM permissions')).map((p) => p.code));
  const unknown = codes.filter((c) => !known.has(c));
  if (unknown.length) throw new AppError(400, 'UNKNOWN_PERMISSION', 'صلاحية غير معروفة', { details: { codes: unknown } });
  await db.query('DELETE FROM role_permissions WHERE role_id = $1', [id]);
  for (const code of new Set(codes)) await db.query('INSERT INTO role_permissions (role_id, permission_code) VALUES ($1, $2)', [id, code]);
}

const isUniqueViolation = (err: unknown) => (err as { code?: string }).code === '23505';

export function adminRoutes(app: FastifyInstance, office: OfficeContext): void {
  const { db } = office;
  const actor = (u: OfficeUser) => ({ type: 'user' as const, userId: u.id });

  /** POST /api/v1/auth/login — password sign-in; returns the tokens and, for this device, the push token. */
  app.post('/api/v1/auth/login', async (request) => {
    const body = parseBody(LoginBody, request.body);
    const [user] = await db.query<{ id: string; password_hash: string | null }>(
      'SELECT id, password_hash FROM users WHERE username = $1 AND is_active', [body.username]);
    if (!user) {
      await verifyPassword(body.password, null);
      throw invalidLogin();
    }
    if (await isLocked(db, user.id)) throw new AppError(429, 'LOGIN_LOCKED', 'محاولات كثيرة، حاول لاحقاً');
    if (!(await verifyPassword(body.password, user.password_hash))) {
      await recordEvent(db, SYSTEM, 'auth.login_failed', { type: 'user', id: user.id }, 'محاولة دخول فاشلة');
      throw invalidLogin();
    }
    return signIn(db, office.secret, user.id, body.device, 'دخول ناجح');
  });

  /** POST /api/v1/auth/refresh — a used refresh token ends every session of its device (it may have been stolen). */
  app.post('/api/v1/auth/refresh', async (request) => {
    const { refresh_token } = parseBody(RefreshBody, request.body);
    const [stored] = await db.query<{ id: string; user_id: string; device_id: string; expired: boolean; revoked_at: Date | null }>(
      `SELECT t.id, t.user_id, t.device_id, t.expires_at < now() AS expired, t.revoked_at
       FROM refresh_tokens t JOIN devices d ON d.id = t.device_id JOIN users u ON u.id = t.user_id
       WHERE t.token_hash = $1 AND d.revoked_at IS NULL AND u.is_active`, [hashToken(refresh_token)]);
    if (!stored || stored.expired) throw new AppError(401, 'INVALID_REFRESH', 'انتهت الجلسة');
    if (stored.revoked_at) {
      await db.query('UPDATE refresh_tokens SET revoked_at = now() WHERE device_id = $1 AND revoked_at IS NULL', [stored.device_id]);
      throw new AppError(401, 'INVALID_REFRESH', 'انتهت الجلسة');
    }
    return db.tx(async (tx) => {
      const [taken] = await tx.query('UPDATE refresh_tokens SET revoked_at = now() WHERE id = $1 AND revoked_at IS NULL RETURNING id', [stored.id]);
      if (!taken) throw new AppError(401, 'INVALID_REFRESH', 'انتهت الجلسة'); // the same token, twice at once
      return issueTokens(tx, office.secret, stored.user_id, stored.device_id, false);
    });
  });

  app.post('/api/v1/auth/logout', async (request, reply) => {
    const user = await office.user(request);
    await db.query('UPDATE refresh_tokens SET revoked_at = now() WHERE device_id = $1 AND revoked_at IS NULL', [user.deviceId]);
    await db.query('UPDATE devices SET push_token_hash = NULL WHERE id = $1', [user.deviceId]);
    return reply.code(204).send();
  });

  app.get('/api/v1/me', async (request) => {
    const user = await office.user(request);
    const [rank] = await db.query<{ role_name: string; job_title: string | null }>(
      'SELECT r.name_ar AS role_name, u.job_title FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = $1', [user.id]);
    return { id: user.id, username: user.username, full_name: user.fullName, role_code: user.roleCode, role_name: rank?.role_name ?? null,
      job_title: rank?.job_title ?? null, permissions: [...user.permissions].sort() };
  });

  /** GET /api/v1/directory — who a task can be sent to: names and posts only. */
  app.get('/api/v1/directory', async (request) => {
    requirePermission(await office.user(request), 'directory.read');
    const items = await db.query(
      `SELECT u.id, u.full_name, u.job_title, r.name_ar AS role_name FROM users u JOIN roles r ON r.id = u.role_id
       WHERE u.is_active AND NOT u.is_principal ORDER BY u.full_name`);
    return { items, next_cursor: null };
  });

  app.get('/api/v1/users', async (request) => {
    requirePermission(await office.user(request), 'users.manage');
    const items = await db.query(`SELECT ${USER_COLUMNS} FROM users u JOIN roles r ON r.id = u.role_id ORDER BY u.full_name`);
    return { items, next_cursor: null };
  });

  app.post('/api/v1/users', async (request, reply) => {
    const admin = await office.user(request);
    requirePermission(admin, 'users.manage');
    const body = parseBody(UserCreate, request.body);
    const principal = body.role_code === 'principal';
    if (!principal && !body.password) throw new AppError(400, 'PASSWORD_REQUIRED', 'كلمة المرور مطلوبة');
    const id = randomUUID();
    try {
      await db.query(
        `INSERT INTO users (id, username, full_name, job_title, aliases, role_id, password_hash, is_principal)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
        [id, body.username, body.full_name, body.job_title ?? null, body.aliases, await roleId(db, body.role_code),
          principal ? null : await hashPassword(body.password!), principal]);
    } catch (err) {
      if (isUniqueViolation(err)) throw new AppError(409, 'USER_CONFLICT', 'اسم المستخدم مأخوذ، أو الشخصية الأساسية موجودة');
      throw err;
    }
    await recordEvent(db, actor(admin), 'user.created', { type: 'user', id }, `أُنشئ مستخدم: ${body.full_name}`);
    return reply.code(201).send(await userView(db, id));
  });

  /** PATCH /api/v1/users/:id — name, post, aliases, role, active. The AI knows a new name from the next request. */
  app.patch<{ Params: { id: string } }>('/api/v1/users/:id', async (request) => {
    const admin = await office.user(request);
    requirePermission(admin, 'users.manage');
    const body = parseBody(UserUpdate, request.body);
    const current = await userView(db, request.params.id) as { is_principal: boolean; full_name: string };
    if (body.is_active === false && request.params.id === admin.id) throw new AppError(409, 'CANNOT_DISABLE_SELF', 'لا يمكنك تعطيل حسابك');
    if (body.role_code && (body.role_code === 'principal' || current.is_principal)) {
      throw new AppError(409, 'PRINCIPAL_ROLE_LOCKED', 'لا يمكن تغيير دور الشخصية الأساسية');
    }
    await db.query(
      `UPDATE users SET full_name = COALESCE($2, full_name), job_title = CASE WHEN $3 THEN $4 ELSE job_title END,
         aliases = COALESCE($5, aliases), is_active = COALESCE($6, is_active), role_id = COALESCE($7, role_id), updated_at = now()
       WHERE id = $1`,
      [request.params.id, body.full_name ?? null, body.job_title !== undefined, body.job_title ?? null, body.aliases ?? null,
        body.is_active ?? null, body.role_code ? await roleId(db, body.role_code) : null]);
    await recordEvent(db, actor(admin), 'user.updated', { type: 'user', id: request.params.id }, `عُدّل المستخدم: ${body.full_name ?? current.full_name}`);
    return userView(db, request.params.id);
  });

  app.post<{ Params: { id: string } }>('/api/v1/users/:id/password', async (request, reply) => {
    const admin = await office.user(request);
    requirePermission(admin, 'users.manage');
    const { password } = parseBody(z.object({ password: z.string().min(8) }), request.body);
    const user = await userView(db, request.params.id) as { is_principal: boolean };
    if (user.is_principal) throw new AppError(409, 'PRINCIPAL_HAS_NO_LOGIN', 'الشخصية الأساسية لا تدخل التطبيق');
    await db.query('UPDATE users SET password_hash = $1, updated_at = now() WHERE id = $2', [await hashPassword(password), request.params.id]);
    await db.query('UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL', [request.params.id]);
    return reply.code(204).send();
  });

  app.get('/api/v1/devices', async (request) => {
    requirePermission(await office.user(request), 'users.manage');
    const devices = await db.query<{ id: string }>(
      `SELECT d.id, d.user_id, u.full_name, d.platform, d.name, d.last_seen_at, d.revoked_at
       FROM devices d JOIN users u ON u.id = d.user_id ORDER BY u.full_name, d.created_at`);
    return { items: devices.map((d) => ({ ...d, connected: office.push.isConnected(d.id) })), next_cursor: null };
  });

  app.post<{ Params: { id: string } }>('/api/v1/devices/:id/revoke', async (request, reply) => {
    requirePermission(await office.user(request), 'users.manage');
    const revoked = await db.query('UPDATE devices SET revoked_at = now(), push_token_hash = NULL WHERE id = $1 AND revoked_at IS NULL RETURNING id', [request.params.id]);
    if (!revoked.length) throw new AppError(404, 'DEVICE_NOT_FOUND', 'الجهاز غير موجود');
    await db.query('UPDATE refresh_tokens SET revoked_at = now() WHERE device_id = $1 AND revoked_at IS NULL', [request.params.id]);
    office.push.disconnectDevice(request.params.id);
    return reply.code(204).send();
  });

  // ---- roles: the admin edits what each role may do, from the app ----

  app.get('/api/v1/permissions', async (request) => {
    requirePermission(await office.user(request), 'roles.manage');
    return { items: await db.query('SELECT code, description FROM permissions ORDER BY code'), next_cursor: null };
  });

  app.get('/api/v1/roles', async (request) => {
    requirePermission(await office.user(request), 'roles.manage');
    const ids = await db.query<{ id: string }>('SELECT id FROM roles ORDER BY is_system DESC, code');
    return { items: await Promise.all(ids.map((r) => roleView(db, r.id))), next_cursor: null };
  });

  app.post('/api/v1/roles', async (request, reply) => {
    const admin = await office.user(request);
    requirePermission(admin, 'roles.manage');
    const body = parseBody(RoleBody.required({ code: true, name_ar: true }), request.body);
    const id = await db.tx(async (tx) => {
      const [role] = await tx.query<{ id: string }>('INSERT INTO roles (code, name_ar) VALUES ($1, $2) ON CONFLICT (code) DO NOTHING RETURNING id', [body.code, body.name_ar]);
      if (!role) throw new AppError(409, 'ROLE_EXISTS', 'الدور موجود');
      await setPermissions(tx, role.id, body.permission_codes ?? []);
      await recordEvent(tx, actor(admin), 'role.created', { type: 'role', id: role.id }, `أُنشئ دور: ${body.name_ar}`);
      return role.id;
    });
    return reply.code(201).send(await roleView(db, id));
  });

  app.patch<{ Params: { id: string } }>('/api/v1/roles/:id', async (request) => {
    const admin = await office.user(request);
    requirePermission(admin, 'roles.manage');
    const body = parseBody(RoleBody, request.body);
    const role = await roleView(db, request.params.id);
    // Without this nobody could ever fix the roles again.
    if (role.code === 'admin' && body.permission_codes && !body.permission_codes.includes('roles.manage')) {
      throw new AppError(409, 'PROTECTED_PERMISSION', 'لا يمكن سحب إدارة الأدوار من مدير النظام');
    }
    await db.tx(async (tx) => {
      if (body.name_ar) await tx.query('UPDATE roles SET name_ar = $1 WHERE id = $2', [body.name_ar, request.params.id]);
      if (body.permission_codes) await setPermissions(tx, request.params.id, body.permission_codes);
      await recordEvent(tx, actor(admin), 'role.updated', { type: 'role', id: request.params.id }, `عُدّل دور: ${role.code}`, { permissions: body.permission_codes });
    });
    return roleView(db, request.params.id);
  });

  app.delete<{ Params: { id: string } }>('/api/v1/roles/:id', async (request, reply) => {
    requirePermission(await office.user(request), 'roles.manage');
    const role = await roleView(db, request.params.id);
    if (role.is_system) throw new AppError(409, 'SYSTEM_ROLE', 'لا يمكن حذف دور أساسي');
    const [used] = await db.query('SELECT 1 FROM users WHERE role_id = $1 LIMIT 1', [request.params.id]);
    if (used) throw new AppError(409, 'ROLE_IN_USE', 'الدور مستخدم');
    await db.query('DELETE FROM roles WHERE id = $1', [request.params.id]);
    return reply.code(204).send();
  });

  // ---- settings (never the secrets) ----

  app.get('/api/v1/settings', async (request) => {
    requirePermission(await office.user(request), 'settings.manage');
    const rows = await db.query<{ key: string; value: unknown }>(`SELECT key, value FROM settings WHERE key NOT LIKE 'secret.%' ORDER BY key`);
    return Object.fromEntries(rows.map((r) => [r.key, r.value]));
  });

  app.patch('/api/v1/settings', async (request) => {
    requirePermission(await office.user(request), 'settings.manage');
    const body = parseBody(z.record(z.string(), z.unknown()), request.body);
    const known = new Set((await db.query<{ key: string }>(`SELECT key FROM settings WHERE key NOT LIKE 'secret.%'`)).map((r) => r.key));
    const unknown = Object.keys(body).filter((k) => !known.has(k));
    if (unknown.length) throw new AppError(400, 'UNKNOWN_SETTING', 'إعداد غير معروف', { details: { keys: unknown } });
    for (const [key, value] of Object.entries(body)) {
      await db.query('UPDATE settings SET value = $1, updated_at = now() WHERE key = $2', [JSON.stringify(value), key]);
    }
    const rows = await db.query<{ key: string; value: unknown }>(`SELECT key, value FROM settings WHERE key NOT LIKE 'secret.%' ORDER BY key`);
    return Object.fromEntries(rows.map((r) => [r.key, r.value]));
  });
}

/** For the first start: `npm run office -- create-admin`. */
export async function createAdmin(db: Db, username: string, fullName: string, password: string): Promise<void> {
  await db.query(
    `INSERT INTO users (username, full_name, role_id, password_hash) SELECT $1, $2, id, $3 FROM roles WHERE code = 'admin'`,
    [username, fullName, await hashPassword(password)],
  );
}
