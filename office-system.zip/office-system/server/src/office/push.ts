import type { FastifyBaseLogger, FastifyInstance } from 'fastify';
import type { WebSocket } from 'ws';
import type { Db } from '../db/index.js';
import { hashToken } from './auth.js';
import type { After } from './context.js';
import { recordEvent, SYSTEM, getSetting } from './events.js';

const PING_MS = 30_000;
const SILENT_MS = 90_000;

interface NotificationRow {
  id: string;
  seq: string;
  kind: string;
  level: string;
  alert_count: number;
  task_id: string | null;
  user_id: string;
}

const FRAME_SQL = `SELECT id, seq, kind, level, alert_count, task_id, user_id FROM notifications
                   WHERE %WHERE% AND opened_at IS NULL AND dismissed_at IS NULL ORDER BY seq`;

/** The notification as it goes to a device: no text from the task, ever. The app shows a fixed sentence for `kind`. */
const frame = (n: NotificationRow) => ({
  type: 'notify', id: n.id, seq: Number(n.seq), kind: n.kind, level: n.level, alert: n.alert_count, task_id: n.task_id,
});

/** Devices connected right now, and sending to them. Everything in this one process, so no message broker. */
export class PushHub {
  private readonly sockets = new Map<string, Map<string, WebSocket>>(); // user -> device -> socket

  constructor(private readonly db: Db, private readonly log: FastifyBaseLogger) {}

  isConnected(deviceId: string): boolean {
    for (const devices of this.sockets.values()) if (devices.has(deviceId)) return true;
    return false;
  }

  disconnectDevice(deviceId: string): void {
    for (const devices of this.sockets.values()) devices.get(deviceId)?.close(4401);
  }

  private async deliver(n: NotificationRow, deviceId: string, socket: WebSocket): Promise<void> {
    if (socket.readyState !== socket.OPEN) return;
    socket.send(JSON.stringify(frame(n)));
    await this.db.query(
      `INSERT INTO notification_deliveries_sent (notification_id, device_id) VALUES ($1, $2)
       ON CONFLICT (notification_id, device_id) DO UPDATE SET sent_at = now()`, [n.id, deviceId]).catch(() => undefined);
  }

  /** Sends a stored notification to every connected device of its user. */
  async send(notificationId: string): Promise<void> {
    const [n] = await this.db.query<NotificationRow>(FRAME_SQL.replace('%WHERE%', 'id = $1'), [notificationId]);
    const devices = n && this.sockets.get(n.user_id);
    if (!n || !devices) return;
    for (const [deviceId, socket] of devices) await this.deliver(n, deviceId, socket);
  }

  dismiss(userId: string, notificationId: string): void {
    for (const socket of this.sockets.get(userId)?.values() ?? []) {
      if (socket.readyState === socket.OPEN) socket.send(JSON.stringify({ type: 'dismiss', id: notificationId }));
    }
  }

  /** GET /api/v1/ws — `Authorization: Bearer <push token>`. The token opens this channel only, never any data. */
  register(app: FastifyInstance): void {
    app.get('/api/v1/ws', { websocket: true }, async (socket, request) => {
      const header = request.headers.authorization ?? '';
      const token = header.startsWith('Bearer ') ? header.slice(7).trim() : '';
      const [device] = token
        ? await this.db.query<{ id: string; user_id: string }>(
            `UPDATE devices d SET last_seen_at = now() FROM users u
             WHERE d.push_token_hash = $1 AND d.revoked_at IS NULL AND u.id = d.user_id AND u.is_active
             RETURNING d.id, d.user_id`, [hashToken(token)])
        : [];
      if (!device) {
        socket.close(4401);
        return;
      }
      const devices = this.sockets.get(device.user_id) ?? new Map<string, WebSocket>();
      devices.get(device.id)?.close(4409); // the same device reconnected: keep the newest
      devices.set(device.id, socket);
      this.sockets.set(device.user_id, devices);

      let heard = Date.now();
      const ping = setInterval(() => {
        if (Date.now() - heard > SILENT_MS) socket.terminate();
        else if (socket.readyState === socket.OPEN) socket.send('{"type":"ping"}');
      }, PING_MS);

      socket.on('message', (raw: Buffer) => {
        heard = Date.now();
        void this.onMessage(device, socket, raw.toString()).catch((err: unknown) => this.log.warn({ err }, 'push message failed'));
      });
      socket.on('close', () => {
        clearInterval(ping);
        if (devices.get(device.id) === socket) devices.delete(device.id);
      });
    });
  }

  private async onMessage(device: { id: string; user_id: string }, socket: WebSocket, raw: string): Promise<void> {
    const message = JSON.parse(raw) as { type?: string; id?: string; last_seq?: number };
    if (message.type === 'hello') {
      const missed = await this.db.query<NotificationRow>(FRAME_SQL.replace('%WHERE%', 'user_id = $1 AND seq > $2'), [device.user_id, message.last_seq ?? 0]);
      for (const n of missed) await this.deliver(n, device.id, socket);
    } else if (message.type === 'ack' && message.id) {
      await acknowledge(this.db, message.id, device.user_id);
    } else if (message.type === 'ping') {
      socket.send('{"type":"pong"}');
    } else if (message.type === 'pong') {
      await this.db.query('UPDATE devices SET last_seen_at = now() WHERE id = $1', [device.id]);
    }
  }
}

/** The device got it: that is when the task reached the employee, whether they look or not. */
async function acknowledge(db: Db, notificationId: string, userId: string): Promise<void> {
  const [n] = await db.query<{ kind: string; task_id: string | null }>(
    `UPDATE notifications SET delivered_at = COALESCE(delivered_at, now()) WHERE id = $1 AND user_id = $2 RETURNING kind, task_id`,
    [notificationId, userId]);
  if (n?.kind !== 'task_assigned' || !n.task_id) return;
  const [task] = await db.query<{ id: string }>(
    `UPDATE tasks SET delivered_at = now(), updated_at = now() WHERE id = $1 AND assignee_id = $2 AND delivered_at IS NULL RETURNING id`,
    [n.task_id, userId]);
  if (task) await recordEvent(db, SYSTEM, 'task.delivered', { type: 'task', id: task.id }, 'وصلت المهمة إلى جهاز الموظف');
}

export async function repeatMinutes(db: Db, level: string): Promise<number> {
  return getSetting<number>(db, level === 'high' ? 'alert.high_repeat_minutes' : 'alert.normal_repeat_minutes');
}

/** Stores a notification and pushes it once the transaction commits. */
export async function notify(
  db: Db, hub: PushHub, after: After,
  userId: string, kind: string, level: string, taskId: string | null, repeats: boolean,
): Promise<void> {
  const minutes = repeats ? await repeatMinutes(db, level) : null;
  const [n] = await db.query<{ id: string }>(
    `INSERT INTO notifications (user_id, kind, level, task_id, next_alert_at)
     VALUES ($1, $2, $3, $4, now() + make_interval(mins => $5)) RETURNING id`,
    [userId, kind, level, taskId, minutes]);
  after(() => void hub.send(n!.id));
}

/** Stops a task's unopened notifications; `column` says why (opened, or no longer this person's). */
export async function stopTaskAlerts(
  db: Db, hub: PushHub, after: After, taskId: string, column: 'opened_at' | 'dismissed_at', userId?: string,
): Promise<void> {
  const stopped = await db.query<{ id: string; user_id: string }>(
    `UPDATE notifications SET ${column} = now(), next_alert_at = NULL
     WHERE task_id = $1 AND ($2::uuid IS NULL OR user_id = $2) AND opened_at IS NULL AND dismissed_at IS NULL
     RETURNING id, user_id`, [taskId, userId ?? null]);
  after(() => stopped.forEach((n) => hub.dismiss(n.user_id, n.id)));
}
