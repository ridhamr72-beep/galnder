import type { Db } from '../db/index.js';
import { readable, speakDuration } from './words.js';
import { getSetting } from './events.js';
import { markRead } from './messages.js';
import { overview, timeZone } from './reports.js';

/**
 * What the AI tells the principal without being asked: a task gone late, an urgent task nobody opened, a result handed
 * in for something she asked, a message for her, an appointment about to start, the morning and evening report.
 * The worker writes each happening once (subject_key); the AI system reads them through /api/v1/ai/announcements,
 * says them and marks them said.
 */

interface Candidate {
  kind: string;
  key: string;
  text: string;
  urgent: boolean;
  messageId?: string;
}

async function candidates(db: Db): Promise<Candidate[]> {
  const zone = await timeZone(db);
  const unopenedMinutes = await getSetting<number>(db, 'announce.unopened_minutes');
  const appointmentMinutes = await getSetting<number>(db, 'announce.appointment_minutes');
  const found: Candidate[] = [];

  // Late now, and late within the last day: an old backlog is the report's job, not a flood of alerts.
  const late = await db.query<{ id: string; title: string; assignee: string; priority: string; due_at: Date; overdue_s: number }>(
    `SELECT id, title, assignee_name AS assignee, priority, due_at, overdue_s FROM office_tasks
     WHERE is_overdue AND status NOT IN ('submitted') AND due_at > now() - interval '1 day'`);
  for (const t of late) {
    found.push({ kind: 'task_overdue', key: `overdue:${t.id}:${new Date(t.due_at).toISOString()}`, urgent: t.priority === 'high',
      text: `مهمة «${t.title}» عند ${t.assignee} تأخرت عن موعدها، وما سلّمها لهسه.` });
  }

  const unopened = await db.query<{ id: string; title: string; assignee: string; device_not_reached: boolean; waiting_s: number }>(
    `SELECT id, title, assignee_name AS assignee, device_not_reached, EXTRACT(EPOCH FROM now() - created_at)::bigint AS waiting_s
     FROM office_tasks WHERE priority = 'high' AND opened_at IS NULL AND status = 'assigned'
       AND created_at < now() - make_interval(mins => $1) AND created_at > now() - interval '1 day'`, [unopenedMinutes]);
  for (const t of unopened) {
    found.push({ kind: 'task_unopened', key: `unopened:${t.id}`, urgent: true,
      text: t.device_not_reached
        ? `المهمة العاجلة «${t.title}» ما وصلت لجهاز ${t.assignee} لهسه، جهازه مو متصل.`
        : `المهمة العاجلة «${t.title}» وصلت لـ${t.assignee} من ${speakDuration(t.waiting_s)} وما فتحها.` });
  }

  // A result for something the principal asked herself (the AI wrote the task).
  const results = await db.query<{ id: string; title: string; assignee: string; result_text: string }>(
    `SELECT s.id, t.title, u.full_name AS assignee, s.result_text FROM task_submissions s
     JOIN tasks t ON t.id = s.task_id JOIN users u ON u.id = s.submitted_by
     WHERE t.created_by_ai AND s.decision IS NULL AND s.submitted_at > now() - interval '1 day'`);
  for (const r of results) {
    found.push({ kind: 'task_result', key: `result:${r.id}`, urgent: false,
      text: `${r.assignee} سلّم مهمة «${r.title}». النتيجة: ${r.result_text}. إذا تمام گولي سكّرها، أو رجّعها ويا السبب.` });
  }

  const messages = await db.query<{ id: string; sender: string; body: string; task_title: string | null }>(
    `SELECT m.id, u.full_name AS sender, m.body, t.title AS task_title FROM messages m
     JOIN users u ON u.id = m.sender_id LEFT JOIN tasks t ON t.id = m.task_id
     WHERE m.recipient_id IS NULL AND m.read_at IS NULL`);
  for (const m of messages) {
    found.push({ kind: 'message', key: `message:${m.id}`, urgent: false, messageId: m.id,
      text: `رسالة من ${m.sender}${m.task_title ? ` بخصوص «${m.task_title}»` : ''}: ${m.body}` });
  }

  const soon = await db.query<{ id: string; title: string; kind: string; starts_at: Date; location: string | null; person: string | null;
    organization: string | null; person_notes: string | null; notes: string | null }>(
    `SELECT a.id, a.title, a.kind, a.starts_at, a.location, a.notes, p.full_name AS person, p.organization, p.notes AS person_notes
     FROM appointments a LEFT JOIN persons p ON p.id = a.person_id
     WHERE a.cancelled_at IS NULL AND a.starts_at > now() AND a.starts_at <= now() + make_interval(mins => $1)`, [appointmentMinutes]);
  for (const a of soon) {
    const minutes = Math.max(1, Math.round((new Date(a.starts_at).getTime() - Date.now()) / 60_000));
    const parts = [`بعد ${minutes} دقيقة عندك ${a.kind === 'interview' ? 'مقابلة' : 'موعد'}: ${a.title}${a.location ? `، بـ${a.location}` : ''}.`];
    if (a.person) parts.push(`الضيف ${a.person}${a.organization ? ` من ${a.organization}` : ''}${a.person_notes ? `: ${a.person_notes}` : '.'}`);
    if (a.notes) parts.push(`ملاحظة: ${a.notes}`);
    found.push({ kind: 'appointment_soon', key: `appointment:${a.id}:${new Date(a.starts_at).toISOString()}`, urgent: true, text: parts.join(' ') });
  }

  const letters = await db.query<{ id: string; subject: string; party: string | null; ref_number: string | null; summary: string | null }>(
    `SELECT id, subject, party, ref_number, summary FROM letters
     WHERE direction = 'incoming' AND task_id IS NULL AND created_at > now() - interval '1 day'`);
  for (const l of letters) {
    found.push({ kind: 'letter', key: `letter:${l.id}`, urgent: false,
      text: [`وصل كتاب${l.party ? ` من ${l.party}` : ''}${l.ref_number ? ` بالعدد ${l.ref_number}` : ''}، موضوعه ${l.subject}.`,
        l.summary && `ملخصه: ${l.summary}`, 'حضرتك تگدر تهمّشه لأي واحد، مثلاً: همّشه لسامي للدراسة.'].filter(Boolean).join(' ') });
  }

  // A meeting's minutes, sent out: the decisions and who got what.
  const minutes = await db.query<{ id: string; title: string; decisions: string[]; tasks: Array<{ title: string; who: string }> | null }>(
    `SELECT m.id, m.title, m.decisions,
            (SELECT json_agg(json_build_object('title', t.title, 'who', u.full_name) ORDER BY t.created_at)
             FROM tasks t JOIN users u ON u.id = t.assignee_id WHERE t.meeting_id = m.id) AS tasks
     FROM meetings m WHERE m.status = 'published' AND m.published_at > now() - interval '1 day'`);
  for (const m of minutes) {
    const tasks = m.tasks ?? [];
    found.push({ kind: 'minutes', key: `minutes:${m.id}`, urgent: false,
      text: [`محضر «${m.title}» انوزّع.`, m.decisions.length ? `القرارات: ${m.decisions.join('؛ ')}.` : '',
        tasks.length ? `المهام: ${tasks.slice(0, 4).map((t) => `${t.who} «${t.title}»`).join('، ')}${tasks.length > 4 ? ` و${tasks.length - 4} غيرها` : ''}.` : ''].filter(Boolean).join(' ') });
  }

  const reports = await db.query<{ id: string; slot: string; content: ReportContent }>(
    // Only the latest: after a restart the morning and evening reports can both be made at once, and only one is news.
    `SELECT id, slot, content FROM daily_reports WHERE generated_at > now() - interval '12 hours'
     ORDER BY report_date DESC, slot DESC LIMIT 1`);
  for (const r of reports) found.push({ kind: 'report', key: `report:${r.id}`, urgent: false, text: reportText(r.slot, r.content, zone) });
  return found;
}

interface ReportContent {
  overdue: Array<{ title: string; assignee: string }>;
  due_soon: Array<{ title: string; assignee: string; due_at: string }>;
  not_opened: Array<{ title: string; assignee: string }>;
  completed: Array<{ title: string; assignee: string }>;
}

/** «مهمة وحدة»، «مهمتين»، «3 مهام»: a number as it is said. */
export function tasksCount(n: number): string {
  return n === 1 ? 'مهمة وحدة' : n === 2 ? 'مهمتين' : `${n} مهام`;
}

/** A report as a few spoken sentences: counts first, then the one or two things worth her attention. */
export function reportText(slot: string, c: ReportContent, zone: string): string {
  const lines = [`${slot === 'morning' ? 'صباح الخير، هذا تقرير الصبح' : 'هذا تقرير المسا'}.`];
  if (!c.overdue.length && !c.not_opened.length && !c.due_soon.length && !c.completed.length) {
    lines.push('ماكو شي متأخر ولا شي ينتظر.');
    return lines.join(' ');
  }
  if (c.completed.length) lines.push(`خلصت ${tasksCount(c.completed.length)} من آخر تقرير.`);
  if (c.overdue.length) {
    const first = c.overdue.slice(0, 2).map((t) => `«${t.title}» عند ${t.assignee}`).join(' و');
    lines.push(`متأخرة ${c.overdue.length}: ${first}${c.overdue.length > 2 ? ' وغيرها' : ''}.`);
  }
  if (c.not_opened.length) lines.push(`${tasksCount(c.not_opened.length)} ما انفتحت بعد.`);
  if (c.due_soon.length) {
    const next = c.due_soon[0]!;
    lines.push(`قريبة الانتهاء ${c.due_soon.length}، أقربها «${next.title}» عند ${next.assignee} ${readable(next.due_at, zone)}.`);
  }
  return lines.join(' ');
}

/** Writes what is new since the last pass; returns how many. */
export async function collectAnnouncements(db: Db): Promise<number> {
  let added = 0;
  for (const c of await candidates(db)) {
    const rows = await db.query(
      `INSERT INTO announcements (kind, subject_key, text, urgent, message_id) VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (subject_key) DO NOTHING RETURNING id`, [c.kind, c.key, c.text, c.urgent, c.messageId ?? null]);
    added += rows.length;
  }
  return added;
}

/** Marks announcements said; a message said aloud counts as read, so the AI does not read it twice. */
export async function markSpoken(db: Db, ids: string[]): Promise<number> {
  if (!ids.length) return 0;
  const said = await db.query<{ message_id: string | null }>(
    'UPDATE announcements SET spoken_at = now() WHERE id = ANY($1::uuid[]) AND spoken_at IS NULL RETURNING message_id', [ids]);
  await markRead(db, said.map((r) => r.message_id).filter((id): id is string => Boolean(id)));
  return said.length;
}

/** What is still to be said, urgent first. A message she already heard by asking is not said again; half a day later
 * it is no longer news. */
export function pendingAnnouncements(db: Db) {
  return db.query<{ id: string; kind: string; text: string; urgent: boolean; created_at: Date }>(
    `SELECT a.id, a.kind, a.text, a.urgent, a.created_at FROM announcements a LEFT JOIN messages m ON m.id = a.message_id
     WHERE a.spoken_at IS NULL AND m.read_at IS NULL AND a.created_at > now() - interval '12 hours' ORDER BY a.urgent DESC, a.created_at LIMIT 20`);
}

/** Today at a glance for the principal: appointments, the state of the work, who is on what, unread messages. */
export async function today(db: Db) {
  const zone = await timeZone(db);
  const [appointments, state, unread, recent] = await Promise.all([
    db.query(`SELECT a.id, a.title, a.kind, a.starts_at, a.location, p.full_name AS person
              FROM appointments a LEFT JOIN persons p ON p.id = a.person_id
              WHERE a.cancelled_at IS NULL AND a.starts_at > now() - interval '1 hour' AND a.starts_at < now() + interval '2 days'
              ORDER BY a.starts_at LIMIT 20`),
    overview(db),
    db.query(`SELECT m.id, u.full_name AS sender, m.body, m.created_at FROM messages m JOIN users u ON u.id = m.sender_id
              WHERE m.recipient_id IS NULL AND m.read_at IS NULL ORDER BY m.created_at`),
    db.query(`SELECT id, kind, text, urgent, created_at, spoken_at FROM announcements ORDER BY created_at DESC LIMIT 15`),
  ]);
  const working = await db.query(
    `SELECT title, assignee_name AS assignee, started_at FROM office_tasks WHERE status = 'in_progress' ORDER BY started_at DESC LIMIT 20`);
  return { now: readable(new Date(), zone), appointments, ...state, working, unread_messages: unread, recent_announcements: recent };
}
