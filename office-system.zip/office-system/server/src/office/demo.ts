import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { seedUsers } from '../db/seed.js';
import type { Db } from '../db/index.js';
import { imageType } from './attachments.js';
import type { OfficeContext } from './context.js';
import type { Actor } from './events.js';
import { marginLetter } from './letters.js';
import { sendMessage } from './messages.js';
import { createTask, reviewTask } from './tasks.js';

/**
 * A working office on a new machine with nothing to type: the people from seed/users.json and a day of
 * tasks, messages, letters and appointments, dated from now so nothing looks stale. Only into an office with no
 * people yet (OFFICE_DEMO=true, on the first start). For trying and showing the system, never for a real office:
 * everyone shares one known password.
 */

export const DEMO_PASSWORD = 'office-dev-1';
const AI: Actor = { type: 'ai' };
const HOUR = 3_600_000;

const at = (hoursFromNow: number) => new Date(Date.now() + hoursFromNow * HOUR);
/** Tomorrow (or a later day) at a time of day, in Baghdad. */
function dayAt(days: number, hour: number): Date {
  const d = new Date(Date.now() + days * 24 * HOUR);
  const baghdad = new Date(d.getTime() + 3 * HOUR);
  return new Date(Date.UTC(baghdad.getUTCFullYear(), baghdad.getUTCMonth(), baghdad.getUTCDate(), hour - 3, 0));
}

export async function seedDemo(office: OfficeContext, root: string, password = DEMO_PASSWORD): Promise<boolean> {
  const { db } = office;
  const [{ n }] = (await db.query<{ n: number }>('SELECT count(*)::int AS n FROM users')) as [{ n: number }];
  if (n > 0) return false;
  await seedUsers(db, join(root, 'seed', 'users.json'), password);
  const id = async (username: string) => (await db.query<{ id: string }>('SELECT id FROM users WHERE username = $1', [username]))[0]!.id;
  const [sami, mustafa, ali, zainab, boss] = await Promise.all(['sami', 'mustafa', 'ali', 'zainab', 'boss'].map(id));
  const page = await readFile(join(root, 'seed', 'letter-sample.png'));

  await office.tx(async (tx, after) => {
    const task = (actor: Actor, assigneeId: string, title: string, due: Date, extra: { priority?: 'normal' | 'high'; utterance?: string; description?: string } = {}) =>
      createTask(tx, office.push, after, actor, {
        title, description: extra.description ?? '', assigneeId, priority: extra.priority ?? 'normal', due,
        source: actor.type === 'ai' ? 'voice_ai' : 'app', ...(extra.utterance ? { utterance: extra.utterance } : {}),
      });

    // The principal's own orders, by voice.
    const booking = await task(AI, sami!, 'حجز موعد مع مدير الكهرباء', dayAt(1, 18),
      { priority: 'high', utterance: 'خلي مدير المكتب يحجزلي موعد ويا مدير الكهرباء باچر الساعة 6' });
    await opened(tx, booking.id);
    const reminder = await task(AI, sami!, 'تذكير بالباقلاء بالدهن الحر الساعة 6 عصراً', dayAt(1, 18),
      { utterance: 'خلي مدير المكتب يسويلي تذكير باچر الساعة 6 عصراً ان اسوي باقلاء بالدهن الحر' });
    await handedIn(tx, reminder.id, sami!, 'سجّلت التذكير على تلفوني وراح أذكّر حضرتك الساعة 5:45');
    const invites = await task(AI, zainab!, 'إرسال دعوات الاجتماع العام', at(-2),
      { priority: 'high', utterance: 'خلي السكرتيرة ترسل دعوات الاجتماع العام اليوم الصبح' });
    await opened(tx, invites.id); // late now: the AI tells the principal by itself
    const minutes = await task(AI, mustafa!, 'كتابة محضر اجتماع الأحد', dayAt(2, 14),
      { utterance: 'خلي مسؤول المحاضر يكتب محضر اجتماع الأحد' });
    await opened(tx, minutes.id, true);

    // The office's own work.
    await task({ type: 'user', userId: ali! }, zainab!, 'تجهيز قاعة الاجتماعات قبل الساعة 9', dayAt(1, 9),
      { description: 'الكراسي والماء وجهاز العرض' }); // still sealed: she has not opened it
    const schedule = await task({ type: 'user', userId: sami! }, zainab!, 'طباعة جدول الأسبوع', at(20));
    await handedIn(tx, schedule.id, zainab!, 'انطبع ومحطوط على مكتب الاستعلامات');
    await reviewTask(tx, office.push, after, { type: 'user', userId: ali! }, ali!, schedule.id, 'accepted', null, 'علي كريم');
    const guests = await task({ type: 'user', userId: ali! }, mustafa!, 'تحديث سجل الضيوف', at(30));
    await handedIn(tx, guests.id, mustafa!, 'حدّثته');
    await reviewTask(tx, office.push, after, { type: 'user', userId: ali! }, ali!, guests.id, 'returned', 'ناقص أرقام هواتف ضيوف الأسبوع الماضي', 'علي كريم');

    // Messages both ways, and one about a task.
    await sendMessage(tx, office.push, after, { fromUserId: zainab!, body: 'القاعة الكبيرة بيها عطل بالتكييف، نحتاج نبدّل مكان الاجتماع' });
    await sendMessage(tx, office.push, after, { fromUserId: sami!, body: 'مدير الكهرباء رد، ينتظر تأكيد حضرتك على الوقت', taskId: booking.id });
    for (const to of [sami!, mustafa!, ali!, zainab!]) {
      await sendMessage(tx, office.push, after, { fromAi: true, toUserId: to, body: 'اكو اجتماع عام باچر الساعة 9 بقاعة الاجتماعات' });
    }

    // Letters: one in with its page and the principal's margin, one waiting for a margin, one out.
    const [received] = await tx.query<{ id: string }>(
      `INSERT INTO letters (direction, ref_number, letter_date, party, subject, summary, registered_by)
       VALUES ('incoming', 'ت/4521', current_date - 2, 'المديرية العامة لتوزيع كهرباء بغداد', 'تجهيز محولة كهربائية لحي الجامعة',
               'المديرية مستعدة تجهّز محولة 400 ك.ف.أ لحي الجامعة إذا تخصّص قطعة أرض وتنطيهم الموافقة خلال 15 يوم.', $1) RETURNING id`, [sami!]);
    await tx.query(
      `INSERT INTO attachments (letter_id, purpose, file_name, content_type, size_bytes, data, uploaded_by) VALUES ($1, 'letter', 'letter.png', $2, $3, $4, $5)`,
      [received!.id, imageType(page) ?? 'image/png', page.length, page, sami!]);
    await marginLetter(tx, office.push, after, AI, received!.id,
      { assigneeId: sami!, margin: 'للدراسة وإعلامي خلال يومين', due: at(48), priority: 'normal', utterance: 'همّش كتاب الكهرباء لسامي للدراسة واعلامي خلال يومين' });
    await tx.query(
      `INSERT INTO letters (direction, ref_number, letter_date, party, subject, summary, registered_by)
       VALUES ('incoming', '77', current_date, 'بلدية الكرخ', 'طلب تخصيص قطعة أرض لمحولة', 'البلدية تطلب رأي المكتب بتخصيص قطعة الأرض المقابلة للمدرسة.', $1)`, [sami!]);
    await tx.query(
      `INSERT INTO letters (direction, ref_number, letter_date, party, subject, registered_by)
       VALUES ('outgoing', 'ص/310', current_date - 1, 'وزارة الكهرباء', 'رد على كتاب تجهيز المحولة', $1)`, [sami!]);

    // Appointments with guest files, one guest seen before.
    const [director] = await tx.query<{ id: string }>(
      `INSERT INTO persons (full_name, organization, notes) VALUES ('مدير الكهرباء', 'دائرة كهرباء بغداد', 'يتابع محولة حي الجامعة') RETURNING id`);
    const [abuAli] = await tx.query<{ id: string }>(
      `INSERT INTO persons (full_name, organization, notes) VALUES ('أبو علي', 'شركة النور', 'يتابع عقد صيانة المولدات') RETURNING id`);
    const appointment = (title: string, kind: string, startsAt: Date, person: string, notes: string | null) => tx.query(
      `INSERT INTO appointments (title, kind, starts_at, person_id, notes, created_by) VALUES ($1, $2, $3, $4, $5, $6)`,
      [title, kind, startsAt, person, notes, boss!]);
    await appointment('لقاء مدير الكهرباء', 'appointment', dayAt(1, 10), director!.id, 'بخصوص المحولة');
    await appointment('زيارة أبو علي الأولى', 'appointment', dayAt(-7, 11), abuAli!.id, null);
    await appointment('مقابلة أبو علي', 'interview', dayAt(2, 12), abuAli!.id, 'جاي يجدد العقد');
  });
  return true;
}

/** As if the assignee opened it (and started it): its alerts stop, like the app does. */
async function opened(db: Db, taskId: string, started = false): Promise<void> {
  await db.query(
    `UPDATE tasks SET status = $2, delivered_at = now() - interval '1 hour', opened_at = now() - interval '50 minutes',
            started_at = CASE WHEN $3 THEN now() - interval '40 minutes' END, updated_at = now() WHERE id = $1`,
    [taskId, started ? 'in_progress' : 'opened', started]);
  await db.query(`UPDATE notifications SET delivered_at = now() - interval '1 hour', opened_at = now() - interval '50 minutes', next_alert_at = NULL WHERE task_id = $1`, [taskId]);
}

async function handedIn(db: Db, taskId: string, by: string, result: string): Promise<void> {
  await opened(db, taskId, true);
  await db.query(`INSERT INTO task_submissions (task_id, attempt_no, result_text, submitted_by) VALUES ($1, 1, $2, $3)`, [taskId, result, by]);
  await db.query(`UPDATE tasks SET status = 'submitted', updated_at = now() WHERE id = $1`, [taskId]);
}
