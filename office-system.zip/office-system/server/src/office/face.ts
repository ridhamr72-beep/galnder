// Face sign-in. A person shows their face to the app's camera once or a few times (enrol); after that the app can sign
// them in from a photo. The face model lives in the AI system with its other models (FACE_URL): it turns a photo into a
// print (128 numbers) and nothing more. The prints, the matching and the sign-in are here; the photos are kept nowhere.
//
// A match needs the best person to be close (cosine >= MATCH) and clearly closer than anyone else (MARGIN), so two
// look-alikes never sign each other in. It is a convenience, not a lock: a printed photo of someone could pass, so the
// password stays, and an admin can wipe anyone's prints.
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import type { Db } from '../db/index.js';
import { AppError } from '../utils/errors.js';
import { parseBody } from '../utils/http.js';
import { Device, signIn } from './admin.js';
import { requirePermission } from './auth.js';
import type { OfficeContext } from './context.js';
import { recordEvent, SYSTEM } from './events.js';

/** SFace's own threshold is 0.363; a little higher, since a wrong match signs in the wrong person. */
export const MATCH = 0.45;
export const MARGIN = 0.08;
const MAX_PRINTS = 5;
/** Failed face sign-ins (anyone) in the last FAIL_MINUTES before it pauses, so photos cannot be tried one after another. */
const MAX_FAILS = 20;
const FAIL_MINUTES = 5;

const Photo = z.object({ image: z.string().min(100).max(11_000_000) });
const FaceLogin = Photo.extend({ device: Device });

/**
 * The AI system's face model. Contract: POST <FACE_URL>/embed, body = the photo's bytes (application/octet-stream),
 * answer = { faces: number, embedding?: number[128], error?: 'NOT_AN_IMAGE' | 'FACE_TOO_SMALL' }.
 */
export interface FaceClient {
  embed(photo: Buffer): Promise<{ faces: number; embedding?: number[]; error?: string }>;
}

export function faceClient(url: string): FaceClient {
  return {
    async embed(photo) {
      let res: Response;
      try {
        res = await fetch(`${url}/embed`, { method: 'POST', body: new Uint8Array(photo), headers: { 'content-type': 'application/octet-stream' }, signal: AbortSignal.timeout(15_000) });
      } catch {
        throw new AppError(503, 'FACE_SERVICE_DOWN', 'خدمة الوجه مو شغالة هسه، ادخل بكلمة المرور');
      }
      if (!res.ok) throw new AppError(503, 'FACE_SERVICE_DOWN', 'خدمة الوجه مو شغالة هسه، ادخل بكلمة المرور');
      return (await res.json()) as { faces: number; embedding?: number[]; error?: string };
    },
  };
}

const cosine = (a: number[], b: number[]) => a.reduce((sum, v, i) => sum + v * b[i]!, 0);

/** The one face in the photo, as a print; a clear message for no face, several, or too far. */
async function printOf(face: FaceClient, image: string): Promise<number[]> {
  const photo = Buffer.from(image.replace(/^data:image\/\w+;base64,/, ''), 'base64');
  const out = await face.embed(photo);
  if (out.error === 'NOT_AN_IMAGE') throw new AppError(400, 'NOT_AN_IMAGE', 'الصورة ما انقرت');
  if (out.faces === 0) throw new AppError(422, 'NO_FACE', 'ما بيّن وجه، قرّب من الكاميرا وخلي الضوء على وجهك');
  if (out.faces > 1) throw new AppError(422, 'MANY_FACES', 'أكثر من وجه بالصورة، خلي وجهك بس');
  if (out.error === 'FACE_TOO_SMALL' || !out.embedding) throw new AppError(422, 'FACE_TOO_SMALL', 'الوجه بعيد، قرّب من الكاميرا');
  return out.embedding;
}

/** Each person's best match with the print, best first. */
export async function closest(db: Db, print: number[]): Promise<Array<{ user_id: string; score: number }>> {
  const rows = await db.query<{ user_id: string; embedding: number[] }>(
    `SELECT f.user_id, f.embedding FROM face_prints f JOIN users u ON u.id = f.user_id WHERE u.is_active`);
  const best = new Map<string, number>();
  for (const r of rows) best.set(r.user_id, Math.max(best.get(r.user_id) ?? -1, cosine(print, r.embedding.map(Number))));
  return [...best].map(([user_id, score]) => ({ user_id, score })).sort((a, b) => b.score - a.score);
}

export function faceRoutes(app: FastifyInstance, office: OfficeContext, face: FaceClient): void {
  const { db } = office;

  /** GET /api/v1/me/face — how many prints I have (0 = face sign-in is off for me). */
  app.get('/api/v1/me/face', async (request) => {
    const user = await office.user(request);
    const [row] = await db.query<{ n: number }>('SELECT count(*)::int AS n FROM face_prints WHERE user_id = $1', [user.id]);
    return { prints: row!.n, max: MAX_PRINTS };
  });

  /** POST /api/v1/me/face — adds a print of my face (the oldest goes past five). Refused if it looks like someone else. */
  app.post('/api/v1/me/face', async (request, reply) => {
    const user = await office.user(request);
    const body = parseBody(Photo, request.body);
    const print = await printOf(face, body.image);
    const [other] = (await closest(db, print)).filter((m) => m.user_id !== user.id);
    if (other && other.score >= MATCH) throw new AppError(409, 'FACE_LIKE_OTHER', 'هذا الوجه يشبه وجه مسجّل لشخص ثاني، ما انحفظ');
    await db.tx(async (tx) => {
      await tx.query('INSERT INTO face_prints (user_id, embedding) VALUES ($1, $2)', [user.id, print]);
      await tx.query(
        `DELETE FROM face_prints WHERE user_id = $1 AND id NOT IN (SELECT id FROM face_prints WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2)`,
        [user.id, MAX_PRINTS]);
      await recordEvent(tx, { type: 'user', userId: user.id }, 'auth.face_enrolled', { type: 'user', id: user.id }, 'سجّل وجهه للدخول');
    });
    const [row] = await db.query<{ n: number }>('SELECT count(*)::int AS n FROM face_prints WHERE user_id = $1', [user.id]);
    return reply.code(201).send({ prints: row!.n, max: MAX_PRINTS });
  });

  /** DELETE /api/v1/me/face — face sign-in off for me. */
  app.delete('/api/v1/me/face', async (request, reply) => {
    const user = await office.user(request);
    await db.query('DELETE FROM face_prints WHERE user_id = $1', [user.id]);
    return reply.code(204).send();
  });

  /** DELETE /api/v1/users/:id/face — an admin wipes someone's face prints (a lost phone, a wrong enrolment). */
  app.delete<{ Params: { id: string } }>('/api/v1/users/:id/face', async (request, reply) => {
    const user = await office.user(request);
    requirePermission(user, 'users.manage');
    await db.query('DELETE FROM face_prints WHERE user_id = $1', [request.params.id]);
    await recordEvent(db, { type: 'user', userId: user.id }, 'auth.face_wiped', { type: 'user', id: request.params.id }, 'مسح بصمة الوجه');
    return reply.code(204).send();
  });

  /** POST /api/v1/auth/face — sign in from a photo of the face; the same tokens as the password sign-in. */
  app.post('/api/v1/auth/face', async (request) => {
    const body = parseBody(FaceLogin, request.body);
    const [fails] = await db.query<{ n: number }>(
      `SELECT count(*)::int AS n FROM events WHERE event_type = 'auth.face_failed' AND occurred_at > now() - make_interval(mins => $1)`, [FAIL_MINUTES]);
    if (fails!.n >= MAX_FAILS) throw new AppError(429, 'FACE_PAUSED', 'محاولات وجه كثيرة، ادخل بكلمة المرور أو جرّب بعد دقائق');
    const print = await printOf(face, body.image);
    const [best, second] = await closest(db, print);
    if (!best || best.score < MATCH || (second && best.score - second.score < MARGIN)) {
      // A failed try names nobody (no one was recognised); its subject is the device, or a zero id for a new one.
      await recordEvent(db, SYSTEM, 'auth.face_failed', { type: 'device', id: body.device.id ?? '00000000-0000-0000-0000-000000000000' }, 'دخول بالوجه ما انعرف');
      throw new AppError(401, 'FACE_NOT_KNOWN', 'ما عرفت الوجه، جرّب مرة ثانية أو ادخل بكلمة المرور');
    }
    return signIn(db, office.secret, best.user_id, body.device, 'دخول بالوجه');
  });
}
