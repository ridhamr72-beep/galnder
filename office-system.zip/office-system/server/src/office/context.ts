import type { FastifyRequest } from 'fastify';
import type { Db } from '../db/index.js';
import { currentUser, type OfficeUser } from './auth.js';
import type { PushHub } from './push.js';

/** Work to do once the transaction is committed: pushing to a phone before the row exists would show a ghost. */
export type After = (fn: () => void) => void;

export interface OfficeContext {
  db: Db;
  secret: string;
  push: PushHub;
  user(request: FastifyRequest): Promise<OfficeUser>;
  /** A transaction whose `after` callbacks run only when it commits. */
  tx<T>(fn: (db: Db, after: After) => Promise<T>): Promise<T>;
}

export function officeContext(db: Db, secret: string, push: PushHub): OfficeContext {
  return {
    db,
    secret,
    push,
    user: (request) => currentUser(db, secret, request),
    async tx(fn) {
      const pending: Array<() => void> = [];
      const result = await db.tx((tx) => fn(tx, (cb) => pending.push(cb)));
      for (const cb of pending) cb();
      return result;
    },
  };
}
