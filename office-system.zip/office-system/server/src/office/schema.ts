/**
 * The office system's tables.
 * Ported from the first design's schema.sql without pgvector (hard to install on Windows; nothing here searches by vector)
 * and without database roles (the server is the only client). Times are timestamptz, stored UTC.
 */
export const OFFICE_SCHEMA = `
CREATE TYPE task_priority     AS ENUM ('normal', 'high');
CREATE TYPE task_status       AS ENUM ('assigned', 'opened', 'in_progress', 'submitted', 'returned', 'closed', 'cancelled');
CREATE TYPE task_source       AS ENUM ('voice_ai', 'meeting', 'app');
CREATE TYPE review_decision   AS ENUM ('accepted', 'returned');
CREATE TYPE meeting_status    AS ENUM ('draft', 'published');
CREATE TYPE appointment_kind  AS ENUM ('appointment', 'interview');
CREATE TYPE actor_type        AS ENUM ('user', 'ai', 'system');
CREATE TYPE device_platform   AS ENUM ('android', 'windows');
CREATE TYPE notification_kind AS ENUM ('task_assigned', 'task_reminder', 'task_returned', 'task_reassigned', 'review_needed');
CREATE TYPE report_slot       AS ENUM ('morning', 'evening');
CREATE TYPE visibility        AS ENUM ('principal', 'general');

CREATE TABLE roles (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code       text NOT NULL UNIQUE,
  name_ar    text NOT NULL,
  is_system  boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE permissions (
  code        text PRIMARY KEY,
  description text NOT NULL
);

CREATE TABLE role_permissions (
  role_id         uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_code text NOT NULL REFERENCES permissions(code) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_code)
);

CREATE TABLE users (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username      text NOT NULL UNIQUE,
  full_name     text NOT NULL,
  job_title     text,
  aliases       text[] NOT NULL DEFAULT '{}',
  role_id       uuid NOT NULL REFERENCES roles(id),
  password_hash text,
  is_principal  boolean NOT NULL DEFAULT false,
  is_active     boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX one_principal ON users (is_principal) WHERE is_principal;

CREATE TABLE devices (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  platform        device_platform NOT NULL,
  name            text NOT NULL,
  app_version     text,
  push_token_hash text,
  last_seen_at    timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now(),
  revoked_at      timestamptz
);

CREATE TABLE refresh_tokens (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_id  uuid NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  revoked_at timestamptz
);

CREATE TABLE persons (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name    text NOT NULL,
  aliases      text[] NOT NULL DEFAULT '{}',
  organization text,
  phone        text,
  notes        text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE meetings (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title        text NOT NULL,
  held_at      timestamptz NOT NULL,
  location     text,
  body         text NOT NULL DEFAULT '',
  status       meeting_status NOT NULL DEFAULT 'draft',
  created_by   uuid NOT NULL REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  published_at timestamptz
);

CREATE TABLE tasks (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title              text NOT NULL,
  description        text NOT NULL DEFAULT '',
  priority           task_priority NOT NULL DEFAULT 'normal',
  status             task_status NOT NULL DEFAULT 'assigned',
  source             task_source NOT NULL,
  original_utterance text,
  meeting_id         uuid REFERENCES meetings(id),
  assignee_id        uuid NOT NULL REFERENCES users(id),
  created_by_user    uuid REFERENCES users(id),
  created_by_ai      boolean NOT NULL DEFAULT false,
  original_due_at    timestamptz NOT NULL,
  due_at             timestamptz NOT NULL,
  created_at         timestamptz NOT NULL DEFAULT now(),
  delivered_at       timestamptz,
  opened_at          timestamptz,
  started_at         timestamptz,
  closed_at          timestamptz,
  closed_by          uuid REFERENCES users(id),
  cancelled_at       timestamptz,
  cancel_reason      text,
  updated_at         timestamptz NOT NULL DEFAULT now(),
  CHECK ((created_by_user IS NOT NULL) <> created_by_ai),
  CHECK (source <> 'meeting' OR meeting_id IS NOT NULL),
  CHECK (source <> 'voice_ai' OR original_utterance IS NOT NULL)
);
CREATE INDEX tasks_assignee_open ON tasks (assignee_id, due_at) WHERE status NOT IN ('closed', 'cancelled');

CREATE TABLE task_submissions (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id      uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  attempt_no   integer NOT NULL,
  result_text  text NOT NULL,
  submitted_by uuid NOT NULL REFERENCES users(id),
  submitted_at timestamptz NOT NULL DEFAULT now(),
  reviewed_by  uuid REFERENCES users(id),
  reviewed_at  timestamptz,
  decision     review_decision,
  review_note  text,
  UNIQUE (task_id, attempt_no),
  CHECK (decision <> 'returned' OR review_note IS NOT NULL)
);
CREATE UNIQUE INDEX one_accepted_submission ON task_submissions (task_id) WHERE decision = 'accepted';

-- Images attached to a task by its sender ('task') or to the result by the assignee ('result'). Kept in the
-- database: one database, one backup.
CREATE TABLE attachments (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id       uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  purpose       text NOT NULL CHECK (purpose IN ('task', 'result')),
  file_name     text NOT NULL,
  content_type  text NOT NULL,
  size_bytes    integer NOT NULL,
  data          bytea NOT NULL,
  uploaded_by   uuid NOT NULL REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX attachments_task ON attachments (task_id);

CREATE TABLE appointments (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title        text NOT NULL,
  kind         appointment_kind NOT NULL DEFAULT 'appointment',
  starts_at    timestamptz NOT NULL,
  ends_at      timestamptz,
  location     text,
  notes        text,
  person_id    uuid REFERENCES persons(id),
  created_by   uuid NOT NULL REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now(),
  cancelled_at timestamptz
);

CREATE TABLE notifications (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seq           bigint GENERATED ALWAYS AS IDENTITY UNIQUE,
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind          notification_kind NOT NULL,
  level         task_priority NOT NULL,
  task_id       uuid REFERENCES tasks(id) ON DELETE CASCADE,
  created_at    timestamptz NOT NULL DEFAULT now(),
  delivered_at  timestamptz,
  opened_at     timestamptz,
  dismissed_at  timestamptz,
  alert_count   integer NOT NULL DEFAULT 1,
  next_alert_at timestamptz
);
CREATE INDEX notifications_user_seq ON notifications (user_id, seq);

CREATE TABLE notification_deliveries_sent (
  notification_id uuid NOT NULL REFERENCES notifications(id) ON DELETE CASCADE,
  device_id       uuid NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
  sent_at         timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (notification_id, device_id)
);

-- What happened, in order. Add only: the AI answers "what happened on day X" from it.
CREATE TABLE events (
  id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  occurred_at   timestamptz NOT NULL DEFAULT now(),
  event_type    text NOT NULL,
  actor_type    actor_type NOT NULL,
  actor_user_id uuid REFERENCES users(id),
  subject_type  text NOT NULL,
  subject_id    uuid NOT NULL,
  summary       text NOT NULL,
  payload       jsonb NOT NULL DEFAULT '{}',
  visibility    visibility NOT NULL DEFAULT 'general'
);
CREATE INDEX events_subject ON events (subject_type, subject_id, id);
CREATE FUNCTION events_append_only() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'events is append-only'; END $$;
CREATE TRIGGER events_no_change BEFORE UPDATE OR DELETE ON events FOR EACH ROW EXECUTE FUNCTION events_append_only();

CREATE TABLE daily_reports (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_date  date NOT NULL,
  slot         report_slot NOT NULL,
  generated_at timestamptz NOT NULL DEFAULT now(),
  content      jsonb NOT NULL,
  UNIQUE (report_date, slot)
);

CREATE TABLE jobs (
  id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  kind       text NOT NULL,
  payload    jsonb NOT NULL DEFAULT '{}',
  dedupe_key text UNIQUE,
  run_at     timestamptz NOT NULL,
  done_at    timestamptz
);

CREATE TABLE settings (
  key        text PRIMARY KEY,
  value      jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Every duration in seconds; receipt delay starts when the device got it, so a phone off the network is not the employee's fault.
CREATE VIEW office_tasks AS
  SELECT t.id, t.title, t.description, t.priority, t.status, t.source, t.original_utterance, t.meeting_id,
         t.assignee_id, u.full_name AS assignee_name, t.created_by_user, t.created_at, t.original_due_at, t.due_at,
         t.delivered_at, t.opened_at, t.started_at, s.submitted_at AS completed_at, t.closed_at, s.result_text,
         s.attempt_no AS attempts,
         EXTRACT(EPOCH FROM t.delivered_at - t.created_at)::bigint AS delivery_delay_s,
         EXTRACT(EPOCH FROM t.opened_at - t.delivered_at)::bigint  AS receipt_delay_s,
         EXTRACT(EPOCH FROM s.submitted_at - t.opened_at)::bigint  AS execution_s,
         (s.submitted_at <= t.due_at) AS completed_on_time,
         (t.status NOT IN ('closed', 'cancelled') AND t.due_at < now()) AS is_overdue,
         CASE WHEN s.submitted_at > t.due_at THEN EXTRACT(EPOCH FROM s.submitted_at - t.due_at)::bigint
              WHEN s.submitted_at IS NULL AND t.status <> 'cancelled' AND t.due_at < now()
                   THEN EXTRACT(EPOCH FROM now() - t.due_at)::bigint END AS overdue_s,
         (t.delivered_at IS NULL AND t.status = 'assigned') AS device_not_reached
  FROM tasks t
  JOIN users u ON u.id = t.assignee_id
  LEFT JOIN task_submissions s ON s.task_id = t.id AND s.decision = 'accepted';

INSERT INTO permissions (code, description) VALUES
  ('directory.read',     'يرى قائمة الموظفين حتى يرسل لهم مهام'),
  ('tasks.read_own',     'يرى مهامه هو'),
  ('tasks.read_all',     'يرى كل المهام بدون نص المحضر'),
  ('tasks.create',       'ينشئ مهمة'),
  ('tasks.reassign',     'يحوّل مهمة لشخص آخر أو يمدّد موعدها'),
  ('tasks.cancel',       'يلغي مهمة'),
  ('tasks.review',       'يراجع التسليم ويغلق المهمة أو يرجّعها'),
  ('meetings.write',     'يكتب محضراً ويوزّعه مهاماً'),
  ('appointments.write', 'يدير المواعيد'),
  ('persons.write',      'يدير الأشخاص خارج النظام'),
  ('performance.read',   'يرى إحصاءات الالتزام'),
  ('users.manage',       'يدير المستخدمين والأجهزة'),
  ('roles.manage',       'يعدّل الأدوار وصلاحياتها'),
  ('settings.manage',    'يعدّل إعدادات النظام');

INSERT INTO roles (code, name_ar, is_system) VALUES
  ('principal', 'الشخصية الأساسية', true), ('admin', 'مدير النظام', true),
  ('office_manager', 'مدير المكتب', true), ('minutes_officer', 'مسؤول المحاضر', true),
  ('follow_up', 'مسؤول المتابعة', true), ('secretary', 'السكرتير', true), ('employee', 'موظف', true);

INSERT INTO role_permissions (role_id, permission_code)
SELECT r.id, p.code FROM roles r JOIN (VALUES
  ('admin', 'users.manage'), ('admin', 'roles.manage'), ('admin', 'settings.manage'), ('admin', 'tasks.read_own'),
  ('office_manager', 'tasks.read_own'), ('office_manager', 'tasks.create'), ('office_manager', 'appointments.write'),
  ('office_manager', 'persons.write'), ('office_manager', 'directory.read'),
  ('minutes_officer', 'tasks.read_own'), ('minutes_officer', 'tasks.create'), ('minutes_officer', 'meetings.write'),
  ('minutes_officer', 'persons.write'), ('minutes_officer', 'directory.read'),
  ('follow_up', 'tasks.read_own'), ('follow_up', 'tasks.read_all'), ('follow_up', 'tasks.create'),
  ('follow_up', 'tasks.reassign'), ('follow_up', 'tasks.cancel'), ('follow_up', 'tasks.review'),
  ('follow_up', 'performance.read'), ('follow_up', 'persons.write'), ('follow_up', 'directory.read'),
  ('secretary', 'tasks.read_own'), ('employee', 'tasks.read_own')
) AS p(role_code, code) ON p.role_code = r.code;

INSERT INTO settings (key, value) VALUES
  ('timezone', '"Asia/Baghdad"'), ('report.morning_time', '"08:00"'), ('report.evening_time', '"17:00"'),
  ('task.default_due_hours', '48'), ('reminder.before_due_hours', '[24, 1]'),
  ('alert.normal_repeat_minutes', '10'), ('alert.high_repeat_minutes', '5'),
  ('auth.max_failed_attempts', '5'), ('auth.lock_minutes', '15');
`;
