import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { AppError } from '../utils/errors.js';
import { parseBody } from '../utils/http.js';
import { requirePermission } from './auth.js';
import type { OfficeContext } from './context.js';
import { recordEvent } from './events.js';

const AppointmentBody = z.object({
  title: z.string().trim().min(1),
  kind: z.enum(['appointment', 'interview']).default('appointment'),
  starts_at: z.iso.datetime({ offset: true }),
  ends_at: z.iso.datetime({ offset: true }).nullish(),
  location: z.string().nullish(),
  notes: z.string().nullish(),
  person_id: z.uuid().nullish(),
});
const PersonBody = z.object({
  full_name: z.string().trim().min(1),
  aliases: z.array(z.string()).default([]),
  organization: z.string().nullish(),
  phone: z.string().nullish(),
  notes: z.string().nullish(),
});

/** The office manager's appointments and interviews; whatever is added here the principal can ask the AI about. */
export function calendarRoutes(app: FastifyInstance, office: OfficeContext): void {
  const { db } = office;

  app.get<{ Querystring: { start?: string; end?: string } }>('/api/v1/appointments', async (request) => {
    requirePermission(await office.user(request), 'appointments.write');
    const items = await db.query(
      `SELECT a.id, a.title, a.kind, a.starts_at, a.ends_at, a.location, a.notes, p.full_name AS person_name
       FROM appointments a LEFT JOIN persons p ON p.id = a.person_id
       WHERE a.cancelled_at IS NULL AND ($1::timestamptz IS NULL OR a.starts_at >= $1) AND ($2::timestamptz IS NULL OR a.starts_at < $2)
       ORDER BY a.starts_at`, [request.query.start ?? null, request.query.end ?? null]);
    return { items, next_cursor: null };
  });

  app.post('/api/v1/appointments', async (request, reply) => {
    const user = await office.user(request);
    requirePermission(user, 'appointments.write');
    const body = parseBody(AppointmentBody, request.body);
    const [row] = await db.query<{ id: string }>(
      `INSERT INTO appointments (title, kind, starts_at, ends_at, location, notes, person_id, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id, title, kind, starts_at, ends_at, location, notes, person_id`,
      [body.title, body.kind, body.starts_at, body.ends_at ?? null, body.location ?? null, body.notes ?? null, body.person_id ?? null, user.id]);
    const label = body.kind === 'interview' ? 'مقابلة جديدة' : 'موعد جديد';
    await recordEvent(db, { type: 'user', userId: user.id }, 'appointment.created', { type: 'appointment', id: row!.id },
      `${label}: ${body.title} بتاريخ ${body.starts_at}`);
    return reply.code(201).send(row);
  });

  app.delete<{ Params: { id: string } }>('/api/v1/appointments/:id', async (request, reply) => {
    const user = await office.user(request);
    requirePermission(user, 'appointments.write');
    const [row] = await db.query<{ title: string }>(
      'UPDATE appointments SET cancelled_at = now() WHERE id = $1 AND cancelled_at IS NULL RETURNING title', [request.params.id]);
    if (!row) throw new AppError(404, 'APPOINTMENT_NOT_FOUND', 'الموعد غير موجود');
    await recordEvent(db, { type: 'user', userId: user.id }, 'appointment.cancelled', { type: 'appointment', id: request.params.id }, `أُلغي الموعد: ${row.title}`);
    return reply.code(204).send();
  });

  app.get('/api/v1/persons', async (request) => {
    requirePermission(await office.user(request), 'persons.write');
    return { items: await db.query('SELECT * FROM persons ORDER BY full_name'), next_cursor: null };
  });

  /** A guest's file: who they are and what they came for before, for the brief the AI gives before the meeting. */
  app.get<{ Params: { id: string } }>('/api/v1/persons/:id', async (request) => {
    requirePermission(await office.user(request), 'persons.write');
    const [person] = await db.query('SELECT * FROM persons WHERE id = $1', [request.params.id]);
    if (!person) throw new AppError(404, 'PERSON_NOT_FOUND', 'الشخص غير موجود');
    const visits = await db.query(
      `SELECT id, title, kind, starts_at, notes FROM appointments WHERE person_id = $1 AND cancelled_at IS NULL ORDER BY starts_at DESC LIMIT 20`,
      [request.params.id]);
    return { ...person, visits };
  });

  app.patch<{ Params: { id: string } }>('/api/v1/persons/:id', async (request) => {
    requirePermission(await office.user(request), 'persons.write');
    const b = parseBody(PersonBody.partial(), request.body);
    const [row] = await db.query(
      `UPDATE persons SET full_name = COALESCE($2, full_name), organization = COALESCE($3, organization), phone = COALESCE($4, phone),
              notes = COALESCE($5, notes) WHERE id = $1 RETURNING *`,
      [request.params.id, b.full_name ?? null, b.organization ?? null, b.phone ?? null, b.notes ?? null]);
    if (!row) throw new AppError(404, 'PERSON_NOT_FOUND', 'الشخص غير موجود');
    return row;
  });

  app.post('/api/v1/persons', async (request, reply) => {
    requirePermission(await office.user(request), 'persons.write');
    const b = parseBody(PersonBody, request.body);
    const [row] = await db.query(
      'INSERT INTO persons (full_name, aliases, organization, phone, notes) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [b.full_name, b.aliases, b.organization ?? null, b.phone ?? null, b.notes ?? null]);
    return reply.code(201).send(row);
  });
}
