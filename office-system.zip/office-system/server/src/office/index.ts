import websocket from '@fastify/websocket';
import type { FastifyInstance } from 'fastify';
import type { Db } from '../db/index.js';
import { adminRoutes } from './admin.js';
import { attachmentRoutes } from './attachments.js';
import { signingSecret } from './auth.js';
import { calendarRoutes } from './calendar.js';
import { officeContext, type OfficeContext } from './context.js';
import { faceClient, faceRoutes, type FaceClient } from './face.js';
import { letterRoutes } from './letters.js';
import { meetingRoutes } from './meetings.js';
import { messageRoutes } from './messages.js';
import { PushHub } from './push.js';
import { reportRoutes } from './reports.js';
import { taskRoutes } from './tasks.js';
import { startWorker } from './worker.js';

export interface Office {
  context: OfficeContext;
}

/**
 * The office's API under /api/v1: the staff app signs in as a user; the AI system uses /api/v1/ai/* with a service key
 * (src/ai/). Everything that changes the office goes through the functions here, whoever asks.
 */
export async function registerOffice(app: FastifyInstance, db: Db, options: { worker?: boolean; face?: FaceClient } = {}): Promise<Office> {
  const push = new PushHub(db, app.log);
  const context = officeContext(db, await signingSecret(db), push);
  await app.register(websocket);
  push.register(app);
  adminRoutes(app, context);
  taskRoutes(app, context);
  meetingRoutes(app, context);
  calendarRoutes(app, context);
  reportRoutes(app, context);
  attachmentRoutes(app, context);
  messageRoutes(app, context);
  letterRoutes(app, context);
  faceRoutes(app, context, options.face ?? faceClient(app.config.faceUrl));
  if (options.worker !== false) {
    const stop = startWorker(context, app.log);
    app.addHook('onClose', async () => stop());
  }
  return { context };
}
