import { mkdtempSync, rmSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import pino from 'pino';
import { afterAll, describe, expect, it } from 'vitest';
import { startEmbeddedDb, type EmbeddedDb } from '../src/db/embedded.js';
import { migrate, PgDb } from '../src/db/index.js';
import { restoreDatabase } from '../src/db/restore.js';
// A plain .mjs script, shared with the nightly backup.
import { dumpDatabase } from '../scripts/lib/db-dump.mjs';

/**
 * The server's own PostgreSQL on a real (temporary) data folder: made once, started, reused.
 * Slow (initdb), so one test walks the whole life of it.
 */
const root = mkdtempSync(join(tmpdir(), 'office-pg-'));
const dir = join(root, 'postgres');
const port = 5490 + Math.floor(Math.random() * 40);
const log = pino({ level: 'silent' });
let running: EmbeddedDb | undefined;

afterAll(async () => {
  await running?.stop();
  rmSync(root, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
});

describe('embedded PostgreSQL', () => {
  it('makes the database on first start, keeps a private password, and is reused when already up', async () => {
    running = await startEmbeddedDb({ dir, port, log });
    expect(running.url).toMatch(new RegExp(`^postgres://office:.+@127\.0\.0\.1:${port}/office$`));
    expect(statSync(`${dir}.secret`).size).toBeGreaterThan(20);

    const db = new PgDb(running.url);
    expect(await migrate(db)).toContain('011_office_service_keys');
    await db.close();

    // Already running (a crashed server left it, or `npm run db` alongside): connect, do not start a second one.
    const again = await startEmbeddedDb({ dir, port, log });
    expect(again.url).toBe(running.url);
    await again.stop(); // a no-op: the first one keeps running
    const check = new PgDb(running.url);
    expect((await check.query('SELECT 1 AS ok'))[0]).toEqual({ ok: 1 });
    await check.close();
  }, 120_000);

  it('exports the database for the backup and puts it back into an empty one, images and Arabic intact', async () => {
    const db = new PgDb(running!.url);
    await migrate(db);
    const png = Buffer.from('89504e470d0a1a0a0000000d49484452', 'hex');
    await db.query(`INSERT INTO users (username, full_name, role_id) SELECT 'zainab', 'زينب حسن', id FROM roles WHERE code = 'secretary'`);
    const [task] = await db.query<{ id: string }>(
      `INSERT INTO tasks (title, description, priority, source, original_utterance, assignee_id, created_by_ai, original_due_at, due_at)
       SELECT 'تجهيز القاعة', 'قبل الاجتماع', 'high', 'voice_ai', 'خلي زينب تجهز القاعة', id, true, now(), now() FROM users WHERE username = 'zainab' RETURNING id`);
    await db.query(`INSERT INTO attachments (task_id, purpose, file_name, content_type, size_bytes, data, uploaded_by)
                    SELECT $1, 'task', 'a.png', 'image/png', $2, $3, id FROM users WHERE username = 'zainab'`, [task!.id, png.length, png]);
    await db.query(`INSERT INTO events (event_type, actor_type, subject_type, subject_id, summary) VALUES ('task.created', 'ai', 'task', $1, 'كُلّفت زينب')`, [task!.id]);
    await db.exec('CREATE DATABASE restored');
    await db.close();

    const dump = join(root, 'backup');
    const written = await dumpDatabase(running!.url, join(dump, 'database'));
    expect(written.files).toBeGreaterThan(10);

    const target = new PgDb(running!.url.replace(/\/office$/, '/restored'));
    try {
      const counts = await restoreDatabase(target, dump);
      expect(counts).toMatchObject({ users: 1, tasks: 1, attachments: 1, events: 1 });
      const [back] = await target.query<{ title: string; data: Buffer; full_name: string }>(
        `SELECT t.title, a.data, u.full_name FROM tasks t JOIN attachments a ON a.task_id = t.id JOIN users u ON u.id = t.assignee_id`);
      expect(back!.title).toBe('تجهيز القاعة');
      expect(back!.full_name).toBe('زينب حسن');
      expect(Buffer.from(back!.data).equals(png)).toBe(true);
      // New events continue after the restored ones, and a restore refuses a database that has data.
      await target.query(`INSERT INTO events (event_type, actor_type, subject_type, subject_id, summary) VALUES ('x', 'ai', 'task', $1, 'بعد')`, [task!.id]);
      await expect(restoreDatabase(target, dump)).rejects.toThrow(/restore only into an empty one/);
    } finally {
      await target.close();
    }
  }, 120_000);
});
