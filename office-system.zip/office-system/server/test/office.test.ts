import type { FastifyInstance } from 'fastify';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import type { Db } from '../src/db/index.js';
import { createAdmin } from '../src/office/admin.js';
import { normalizeArabic, resolvePerson } from '../src/office/people.js';
import { zoneOffset } from '../src/office/reports.js';
import { hashPassword } from '../src/office/auth.js';
import { realertUnopened, runDueJobs, generateDueReports } from '../src/office/worker.js';
import { buildTestApp, serviceKey } from './helpers/app.js';
import { collectAnnouncements, reportText } from '../src/office/announce.js';
import { testDb } from './helpers/pglite.js';

const PASSWORD = 'office-test-1';
let seq = 0;
let app: FastifyInstance;
let db: Db;
let aiKey: string;


interface Session { id: string; name: string; token: string }

async function addUser(role: string, fullName?: string, jobTitle?: string): Promise<{ id: string; username: string; name: string }> {
  const username = `u${++seq}${Date.now()}`;
  const name = fullName ?? username;
  const [row] = await db.query<{ id: string }>(
    `INSERT INTO users (username, full_name, job_title, role_id, password_hash) SELECT $1, $2, $3, id, $4 FROM roles WHERE code = $5 RETURNING id`,
    [username, name, jobTitle ?? null, await hashPassword(PASSWORD), role]);
  return { id: row!.id, username, name };
}

async function login(role: string, fullName?: string, jobTitle?: string): Promise<Session> {
  const user = await addUser(role, fullName, jobTitle);
  const r = await app.inject({ method: 'POST', url: '/api/v1/auth/login', payload: { username: user.username, password: PASSWORD, device: { platform: 'windows', name: 't' } } });
  expect(r.statusCode, r.body).toBe(200);
  return { id: user.id, name: user.name, token: r.json().access_token };
}

const call = (s: Session, method: 'GET' | 'POST' | 'PATCH' | 'DELETE', url: string, payload?: object) =>
  app.inject({ method, url: `/api/v1${url}`, headers: { authorization: `Bearer ${s.token}` }, ...(payload ? { payload } : {}) });

async function newTask(from: Session, to: Session, extra: object = {}) {
  const r = await call(from, 'POST', '/tasks', { title: 'مهمة سرّية', description: 'تفاصيل سرّية', assignee_id: to.id, due_in_hours: 24, ...extra });
  expect(r.statusCode, r.body).toBe(201);
  return r.json() as { id: string };
}


beforeAll(async () => {
  db = await testDb();
  app = await buildTestApp(db);
  aiKey = await serviceKey(db);
});

afterAll(async () => {
  await app.close();
  await db.close();
});

/** What the AI system reads: the announcements waiting to be said. */
const announcements = async () => (await app.inject({ method: 'GET', url: '/api/v1/ai/announcements', headers: { authorization: `Bearer ${aiKey}` } }))
  .json().items as Array<{ id: string; kind: string; text: string; urgent: boolean }>;

describe('office: sign-in and roles', () => {
  it('signs in, refuses a wrong password the same as a missing user, and locks after five failures', async () => {
    const user = await addUser('employee');
    const wrong = await app.inject({ method: 'POST', url: '/api/v1/auth/login', payload: { username: user.username, password: 'x', device: { platform: 'windows', name: 't' } } });
    const ghost = await app.inject({ method: 'POST', url: '/api/v1/auth/login', payload: { username: 'nobody', password: 'x', device: { platform: 'windows', name: 't' } } });
    expect(wrong.statusCode).toBe(401);
    expect(wrong.json().error.message).toBe(ghost.json().error.message);
    for (let i = 0; i < 4; i++) await app.inject({ method: 'POST', url: '/api/v1/auth/login', payload: { username: user.username, password: 'x', device: { platform: 'windows', name: 't' } } });
    const locked = await app.inject({ method: 'POST', url: '/api/v1/auth/login', payload: { username: user.username, password: PASSWORD, device: { platform: 'windows', name: 't' } } });
    expect(locked.json().error.code).toBe('LOGIN_LOCKED');
  });

  it('does not let a user token open the AI door, nor a service key the staff routes', async () => {
    expect((await app.inject({ method: 'GET', url: '/api/v1/me' })).statusCode).toBe(401);
    const s = await login('employee');
    expect((await app.inject({ method: 'GET', url: '/api/v1/ai/health', headers: { authorization: `Bearer ${s.token}` } })).statusCode).toBe(401);
    expect((await app.inject({ method: 'GET', url: '/api/v1/me', headers: { authorization: `Bearer ${aiKey}` } })).statusCode).toBe(401);
  });

  it('lets the admin change what a role may do, and the change applies at once', async () => {
    const admin = await login('admin');
    const secretary = await login('secretary');
    expect((await call(secretary, 'GET', '/directory')).statusCode).toBe(403);
    const roles = (await call(admin, 'GET', '/roles')).json().items as Array<{ id: string; code: string; permission_codes: string[] }>;
    const role = roles.find((r) => r.code === 'secretary')!;
    const r = await call(admin, 'PATCH', `/roles/${role.id}`, { permission_codes: [...role.permission_codes, 'directory.read'] });
    expect(r.statusCode).toBe(200);
    expect((await call(secretary, 'GET', '/directory')).statusCode).toBe(200);
    await call(admin, 'PATCH', `/roles/${role.id}`, { permission_codes: role.permission_codes });
  });

  it('keeps role management with the admin role', async () => {
    const admin = await login('admin');
    const role = ((await call(admin, 'GET', '/roles')).json().items as Array<{ id: string; code: string }>).find((r) => r.code === 'admin')!;
    expect((await call(admin, 'PATCH', `/roles/${role.id}`, { permission_codes: ['users.manage'] })).statusCode).toBe(409);
  });

  it('shows each role only its own screens', async () => {
    const secretary = await login('secretary');
    for (const path of ['/tasks', '/tasks/review-queue', '/directory', '/meetings', '/appointments', '/users', '/roles', '/dashboard/overview']) {
      expect((await call(secretary, 'GET', path)).statusCode, path).toBe(403);
    }
  });

  it('renames an employee and the new name is the one the office knows', async () => {
    const admin = await login('admin');
    const worker = await login('employee', 'اسم قديم');
    await call(admin, 'PATCH', `/users/${worker.id}`, { full_name: 'اسم جديد', job_title: 'منصب جديد' });
    const directory = await login('office_manager');
    const items = (await call(directory, 'GET', '/directory')).json().items as Array<{ id: string; full_name: string }>;
    expect(items.find((p) => p.id === worker.id)?.full_name).toBe('اسم جديد');
  });

  it('creates the first admin', async () => {
    await createAdmin(db, `root${Date.now()}`, 'مدير', 'password-123');
  });
});

describe('office: tasks', () => {
  it('keeps a task sealed until the assignee opens it, and records when', async () => {
    const sender = await login('follow_up');
    const worker = await login('employee');
    const task = await newTask(sender, worker, { priority: 'high' });
    const sealed = (await call(worker, 'GET', '/tasks/mine')).json().items[0];
    expect(Object.keys(sealed).sort()).toEqual(['created_at', 'id', 'notification_level', 'sealed']);
    expect((await call(worker, 'GET', `/tasks/${task.id}`)).statusCode).toBe(404);

    const opened = await call(worker, 'POST', `/tasks/${task.id}/open`);
    expect(opened.json().title).toBe('مهمة سرّية');
    const again = await call(worker, 'POST', `/tasks/${task.id}/open`);
    expect(again.json().opened_at).toBe(opened.json().opened_at);

    const stranger = await login('employee');
    expect((await call(stranger, 'POST', `/tasks/${task.id}/open`)).statusCode).toBe(404);
  });

  it('runs the whole cycle with a return, and counts the accepted submission', async () => {
    const reviewer = await login('follow_up');
    const worker = await login('employee');
    const { id } = await newTask(reviewer, worker);
    await call(worker, 'POST', `/tasks/${id}/open`);
    expect((await call(worker, 'POST', `/tasks/${id}/submit`, { result_text: 'قبل المباشرة' })).statusCode).toBe(409);
    await call(worker, 'POST', `/tasks/${id}/start`);
    await call(worker, 'POST', `/tasks/${id}/submit`, { result_text: 'أ' });
    expect((await call(reviewer, 'POST', `/tasks/${id}/review`, { decision: 'returned' })).statusCode).toBe(400);
    await call(reviewer, 'POST', `/tasks/${id}/review`, { decision: 'returned', note: 'ناقص' });
    expect((await call(worker, 'GET', `/tasks/${id}`)).json().return_note).toBe('ناقص');
    await call(worker, 'POST', `/tasks/${id}/submit`, { result_text: 'ب' });
    expect((await call(reviewer, 'POST', `/tasks/${id}/review`, { decision: 'accepted' })).json().status).toBe('closed');
    const view = (await call(reviewer, 'GET', `/tasks/${id}`)).json();
    expect(view).toMatchObject({ result_text: 'ب', attempts: 2, completed_on_time: true });
    const types = (await call(reviewer, 'GET', `/tasks/${id}/timeline`)).json().items.map((e: { event_type: string }) => e.event_type);
    expect(types).toEqual(['task.created', 'task.opened', 'task.started', 'task.submitted', 'task.returned', 'task.submitted', 'task.closed']);
  });

  it('shows the sender whether it arrived and when it was opened', async () => {
    const sender = await login('office_manager');
    const worker = await login('secretary');
    const { id } = await newTask(sender, worker);
    let sent = (await call(sender, 'GET', '/tasks/sent')).json().items[0];
    expect(sent).toMatchObject({ id, opened_at: null, device_not_reached: true });
    await call(worker, 'POST', `/tasks/${id}/open`);
    sent = (await call(sender, 'GET', '/tasks/sent')).json().items[0];
    expect(sent.opened_at).not.toBeNull();
  });

  it('keeps ringing an unopened task and stops once it is opened', async () => {
    const sender = await login('follow_up');
    const worker = await login('employee');
    const { id } = await newTask(sender, worker, { priority: 'high' });
    await db.query(`UPDATE notifications SET next_alert_at = now() - interval '1 second' WHERE task_id = $1`, [id]);
    await realertUnopened(app.office!.context);
    const [n] = await db.query<{ alert_count: number }>(`SELECT alert_count FROM notifications WHERE task_id = $1`, [id]);
    expect(n!.alert_count).toBe(2);
    await call(worker, 'POST', `/tasks/${id}/open`);
    const [after] = await db.query<{ next_alert_at: Date | null }>(`SELECT next_alert_at FROM notifications WHERE task_id = $1`, [id]);
    expect(after!.next_alert_at).toBeNull();
  });

  it('sends a reminder, and skips it once the due date moved', async () => {
    const sender = await login('follow_up');
    const worker = await login('employee');
    const { id } = await newTask(sender, worker, { due_in_hours: 48 });
    await db.query(`UPDATE jobs SET run_at = now() WHERE id = (SELECT min(id) FROM jobs WHERE payload->>'task_id' = $1)`, [id]);
    await runDueJobs(app.office!.context);
    const kinds = (await call(worker, 'GET', '/notifications/mine')).json().items.map((n: { kind: string }) => n.kind);
    expect(kinds).toEqual(['task_assigned', 'task_reminder']);
  });

  it('makes the morning report once its time has come', async () => {
    const made = await generateDueReports(db, new Date('2031-03-10T05:30:00Z')); // 08:30 in Baghdad
    expect(made).toEqual(['morning']);
    expect(await generateDueReports(db, new Date('2031-03-10T05:40:00Z'))).toEqual([]);
  });
});

describe('office: meetings', () => {
  it('publishes every task at once and never shows the minutes to an employee', async () => {
    const recorder = await login('minutes_officer');
    const worker = await login('employee');
    const meeting = (await call(recorder, 'POST', '/meetings', { title: 'اجتماع خاص', held_at: new Date().toISOString(), body: 'نص المحضر السرّي' })).json();
    const r = await call(recorder, 'POST', `/meetings/${meeting.id}/publish`, { tasks: [{ title: 'مهمتك', assignee_id: worker.id, due_in_hours: 168, priority: 'high' }] });
    expect(r.statusCode, r.body).toBe(200);
    const taskId = (await call(worker, 'GET', '/tasks/mine')).json().items[0].id;
    const opened = await call(worker, 'POST', `/tasks/${taskId}/open`);
    expect(opened.body).not.toContain('نص المحضر');
    expect(opened.body).not.toContain('meeting');
    expect((await call(worker, 'GET', `/meetings/${meeting.id}`)).statusCode).toBe(403);
    expect((await call(await login('minutes_officer'), 'GET', `/meetings/${meeting.id}`)).statusCode).toBe(404);
  });

  it('cancels the whole publish when one task is wrong', async () => {
    const recorder = await login('minutes_officer');
    const worker = await login('employee');
    const meeting = (await call(recorder, 'POST', '/meetings', { title: 'x', held_at: new Date().toISOString() })).json();
    const r = await call(recorder, 'POST', `/meetings/${meeting.id}/publish`, { tasks: [
      { title: 'سليمة', assignee_id: worker.id, due_in_hours: 24 },
      { title: 'خاطئة', assignee_id: '00000000-0000-0000-0000-000000000000', due_in_hours: 24 },
    ] });
    expect(r.statusCode).toBe(400);
    expect((await call(recorder, 'GET', `/meetings/${meeting.id}`)).json().status).toBe('draft');
    expect((await call(worker, 'GET', '/tasks/mine')).json().items).toEqual([]);
  });
});

describe('office: attachments', () => {
  const png = Buffer.from('89504e470d0a1a0a0000000d49484452', 'hex');
  const upload = (s: Session, taskId: string, data: Buffer, name = 'a.png') => {
    const boundary = 'xBOUNDARYx';
    const body = Buffer.concat([
      Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${name}"\r\nContent-Type: image/png\r\n\r\n`),
      data, Buffer.from(`\r\n--${boundary}--\r\n`),
    ]);
    return app.inject({ method: 'POST', url: `/api/v1/tasks/${taskId}/attachments`, payload: body,
      headers: { authorization: `Bearer ${s.token}`, 'content-type': `multipart/form-data; boundary=${boundary}` } });
  };

  it('lets the sender attach an image the assignee sees only after opening', async () => {
    const sender = await login('office_manager');
    const worker = await login('secretary');
    const { id } = await newTask(sender, worker);
    const r = await upload(sender, id, png);
    expect(r.statusCode, r.body).toBe(201);
    expect(r.json()).toMatchObject({ purpose: 'task', content_type: 'image/png' });

    expect((await call(worker, 'GET', `/tasks/${id}/attachments`)).statusCode).toBe(404);
    expect((await call(worker, 'GET', `/attachments/${r.json().id}`)).statusCode).toBe(404);
    await call(worker, 'POST', `/tasks/${id}/open`);
    const file = await call(worker, 'GET', `/attachments/${r.json().id}`);
    expect(file.headers['content-type']).toBe('image/png');
    expect(file.rawPayload.equals(png)).toBe(true);
  });

  it('attaches the assignee\'s image to the result, and refuses what is not an image', async () => {
    const sender = await login('office_manager');
    const worker = await login('secretary');
    const { id } = await newTask(sender, worker);
    await call(worker, 'POST', `/tasks/${id}/open`);
    expect((await upload(worker, id, png)).json().purpose).toBe('result');
    expect((await upload(worker, id, Buffer.from('MZ not an image'), 'evil.png')).statusCode).toBe(400);
    expect((await upload(await login('employee'), id, png)).statusCode).toBe(404);
  });
});

describe('office: who and what was meant', () => {
  it('matches Arabic spellings and refuses to guess between two people', () => {
    expect(normalizeArabic('مديرُ المكتب')).toBe(normalizeArabic('مدير مكتب'));
    const people = [
      { id: '1', full_name: 'علي حسن', job_title: null, role_name: 'موظف', aliases: [] },
      { id: '2', full_name: 'علي كريم', job_title: 'مدير المكتب', role_name: 'مدير المكتب', aliases: [] },
    ];
    expect(resolvePerson(people, 'مدير مكتب').id).toBe('2');
    expect(() => resolvePerson(people, 'علي')).toThrow(/منو تقصد، علي حسن لو علي كريم/);
  });

  it('gives the office real dates and a time-zone offset that needs no zone data', () => {
    expect(zoneOffset('Asia/Baghdad')).toBe('+03:00');
    expect(zoneOffset('UTC')).toBe('+00:00');
  });
});

describe('office: messages', () => {
  it('keeps a task conversation to those who may see the task', async () => {
    const sender = await login('office_manager');
    const worker = await login('secretary');
    const { id } = await newTask(sender, worker, { title: `مهمة نقاش ${Date.now()}` });
    expect((await call(worker, 'POST', '/messages', { to: sender.id, body: 'سؤال', task_id: id })).statusCode).toBe(404); // still sealed
    await call(worker, 'POST', `/tasks/${id}/open`);
    expect((await call(worker, 'POST', '/messages', { to: sender.id, body: 'وين المفتاح؟', task_id: id })).statusCode).toBe(201);
    expect((await call(sender, 'GET', `/tasks/${id}/messages`)).json().items[0].body).toBe('وين المفتاح؟');
    expect((await call(await login('employee'), 'GET', `/tasks/${id}/messages`)).statusCode).toBe(404);
  });
});

describe('office: what the AI system tells the principal by itself', () => {
  const ai = () => ({ authorization: `Bearer ${aiKey}` });

  it('says once: an urgent task nobody opened, a late task, a result, a message and an appointment about to start', async () => {
    await db.query(`UPDATE settings SET value = '0' WHERE key = 'announce.unopened_minutes'`);
    const sender = await login('follow_up');
    const worker = await login('secretary', `عباس ${Date.now()}`);
    const urgent = await newTask(sender, worker, { title: `عاجل ${Date.now()}`, priority: 'high' });
    await db.query(`UPDATE tasks SET created_at = now() - interval '1 minute' WHERE id = $1`, [urgent.id]);
    const late = await newTask(sender, worker, { title: `متأخرة ${Date.now()}` });
    await db.query(`UPDATE tasks SET due_at = now() - interval '5 minutes' WHERE id = $1`, [late.id]);

    // A task the principal gave through the AI system, opened, started and handed in.
    const asked = await app.inject({ method: 'POST', url: '/api/v1/ai/tasks', headers: ai(),
      payload: { assignee_id: worker.id, title: `تقرير الميزانية ${Date.now()}`, original_utterance: 'خلي عباس يكتب تقرير الميزانية' } });
    expect(asked.statusCode, asked.body).toBe(201);
    const taskId = asked.json().id as string;
    await call(worker, 'POST', `/tasks/${taskId}/open`);
    await call(worker, 'POST', `/tasks/${taskId}/start`);
    await call(worker, 'POST', `/tasks/${taskId}/submit`, { result_text: 'التقرير جاهز على مكتب السكرتير' });
    const message = (await call(worker, 'POST', '/messages', { to: 'principal', body: 'الضيف وصل للاستعلامات' })).json() as { id: string };

    const [principal] = await db.query<{ id: string }>('SELECT id FROM users LIMIT 1');
    await db.query(`INSERT INTO persons (full_name, organization, notes) VALUES ('أبو حسن', 'دائرة الكهرباء', 'طلب سابقاً محولة للحي') `);
    await db.query(
      `INSERT INTO appointments (title, starts_at, created_by, person_id) SELECT 'لقاء دائرة الكهرباء', now() + interval '10 minutes', $1, id FROM persons WHERE full_name = 'أبو حسن'`,
      [principal!.id]);

    expect(await collectAnnouncements(db)).toBeGreaterThanOrEqual(5);
    expect(await collectAnnouncements(db)).toBe(0); // each happening once
    const items = await announcements();
    const text = items.map((i) => i.text).join('\n');
    expect(text).toMatch(/وما فتحها|ما وصلت لجهاز/);
    expect(text).toContain('تأخرت عن موعدها');
    expect(text).toContain('النتيجة: التقرير جاهز على مكتب السكرتير');
    expect(text).toContain('الضيف وصل للاستعلامات');
    expect(text).toMatch(/بعد (9|10) دقيقة عندك موعد: لقاء دائرة الكهرباء/);
    expect(text).toContain('طلب سابقاً محولة للحي');
    expect(items[0]!.urgent).toBe(true); // urgent first

    // Said aloud: gone from the list, and the message counts as read.
    const said = items.find((i) => i.kind === 'message')!;
    expect((await app.inject({ method: 'POST', url: `/api/v1/ai/announcements/${said.id}/spoken`, headers: ai() })).statusCode).toBe(204);
    expect((await announcements()).some((i) => i.id === said.id)).toBe(false);
    expect((await db.query<{ read_at: Date | null }>('SELECT read_at FROM messages WHERE id = $1', [message.id]))[0]!.read_at).not.toBeNull();
    await db.query(`UPDATE announcements SET spoken_at = now()`);
  });

  it('shows the principal today at a glance, only with a service key', async () => {
    expect((await app.inject({ method: 'GET', url: '/api/v1/ai/today' })).statusCode).toBe(401);
    const today = (await app.inject({ method: 'GET', url: '/api/v1/ai/today', headers: ai() })).json();
    expect(today).toEqual(expect.objectContaining({
      now: expect.any(String), appointments: expect.any(Array), overdue: expect.any(Array), not_opened: expect.any(Array),
      working: expect.any(Array), unread_messages: expect.any(Array), recent_announcements: expect.any(Array),
    }));
  });

  it('turns the morning report into a few spoken sentences', () => {
    const text = reportText('morning', {
      overdue: [{ title: 'أ', assignee: 'زينب' }, { title: 'ب', assignee: 'سامي' }, { title: 'ج', assignee: 'علي' }],
      due_soon: [], not_opened: [{ title: 'د', assignee: 'زينب' }], completed: [{ title: 'هـ', assignee: 'سامي' }],
    }, 'Asia/Baghdad');
    expect(text).toBe('صباح الخير، هذا تقرير الصبح. خلصت مهمة وحدة من آخر تقرير. متأخرة 3: «أ» عند زينب و«ب» عند سامي وغيرها. مهمة وحدة ما انفتحت بعد.');
    expect(reportText('evening', { overdue: [], due_soon: [], not_opened: [], completed: [] }, 'UTC')).toContain('ماكو شي متأخر');
  });
});

describe('office: official letters', () => {
  const png = Buffer.from('89504e470d0a1a0a0000000d49484452', 'hex');
  const upload = (s: Session, url: string) => {
    const form = new FormData();
    form.append('file', new Blob([new Uint8Array(png)], { type: 'image/png' }), 'page1.png');
    return app.inject({ method: 'POST', url: `/api/v1${url}`, headers: { authorization: `Bearer ${s.token}` }, payload: form });
  };

  it('registers a letter with its page; only the register keepers see it, and the principal hears it arrived', async () => {
    const manager = await login('office_manager');
    const secretary = await login('secretary');
    const subject = `تجهيز محولة ${Date.now()}`;
    const fields = { ref_number: '4521', letter_date: '2026-11-05', party: 'وزارة الكهرباء', subject, summary: 'يطلبون موافقة على محولة.' };
    expect((await call(secretary, 'POST', '/letters', fields)).statusCode).toBe(403);
    const made = await call(manager, 'POST', '/letters', fields);
    expect(made.statusCode, made.body).toBe(201);
    const letter = made.json() as { id: string };
    expect((await upload(manager, `/letters/${letter.id}/images`)).statusCode).toBe(201);
    const list = (await call(manager, 'GET', '/letters')).json().items as Array<{ id: string; images: number; margin: string | null }>;
    expect(list.find((l) => l.id === letter.id)).toMatchObject({ images: 1, margin: null });
    expect((await call(secretary, 'GET', '/letters')).statusCode).toBe(403);
    // The office reads no photos: there is no reading route here.
    expect((await upload(manager, '/letters/read')).statusCode).toBe(404);

    await collectAnnouncements(db);
    expect((await announcements()).some((a) => a.text.includes(subject) && a.text.includes('وزارة الكهرباء'))).toBe(true);
  });

  it('enters a margin written on the paper as a task with the letter\'s page, once', async () => {
    const manager = await login('office_manager');
    const worker = await login('employee', `قانوني ${Date.now()}`);
    const subject = `طلب قطعة أرض ${Date.now()}`;
    const letter = (await call(manager, 'POST', '/letters', { subject, party: 'بلدية الكرخ', ref_number: '77' })).json() as { id: string };
    await upload(manager, `/letters/${letter.id}/images`);
    const margined = await call(manager, 'POST', `/letters/${letter.id}/margin`, { assignee_id: worker.id, margin: 'للدراسة وبيان الرأي', due_in_hours: 48 });
    expect(margined.statusCode, margined.body).toBe(201);
    const opened = (await call(worker, 'POST', `/tasks/${margined.json().task_id}/open`)).json();
    expect(opened.title).toBe(`هامش: ${subject}`);
    expect(opened.description).toContain('الهامش: للدراسة وبيان الرأي');
    expect(opened.attachments).toBe(1);
    expect((await call(manager, 'POST', `/letters/${letter.id}/margin`, { assignee_id: worker.id, margin: 'مرة ثانية' })).json().error.code).toBe('LETTER_MARGINED');
  });
});

describe('office: the people file', () => {
  it('adds the office\'s people from seed/users.json with a first password, and leaves existing ones alone', async () => {
    const { seedUsers } = await import('../src/db/seed.js');
    const { mkdtempSync, writeFileSync } = await import('node:fs');
    const { join } = await import('node:path');
    const { tmpdir } = await import('node:os');
    const real = JSON.parse((await import('node:fs')).readFileSync('seed/users.json', 'utf8')) as { users: Array<{ role: string }> };
    expect(real.users.length).toBeGreaterThan(3);
    const stamp = Date.now();
    const file = join(mkdtempSync(join(tmpdir(), 'seed-')), 'users.json');
    writeFileSync(file, JSON.stringify({ users: [
      { username: `seed-a-${stamp}`, full_name: 'موظف أول', role: 'secretary' },
      { username: `seed-b-${stamp}`, full_name: 'موظف ثاني', job_title: 'مدير المكتب', role: 'office_manager' },
    ] }));
    await expect(seedUsers(db, file, 'short')).rejects.toThrow(/8 characters/);
    expect(await seedUsers(db, file, 'first-pass-1')).toEqual({ added: [`seed-a-${stamp}`, `seed-b-${stamp}`], skipped: [] });
    expect((await seedUsers(db, file, 'first-pass-1')).skipped).toHaveLength(2);
    const r = await app.inject({ method: 'POST', url: '/api/v1/auth/login', payload: { username: `seed-b-${stamp}`, password: 'first-pass-1', device: { platform: 'windows', name: 't' } } });
    expect(r.statusCode).toBe(200);
  });
});

describe('office: the minutes officer at the meeting', () => {
  it('sends the decisions and the tasks, and the principal hears the summary', async () => {
    const officer = await login('minutes_officer');
    const worker = await login('employee', `حسن ${Date.now()}`);
    const title = `اجتماع المحولة ${Date.now()}`;
    const meeting = (await call(officer, 'POST', '/meetings', { title, held_at: new Date().toISOString() })).json() as { id: string };
    const published = await call(officer, 'POST', `/meetings/${meeting.id}/publish`, {
      decisions: ['الموافقة على نصب المحولة قرب المدرسة'],
      tasks: [{ title: 'مخاطبة البلدية بالموافقة', assignee_id: worker.id, priority: 'high', due_in_hours: 2 }],
    });
    expect(published.statusCode, published.body).toBe(200);
    expect(published.json()).toMatchObject({ decisions: ['الموافقة على نصب المحولة قرب المدرسة'] });

    await collectAnnouncements(db);
    const summary = (await announcements()).find((a) => a.kind === 'minutes' && a.text.includes(title))!;
    expect(summary.text).toContain('القرارات: الموافقة على نصب المحولة قرب المدرسة');
    expect(summary.text).toContain(`${worker.name} «مخاطبة البلدية بالموافقة»`);
  });
});
