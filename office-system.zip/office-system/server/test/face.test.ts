import http from 'node:http';
import type { AddressInfo } from 'node:net';
import type { FastifyInstance } from 'fastify';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import type { Db } from '../src/db/index.js';
import { hashPassword } from '../src/office/auth.js';
import { buildTestApp } from './helpers/app.js';
import { testDb } from './helpers/pglite.js';

/**
 * Face sign-in against a fake of the AI system's face model. The "photo" is a word; the fake turns it into a print: "salim" and
 * "salim2" are the same face a little apart, "noor" another face, "crowd" two faces, "wall" none.
 */
const DIM = 128;
const unit = (v: number[]) => { const n = Math.hypot(...v); return v.map((x) => x / n); };
const axis = (i: number, wobble = 0) => unit(Array.from({ length: DIM }, (_, k) => (k === i ? 1 : k === i + 1 ? wobble : 0)));
const PRINTS: Record<string, { faces: number; embedding?: number[] }> = {
  salim: { faces: 1, embedding: axis(0) },
  salim2: { faces: 1, embedding: axis(0, 0.3) },
  noor: { faces: 1, embedding: axis(10) },
  noorTwin: { faces: 1, embedding: axis(10, 0.2) },
  stranger: { faces: 1, embedding: axis(50) },
  crowd: { faces: 2 },
  wall: { faces: 0 },
};
const photo = (word: string) => Buffer.from(word.padEnd(120, '.')).toString('base64');

let face: http.Server;
let db: Db;
let app: FastifyInstance;

beforeAll(async () => {
  face = http.createServer((req, res) => {
    const chunks: Buffer[] = [];
    req.on('data', (c: Buffer) => chunks.push(c));
    req.on('end', () => {
      const word = Buffer.concat(chunks).toString().replace(/\.+$/, '');
      res.writeHead(200, { 'content-type': 'application/json' }).end(JSON.stringify(PRINTS[word] ?? { faces: 0 }));
    });
  });
  await new Promise<void>((r) => face.listen(0, '127.0.0.1', r));
  db = await testDb();
  app = await buildTestApp(db, { FACE_URL: `http://127.0.0.1:${(face.address() as AddressInfo).port}` });
  const hash = await hashPassword('office-dev-1');
  await db.query(
    `INSERT INTO users (username, full_name, role_id, password_hash)
     SELECT u, n, (SELECT id FROM roles WHERE code = 'secretary'), $1 FROM (VALUES ('salim', 'سالم الوجه'), ('noor', 'نور الوجه')) AS v(u, n)`, [hash]);
});
afterAll(async () => {
  await app.close();
  await db.close();
  await new Promise((r) => face.close(r));
});

const device = { platform: 'windows', name: 'كاميرا الاستقبال' };
async function token(username: string): Promise<string> {
  const r = await app.inject({ method: 'POST', url: '/api/v1/auth/login', payload: { username, password: 'office-dev-1', device } });
  return r.json().access_token;
}
const enrol = (t: string, word: string) =>
  app.inject({ method: 'POST', url: '/api/v1/me/face', headers: { authorization: `Bearer ${t}` }, payload: { image: photo(word) } });
const faceLogin = (word: string) => app.inject({ method: 'POST', url: '/api/v1/auth/face', payload: { image: photo(word), device } });
const whoAmI = async (accessToken: string) =>
  (await app.inject({ method: 'GET', url: '/api/v1/me', headers: { authorization: `Bearer ${accessToken}` } })).json().full_name;

describe('face sign-in', () => {
  it('enrols a face and signs that person in from a new photo', async () => {
    const salim = await token('salim');
    const res = await enrol(salim, 'salim');
    expect(res.statusCode, res.body).toBe(201);
    expect(res.json()).toMatchObject({ prints: 1 });

    const login = await faceLogin('salim2');
    expect(login.statusCode, login.body).toBe(200);
    expect(login.json()).toHaveProperty('push_token');
    expect(await whoAmI(login.json().access_token)).toBe('سالم الوجه');
  });

  it('refuses a stranger, no face, and several faces', async () => {
    expect((await faceLogin('stranger')).json().error.code).toBe('FACE_NOT_KNOWN');
    expect((await faceLogin('wall')).json().error.code).toBe('NO_FACE');
    expect((await faceLogin('crowd')).json().error.code).toBe('MANY_FACES');
  });

  it("will not keep a face that looks like someone else's", async () => {
    const noor = await token('noor');
    const res = await enrol(noor, 'salim2');
    expect(res.statusCode).toBe(409);
    expect(res.json().error.code).toBe('FACE_LIKE_OTHER');
    expect((await enrol(noor, 'noor')).statusCode).toBe(201);
  });

  it('turns off when the person deletes their prints', async () => {
    const salim = await token('salim');
    expect((await app.inject({ method: 'DELETE', url: '/api/v1/me/face', headers: { authorization: `Bearer ${salim}` } })).statusCode).toBe(204);
    expect((await faceLogin('salim2')).json().error.code).toBe('FACE_NOT_KNOWN');
  });

  it('says so when the face service is down', async () => {
    const down = await buildTestApp(db, { FACE_URL: 'http://127.0.0.1:9' });
    const res = await down.inject({ method: 'POST', url: '/api/v1/auth/face', payload: { image: photo('noor'), device } });
    expect(res.statusCode).toBe(503);
    await down.close();
  });
});
