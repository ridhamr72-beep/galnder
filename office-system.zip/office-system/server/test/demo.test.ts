import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import type { FastifyInstance } from 'fastify';
import type { Db } from '../src/db/index.js';
import { collectAnnouncements } from '../src/office/announce.js';
import type { Briefing } from '../src/office/briefing.js';
import { DEMO_PASSWORD, seedDemo } from '../src/office/demo.js';
import { buildTestApp, serviceKey } from './helpers/app.js';
import { testDb } from './helpers/pglite.js';

let db: Db;
let app: FastifyInstance;
let key: { authorization: string };

beforeAll(async () => {
  db = await testDb();
  app = await buildTestApp(db);
  key = { authorization: `Bearer ${await serviceKey(db)}` };
});
afterAll(async () => {
  await app.close();
  await db.close();
});

describe('the demo office on a new machine', () => {
  it('fills an empty office once: people who can sign in, work in every state, letters, messages and guests', async () => {
    expect(await seedDemo(app.office.context, process.cwd())).toBe(true);
    expect(await seedDemo(app.office.context, process.cwd())).toBe(false); // never twice, never over real people

    const login = await app.inject({ method: 'POST', url: '/api/v1/auth/login',
      payload: { username: 'sami', password: DEMO_PASSWORD, device: { platform: 'windows', name: 'demo' } } });
    expect(login.statusCode, login.body).toBe(200);
    const auth = { authorization: `Bearer ${login.json().access_token}` };
    const mine = (await app.inject({ method: 'GET', url: '/api/v1/tasks/mine', headers: auth })).json().items as Array<{ title?: string; sealed: boolean }>;
    expect(mine.map((t) => t.title)).toEqual(expect.arrayContaining(['حجز موعد مع مدير الكهرباء', 'تذكير بالباقلاء بالدهن الحر الساعة 6 عصراً']));
    expect(mine.filter((t) => t.sealed)).toHaveLength(1); // the letter's margin, waiting for him to open it

    const statuses = (await db.query<{ status: string }>('SELECT DISTINCT status FROM tasks')).map((r) => r.status).sort();
    expect(statuses).toEqual(['assigned', 'closed', 'in_progress', 'opened', 'returned', 'submitted']);
    const counts = (await db.query<{ letters: number; pages: number; persons: number; appts: number; messages: number }>(
      `SELECT (SELECT count(*)::int FROM letters) AS letters, (SELECT count(*)::int FROM attachments) AS pages,
              (SELECT count(*)::int FROM persons) AS persons, (SELECT count(*)::int FROM appointments) AS appts,
              (SELECT count(*)::int FROM messages) AS messages`))[0];
    expect(counts).toEqual({ letters: 3, pages: 2, persons: 2, appts: 3, messages: 6 }); // the margin's task got a copy of the page

    // The principal hears about it at once: the late urgent task, the result, the message, the letter without a margin.
    await collectAnnouncements(db);
    const said = (await app.inject({ method: 'GET', url: '/api/v1/ai/announcements', headers: key })).json().items as Array<{ kind: string }>;
    expect(new Set(said.map((a) => a.kind))).toEqual(new Set(['task_overdue', 'task_result', 'message', 'letter']));
  });

  it('briefs the principal when she opens: decisions waiting, what is late, news since she last looked', async () => {
    const first = (await app.inject({ method: 'GET', url: '/api/v1/ai/briefing', headers: key })).json() as Briefing;
    const titles = first.sections.map((s) => s.key);
    expect(titles.slice(0, 2)).toEqual(['decisions', 'late']); // what needs her first
    const decisions = first.sections[0]!.items.map((i) => i.text).join(' | ');
    expect(decisions).toContain('طلب تخصيص قطعة أرض لمحولة'); // the letter with no margin
    expect(decisions).toContain('سجّلت التذكير على تلفوني'); // a result of something she asked for
    expect(first.sections[1]!.items[0]!.text).toContain('زينب حسن');
    expect(first.spoken).toMatch(/^(صباح الخير|مساء الخير|مساء النور)\. تنتظر قرار حضرتك/);
    expect(first.spoken).toContain('متأخر: زينب حسن');

    expect((await app.inject({ method: 'POST', url: '/api/v1/ai/briefing/seen', headers: key })).statusCode).toBe(204);
    const later = (await app.inject({ method: 'GET', url: '/api/v1/ai/briefing', headers: key })).json() as Briefing;
    expect(later.since).not.toBeNull();
    expect(later.sections.find((s) => s.key === 'since')?.title ?? 'من آخر مرة فتحت').toBe('من آخر مرة فتحت');
  });
});
