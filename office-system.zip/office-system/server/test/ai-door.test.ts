import type { FastifyInstance } from 'fastify';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import type { Db } from '../src/db/index.js';
import { hashPassword } from '../src/office/auth.js';
import { buildTestApp, serviceKey } from './helpers/app.js';
import { testDb } from './helpers/pglite.js';

/**
 * The AI system's door (/api/v1/ai/*): everything the AI used to do by calling the office's functions directly, now
 * over HTTP with a service key, and nothing more.
 */

const PASSWORD = 'office-test-1';
let seq = 0;
let app: FastifyInstance;
let db: Db;
let key: string;

interface Session { id: string; name: string; token: string }

async function login(role: string, fullName?: string, jobTitle?: string): Promise<Session> {
  const username = `d${++seq}${Date.now()}`;
  const name = fullName ?? username;
  const [row] = await db.query<{ id: string }>(
    `INSERT INTO users (username, full_name, job_title, role_id, password_hash) SELECT $1, $2, $3, id, $4 FROM roles WHERE code = $5 RETURNING id`,
    [username, name, jobTitle ?? null, await hashPassword(PASSWORD), role]);
  const r = await app.inject({ method: 'POST', url: '/api/v1/auth/login', payload: { username, password: PASSWORD, device: { platform: 'windows', name: 't' } } });
  expect(r.statusCode, r.body).toBe(200);
  return { id: row!.id, name, token: r.json().access_token };
}

const call = (s: Session, method: 'GET' | 'POST' | 'PATCH' | 'DELETE', url: string, payload?: object) =>
  app.inject({ method, url: `/api/v1${url}`, headers: { authorization: `Bearer ${s.token}` }, ...(payload ? { payload } : {}) });

/** The AI system calling its door. */
const ai = (method: 'GET' | 'POST', url: string, payload?: object, headers: Record<string, string> = {}) =>
  app.inject({ method, url: `/api/v1/ai${url}`, headers: { authorization: `Bearer ${key}`, ...headers }, ...(payload ? { payload } : {}) });

beforeAll(async () => {
  db = await testDb();
  app = await buildTestApp(db);
  key = await serviceKey(db);
  await db.query(`INSERT INTO users (username, full_name, role_id, is_principal) SELECT 'boss', 'الشخصية', id, true FROM roles WHERE code = 'principal'`);
});

afterAll(async () => {
  await app.close();
  await db.close();
});

describe('AI door: keys', () => {
  it('lets the admin make a key that is shown once, scopes it, and revokes it', async () => {
    const admin = await login('admin');
    const secretary = await login('secretary');
    expect((await call(secretary, 'POST', '/api-keys', { name: 'x' })).statusCode).toBe(403);
    expect((await call(admin, 'POST', '/api-keys', { name: 'x', scopes: ['ai.everything'] })).json().error.code).toBe('UNKNOWN_SCOPE');

    const made = await call(admin, 'POST', '/api-keys', { name: 'قارئ فقط', scopes: ['ai.read'] });
    expect(made.statusCode, made.body).toBe(201);
    const { id, api_key: readOnly } = made.json() as { id: string; api_key: string };
    expect(readOnly).toMatch(/^ok_[0-9a-f]{8}_[0-9a-f]{64}$/);
    const listed = (await call(admin, 'GET', '/api-keys')).json().items as Array<Record<string, unknown>>;
    expect(JSON.stringify(listed)).not.toContain(readOnly.split('_')[2]); // the secret never again
    expect(listed.find((k) => k.id === id)).toMatchObject({ name: 'قارئ فقط', scopes: ['ai.read'], revoked_at: null });

    const as = (k: string, method: 'GET' | 'POST', url: string, payload?: object) =>
      app.inject({ method, url: `/api/v1/ai${url}`, headers: { authorization: `Bearer ${k}` }, ...(payload ? { payload } : {}) });
    expect((await as(readOnly, 'GET', '/health')).json()).toEqual({ status: 'ok', key: 'قارئ فقط', scopes: ['ai.read'] });
    const refused = await as(readOnly, 'POST', '/tasks', { assignee_query: 'x', title: 'y', original_utterance: 'z' });
    expect(refused.statusCode).toBe(403);
    expect(refused.json().error).toMatchObject({ code: 'MISSING_SCOPE', details: { scope: 'ai.tasks.write' } });

    expect((await call(admin, 'POST', `/api-keys/${id}/revoke`)).statusCode).toBe(204);
    expect((await as(readOnly, 'GET', '/health')).statusCode).toBe(401);
    expect((await app.inject({ method: 'GET', url: '/api/v1/ai/health' })).statusCode).toBe(401);
    expect((await as(`${readOnly}x`, 'GET', '/health')).statusCode).toBe(401);
    // Through x-api-key too, for programs that send that header.
    expect((await app.inject({ method: 'GET', url: '/api/v1/ai/health', headers: { 'x-api-key': key } })).statusCode).toBe(200);
  });
});

describe('AI door: tasks', () => {
  it('gives a task to the person named by post, sealed until opened, from the principal, in her own words', async () => {
    const post = `مدير مكتب ${Date.now()}`;
    const manager = await login('office_manager', 'سامي', post);
    const r = await ai('POST', '/tasks', { assignee_query: post, title: 'حجز موعد', priority: 'high', due_in_hours: 24,
      original_utterance: 'خلي مدير المكتب يحجزلي موعد باچر' });
    expect(r.statusCode, r.body).toBe(201);
    expect(r.json()).toMatchObject({ status: 'assigned', priority: 'high', assignee: { id: manager.id, full_name: 'سامي' } });

    const mine = (await call(manager, 'GET', '/tasks/mine')).json().items as Array<{ id: string; sealed: boolean }>;
    expect(mine.find((t) => t.id === r.json().id)?.sealed).toBe(true);
    const opened = (await call(manager, 'POST', `/tasks/${r.json().id}/open`)).json();
    expect(opened).toMatchObject({ title: 'حجز موعد', sender_name: 'الشخصية الأساسية', original_utterance: 'خلي مدير المكتب يحجزلي موعد باچر' });

    const [task] = await db.query<{ source: string; created_by_ai: boolean }>('SELECT source, created_by_ai FROM tasks WHERE id = $1', [r.json().id]);
    expect(task).toEqual({ source: 'voice_ai', created_by_ai: true });
    const [event] = await db.query<{ actor_type: string; name: string }>(
      `SELECT e.actor_type, k.name FROM events e JOIN api_keys k ON k.id = e.actor_key_id WHERE e.subject_id = $1 AND e.event_type = 'task.created'`, [r.json().id]);
    expect(event).toEqual({ actor_type: 'ai', name: 'نظام الذكاء' }); // the record says which program acted
  });

  it('asks back instead of guessing a person, and says who could be meant', async () => {
    const stamp = Date.now();
    await login('employee', `علي حسن ${stamp}`);
    await login('employee', `علي كريم ${stamp}`);
    const two = await ai('POST', '/tasks', { assignee_query: `علي ${stamp}`, title: 'x', original_utterance: 'خلي علي يسويها' });
    expect(two.statusCode).toBe(409);
    expect(two.json().error.code).toBe('AMBIGUOUS_ASSIGNEE');
    expect(two.json().error.details.candidates).toHaveLength(2);
    expect((await ai('POST', '/tasks', { assignee_query: 'ما موجود أبداً', title: 'x', original_utterance: 'x' })).json().error.code).toBe('ASSIGNEE_NOT_FOUND');
    expect((await ai('GET', `/people/resolve?q=${encodeURIComponent(`علي كريم ${stamp}`)}`)).json().full_name).toBe(`علي كريم ${stamp}`);
    const asked = await ai('POST', '/tasks', { title: 'x', original_utterance: 'x' });
    expect(asked.statusCode).toBe(400);
  });

  it('does a retried order once: the same Idempotency-Key gets the first answer back', async () => {
    const worker = await login('employee');
    const order = { assignee_id: worker.id, title: `مرة وحدة ${Date.now()}`, original_utterance: 'خليه يسويها' };
    const first = await ai('POST', '/tasks', order, { 'idempotency-key': 'order-1' });
    const again = await ai('POST', '/tasks', order, { 'idempotency-key': 'order-1' });
    expect(again.statusCode).toBe(201);
    expect(again.json().id).toBe(first.json().id);
    expect(again.headers['idempotent-replayed']).toBe('true');
    expect(await db.query('SELECT 1 FROM tasks WHERE title = $1', [order.title])).toHaveLength(1);
    const other = await ai('POST', '/tasks', order, { 'idempotency-key': 'order-2' });
    expect(other.json().id).not.toBe(first.json().id);
  });

  it('hands a task to someone else, gives it more time, and cancels it', async () => {
    const sender = await login('follow_up');
    const first = await login('employee', `أحمد ${Date.now()}`);
    const second = await login('employee', `حيدر ${Date.now()}`);
    const title = `تجديد العقد ${Date.now()}`;
    const { id } = (await call(sender, 'POST', '/tasks', { title, assignee_id: first.id, due_in_hours: 24 })).json() as { id: string };

    const moved = await ai('POST', `/tasks/${id}/reassign`, { assignee_query: second.name, reason: 'طلب الشخصية: حوّلها لحيدر' });
    expect(moved.statusCode, moved.body).toBe(200);
    expect((await call(second, 'GET', '/tasks/mine')).json().items.map((t: { id: string }) => t.id)).toContain(id);

    const longer = await ai('POST', `/tasks/${id}/extend`, { due_in_hours: 168, reason: 'أعطيه أسبوع' });
    expect(longer.statusCode, longer.body).toBe(200);
    const [due] = await db.query<{ due_at: Date; original_due_at: Date }>('SELECT due_at, original_due_at FROM tasks WHERE id = $1', [id]);
    expect(new Date(due!.due_at).getTime()).toBeGreaterThan(new Date(due!.original_due_at).getTime());
    expect((await ai('POST', `/tasks/${id}/extend`, { due_at: '2025-07-13T14:00:00+03:00', reason: 'x' })).json().error.code).toBe('DUE_IN_PAST');

    expect((await ai('POST', `/tasks/${id}/cancel`, { reason: 'ما نحتاجها' })).json()).toMatchObject({ id, status: 'cancelled' });
    expect((await ai('POST', `/tasks/${id}/cancel`, { reason: 'مرة ثانية' })).statusCode).toBe(409);
    expect((await ai('POST', '/tasks/not-a-task/cancel', { reason: 'x' })).statusCode).toBe(404);
  });

  it('finds tasks by words or a name, open ones first, and lists two when two fit', async () => {
    const sender = await login('follow_up');
    const worker = await login('employee');
    const word = `توأم${Date.now()}`;
    await call(sender, 'POST', '/tasks', { title: `${word} أول`, assignee_id: worker.id });
    await call(sender, 'POST', '/tasks', { title: `${word} ثاني`, assignee_id: worker.id });
    const found = (await ai('GET', `/tasks?q=${encodeURIComponent(word)}`)).json().items as Array<{ title: string; status_ar: string }>;
    expect(found.map((t) => t.title).sort()).toEqual([`${word} أول`, `${word} ثاني`]);
    expect(found[0]!.status_ar).toBe('لم تُفتح بعد');
    const open = (await ai('GET', `/tasks?assignee_id=${worker.id}`)).json().items;
    expect(open).toHaveLength(2);
  });

  it('lets the principal close a handed-in task, or return it with a reason', async () => {
    const worker = await login('employee', `حسين ${Date.now()}`);
    const made = (await ai('POST', '/tasks', { assignee_id: worker.id, title: `باقلاء ${Date.now()}`, original_utterance: 'خليه يسويها' })).json() as { id: string };
    await call(worker, 'POST', `/tasks/${made.id}/open`);
    await call(worker, 'POST', `/tasks/${made.id}/start`);
    await call(worker, 'POST', `/tasks/${made.id}/submit`, { result_text: 'استوت الباقلاء' });

    const detail = (await ai('GET', `/tasks/${made.id}`)).json();
    expect(detail).toMatchObject({ status: 'submitted', handed_in: 'استوت الباقلاء' });
    expect(detail.submissions).toHaveLength(1);

    expect((await ai('POST', `/tasks/${made.id}/review`, { decision: 'returned' })).json().error.code).toBe('RETURN_NEEDS_REASON');
    const closed = await ai('POST', `/tasks/${made.id}/review`, { decision: 'accepted' });
    expect(closed.json()).toMatchObject({ status: 'closed' });
    const [by] = await db.query<{ closed_by: string }>('SELECT t.closed_by FROM tasks t WHERE t.id = $1', [made.id]);
    const [boss] = await db.query<{ id: string }>('SELECT id FROM users WHERE is_principal');
    expect(by!.closed_by).toBe(boss!.id);
  });

  it('shows a task\'s images through links good for an hour', async () => {
    const sender = await login('office_manager');
    const worker = await login('secretary');
    const { id } = (await call(sender, 'POST', '/tasks', { title: `مخزن ${Date.now()}`, assignee_id: worker.id })).json() as { id: string };
    const png = Buffer.from('89504e470d0a1a0a0000000d49484452', 'hex');
    await app.inject({
      method: 'POST', url: `/api/v1/tasks/${id}/attachments`,
      headers: { authorization: `Bearer ${sender.token}`, 'content-type': 'multipart/form-data; boundary=b' },
      payload: Buffer.concat([Buffer.from('--b\r\nContent-Disposition: form-data; name="file"; filename="a.png"\r\nContent-Type: image/png\r\n\r\n'), png, Buffer.from('\r\n--b--\r\n')]),
    });
    const images = (await ai('GET', `/tasks/${id}/images`)).json().items as Array<{ url: string; purpose: string }>;
    expect(images).toHaveLength(1);
    const file = await app.inject({ method: 'GET', url: images[0]!.url });
    expect(file.statusCode).toBe(200);
    expect(file.rawPayload.equals(png)).toBe(true);
    expect((await app.inject({ method: 'GET', url: images[0]!.url.replace(/sig=[^&]+/, 'sig=abc') })).statusCode).toBe(403);
  });
});

describe('AI door: letters', () => {
  it('turns the principal\'s margin into a task with the letter\'s page, to whoever she named or back to the registrar', async () => {
    const manager = await login('office_manager', `مدير مكتب ${Date.now()}`);
    const worker = await login('employee', `قانوني ${Date.now()}`);
    const subject = `طلب قطعة أرض ${Date.now()}`;
    const letter = (await call(manager, 'POST', '/letters', { subject, party: 'بلدية الكرخ', ref_number: '77' })).json() as { id: string };
    const form = new FormData();
    form.append('file', new Blob([new Uint8Array(Buffer.from('89504e470d0a1a0a0000000d49484452', 'hex'))], { type: 'image/png' }), 'p.png');
    await app.inject({ method: 'POST', url: `/api/v1/letters/${letter.id}/images`, headers: { authorization: `Bearer ${manager.token}` }, payload: form });

    const waiting = (await ai('GET', '/letters?unmargined=true')).json().items as Array<{ id: string }>;
    expect(waiting.map((l) => l.id)).toContain(letter.id);
    const found = (await ai('GET', `/letters?q=${encodeURIComponent('بلدية الكرخ')}`)).json().items as Array<{ id: string }>;
    expect(found[0]!.id).toBe(letter.id);
    expect((await ai('GET', `/letters/${letter.id}/images`)).json().items).toHaveLength(1);

    const margined = await ai('POST', `/letters/${letter.id}/margin`, { assignee_query: worker.name, margin: 'للدراسة وبيان الرأي', due_in_hours: 48, original_utterance: 'همّش كتاب البلدية للقانوني' });
    expect(margined.statusCode, margined.body).toBe(201);
    const opened = (await call(worker, 'POST', `/tasks/${margined.json().task_id}/open`)).json();
    expect(opened.title).toBe(`هامش: ${subject}`);
    expect(opened.attachments).toBe(1);
    expect((await ai('POST', `/letters/${letter.id}/margin`, { margin: 'مرة ثانية', original_utterance: 'همّشه' })).json().error.code).toBe('LETTER_MARGINED');

    const second = (await call(manager, 'POST', '/letters', { subject: `طلب تعيين ${Date.now()}`, party: 'هيثم يوسف' })).json() as { id: string };
    const back = await ai('POST', `/letters/${second.id}/margin`, { margin: 'موافقة', original_utterance: 'همش كتاب هيثم يوسف بالموافقة' });
    expect(back.json().assignee).toEqual({ id: manager.id, full_name: manager.name });
  });
});

describe('AI door: appointments, messages and what the office knows', () => {
  it('books an appointment for the principal, keeps one file per guest, and tells the diary keepers', async () => {
    const keeper = await login('office_manager');
    const guest = `أبو علي ${Date.now()}`;
    const first = await ai('POST', '/appointments', { title: 'زيارة أولى', starts_at: '2031-01-10T10:00:00+03:00', guest });
    expect(first.statusCode, first.body).toBe(201);
    await ai('POST', '/appointments', { title: 'زيارة ثانية', starts_at: '2031-02-10T10:00:00+03:00', guest, original_utterance: 'يجيني أبو علي مرة ثانية' });
    const files = await db.query<{ id: string }>('SELECT id FROM persons WHERE full_name = $1', [guest]);
    expect(files).toHaveLength(1);
    const [stored] = await db.query<{ starts_at: Date }>(`SELECT starts_at FROM appointments WHERE title = 'زيارة أولى'`);
    expect(new Date(stored!.starts_at).toISOString()).toBe('2031-01-10T07:00:00.000Z');
    expect((await call(keeper, 'GET', '/notifications/mine')).json().items.map((n: { kind: string }) => n.kind)).toContain('appointment');
    expect((await ai('POST', '/appointments', { title: 'قديم', starts_at: '2025-07-13T10:00:00+03:00' })).json().error.code).toBe('IN_PAST');

    await db.query(`UPDATE persons SET organization = 'شركة النور', notes = 'يتابع عقد الصيانة' WHERE id = $1`, [files[0]!.id]);
    const facts = (await ai('GET', '/facts?from=2031-02-10')).json();
    expect(facts.appointments).toEqual([expect.objectContaining({
      title: 'زيارة ثانية', guest, organization: 'شركة النور', guest_notes: 'يتابع عقد الصيانة', earlier_visits: 1,
    })]);
  });

  it('sends the principal\'s words to everyone or to the people named, ringing their devices', async () => {
    const a = await login('employee', `منتظر ${Date.now()}`);
    const b = await login('secretary');
    const all = await ai('POST', '/messages', { body: 'بارك الله بجهودكم هذا الأسبوع', all: true });
    expect(all.statusCode, all.body).toBe(201);
    for (const s of [a, b]) {
      expect((await call(s, 'GET', '/messages')).json().items[0]).toMatchObject({ sender_name: 'الشخصية الأساسية', body: 'بارك الله بجهودكم هذا الأسبوع' });
      expect((await call(s, 'GET', '/notifications/mine')).json().items.map((n: { kind: string }) => n.kind)).toContain('message');
    }
    const one = await ai('POST', '/messages', { body: 'تعال لمكتبي', recipients: [a.name] });
    expect(one.json().recipients).toEqual([{ id: a.id, full_name: a.name }]);
    expect((await ai('POST', '/messages', { body: 'x' })).statusCode).toBe(400);
  });

  it('gives the principal her messages, the minutes\' decisions and the work in hand; she marks what she heard', async () => {
    const worker = await login('secretary', `زينب ${Date.now()}`);
    const officer = await login('minutes_officer');
    await call(worker, 'POST', '/messages', { to: 'principal', body: 'القاعة جاهزة بس ينقصها جهاز عرض' });
    const meeting = (await call(officer, 'POST', '/meetings', { title: `اجتماع المحولة ${Date.now()}`, held_at: new Date().toISOString() })).json() as { id: string };
    await call(officer, 'POST', `/meetings/${meeting.id}/publish`, { decisions: ['الموافقة على نصب المحولة'], tasks: [{ title: 'مخاطبة البلدية', assignee_id: worker.id }] });

    const facts = (await ai('GET', '/facts')).json();
    expect(facts.time_zone).toBe('Asia/Baghdad');
    expect(facts.people.length).toBeGreaterThan(0);
    const mine = facts.messages_to_principal.find((m: { body: string }) => m.body.includes('ينقصها جهاز عرض'));
    expect(mine).toMatchObject({ sender_name: worker.name });
    expect(facts.meetings.some((m: { decisions: string[] }) => m.decisions.includes('الموافقة على نصب المحولة'))).toBe(true);
    expect(facts.tasks.some((t: { title: string }) => t.title === 'مخاطبة البلدية')).toBe(true);

    expect((await ai('POST', '/messages/read', { ids: [mine.id] })).statusCode).toBe(204);
    expect((await ai('GET', '/facts')).json().messages_to_principal.some((m: { id: string }) => m.id === mine.id)).toBe(false);
    expect((await ai('GET', '/facts?from=2026-13-01')).statusCode).toBe(400);
  });

  it('keeps the record in order for whoever follows it', async () => {
    const page = (await ai('GET', '/events?limit=5')).json() as { items: Array<{ id: number }>; next_cursor: number };
    expect(page.items).toHaveLength(5);
    const next = (await ai('GET', `/events?after_id=${page.next_cursor}&limit=5`)).json().items as Array<{ id: number }>;
    expect(next[0]!.id).toBeGreaterThan(page.next_cursor);
  });
});
