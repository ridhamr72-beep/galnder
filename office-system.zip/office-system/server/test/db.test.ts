import { describe, expect, it } from 'vitest';
import { migrate } from '../src/db/index.js';
import { testDb } from './helpers/pglite.js';

describe('database', () => {
  it('applies the office migrations once, and makes none of the AI system\'s tables', async () => {
    const db = await testDb();
    try {
      expect(await migrate(db)).toEqual([]);
      const tables = (await db.query<{ name: string }>(`SELECT tablename AS name FROM pg_tables WHERE schemaname = 'public'`)).map((t) => t.name);
      expect(tables).toEqual(expect.arrayContaining(['users', 'tasks', 'notifications', 'letters', 'messages', 'face_prints', 'api_keys', 'idempotency_keys']));
      expect(tables).not.toContain('kb_documents');
      expect(tables).not.toContain('intent_examples');
    } finally {
      await db.close();
    }
  });
});
