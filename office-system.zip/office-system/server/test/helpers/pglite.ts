import { PGlite } from '@electric-sql/pglite';
import { migrate, type Db } from '../../src/db/index.js';

type Session = Pick<PGlite, 'query' | 'exec'>;

class PgliteDb implements Db {
  constructor(private readonly pg: Session, private readonly root?: PGlite) {}

  async query<T>(sql: string, params: unknown[] = []): Promise<T[]> {
    return (await this.pg.query<T>(sql, params)).rows;
  }

  async exec(sql: string): Promise<void> {
    await this.pg.exec(sql);
  }

  tx<T>(fn: (db: Db) => Promise<T>): Promise<T> {
    if (!this.root) return fn(this);
    return this.root.transaction((t) => fn(new PgliteDb(t)));
  }

  async close(): Promise<void> {
    await this.root?.close();
  }
}

/** A real Postgres in memory, migrated: tests run the production SQL without a server. */
export async function testDb(): Promise<Db> {
  const pg = await PGlite.create();
  const db = new PgliteDb(pg, pg);
  await migrate(db);
  return db;
}
