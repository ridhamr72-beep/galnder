import type { FastifyInstance } from 'fastify';
import { pino } from 'pino';
import { createServiceKey, SCOPES } from '../../src/ai/keys.js';
import { loadConfig, type Config } from '../../src/config.js';
import type { Db } from '../../src/db/index.js';
import { buildServer } from '../../src/server.js';

export function testConfig(overrides: Record<string, string> = {}): Config {
  return loadConfig({ NODE_ENV: 'test', LOG_LEVEL: 'silent', LOG_PRETTY: 'false', ...overrides });
}

/** The office server on a test database, with the background timer off (tests run its steps by hand). */
export async function buildTestApp(db: Db, overrides: Record<string, string> = {}): Promise<FastifyInstance> {
  const app = await buildServer({ config: testConfig(overrides), db, worker: false, logger: pino({ level: process.env.TEST_LOG ?? 'silent' }) });
  await app.ready();
  return app;
}

/** A service key, as the admin would make one for the AI system. */
export async function serviceKey(db: Db, scopes: string[] = [...SCOPES], name = 'نظام الذكاء'): Promise<string> {
  return (await createServiceKey(db, null, name, scopes)).api_key;
}
