"""ذكاء وهمي لتجربة باب الذكاء (/api/v1/ai) بدون نموذج. بلا مكتبات خارجية.

    set OFFICE_URL=http://localhost:8000
    set AI_API_KEY=ok_...          (npm run db -- api-key "نظام الذكاء" من مجلد server)
    python fake_ai.py health
    python fake_ai.py task "مدير المكتب" "حجز موعد مع فلان" --hours 168 --high
    python fake_ai.py find "الميزانية"
    python fake_ai.py cancel <task-id> "ما نحتاجها"
    python fake_ai.py facts --from 2026-11-01 --to 2026-11-04
    python fake_ai.py facts --q "سامي"
    python fake_ai.py briefing
    python fake_ai.py message "بارك الله بجهودكم" --all
    python fake_ai.py announcements
"""
import argparse
import json
import os
import ssl
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid


def call(method: str, path: str, body: dict | None = None, headers: dict | None = None) -> None:
    base = os.environ.get("OFFICE_URL", "http://localhost:8000")
    request = urllib.request.Request(
        f"{base}/api/v1/ai{path}",
        method=method,
        data=json.dumps(body).encode() if body is not None else None,
        headers={
            "Authorization": f"Bearer {os.environ['AI_API_KEY']}",
            "Content-Type": "application/json",
            **(headers or {}),
        },
    )
    # شهادة الشبكة الداخلية غير موثوقة من النظام، وهذه أداة تجربة فقط
    context = ssl._create_unverified_context() if os.environ.get("OFFICE_INSECURE") else None
    try:
        with urllib.request.urlopen(request, context=context) as response:
            status, payload = response.status, response.read()
    except urllib.error.HTTPError as error:
        status, payload = error.code, error.read()
    print(status)
    if payload:
        print(json.dumps(json.loads(payload), ensure_ascii=False, indent=2))


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)

    commands.add_parser("health")

    task = commands.add_parser("task", help="مهمة جديدة لموظف بالاسم أو المنصب")
    task.add_argument("assignee")
    task.add_argument("title")
    task.add_argument("--hours", type=int)
    task.add_argument("--high", action="store_true")

    find = commands.add_parser("find", help="بحث بالمهام بكلمات العنوان أو اسم الموظف")
    find.add_argument("words")

    cancel = commands.add_parser("cancel")
    cancel.add_argument("task_id")
    cancel.add_argument("reason")

    facts = commands.add_parser("facts", help="كل ما يعرفه المكتب عن فترة، أو عن كلمة")
    facts.add_argument("--from", dest="start")
    facts.add_argument("--to", dest="end")
    facts.add_argument("--q")

    commands.add_parser("briefing")
    commands.add_parser("announcements")

    message = commands.add_parser("message")
    message.add_argument("body")
    message.add_argument("--all", action="store_true")
    message.add_argument("--to", action="append", default=[])

    args = parser.parse_args()
    once = {"Idempotency-Key": str(uuid.uuid4())}
    if args.command == "health":
        call("GET", "/health")
    elif args.command == "task":
        body = {
            "assignee_query": args.assignee,
            "title": args.title,
            "priority": "high" if args.high else "normal",
            "original_utterance": f"خلي {args.assignee} {args.title}",
        }
        if args.hours:
            body["due_in_hours"] = args.hours
        call("POST", "/tasks", body, once)
    elif args.command == "find":
        call("GET", f"/tasks?{urllib.parse.urlencode({'q': args.words})}")
    elif args.command == "cancel":
        call("POST", f"/tasks/{args.task_id}/cancel", {"reason": args.reason}, once)
    elif args.command == "facts":
        query = {k: v for k, v in (("from", args.start), ("to", args.end), ("q", args.q)) if v}
        call("GET", f"/facts?{urllib.parse.urlencode(query)}")
    elif args.command == "briefing":
        call("GET", "/briefing")
    elif args.command == "announcements":
        call("GET", "/announcements")
    else:
        body = {"body": args.body, "all": True} if args.all else {"body": args.body, "recipients": args.to}
        call("POST", "/messages", body, once)


if __name__ == "__main__":
    main()
